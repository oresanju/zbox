# ZBOX Secure Update Packages

The panel fetches the OTA manifest from `https://raw.githubusercontent.com/oresanju/zbox/main/U50/update.json` and its detached binary signature from `update.json.sig`. It verifies the signature with the installed `license/public.pem` RSA public key before parsing the manifest, then verifies every selected archive against its SHA-256.

Copy `update.json.template` to `U50/update.json`, replace checksums with lowercase `sha256sum` output, and keep the flat quoted-string fields. Only numeric dotted versions newer than the installed component are applied. Sign the final, unmodified manifest with the private key corresponding to `license/public.pem`:

```sh
openssl dgst -sha256 -sign private.pem -out U50/update.json.sig U50/update.json
```

Never publish the private key.

## Component Packages

Every manifest package is a gzip tar archive with a `payload/` root. A panel package can contain `payload/index.html`, `payload/js/app.js`, and `payload/cgi-bin/app.sh`; Xray and sing-box packages contain `payload/bin/xray` and `payload/bin/sing-box` respectively.

Do not package `payload/app.json`, `payload/configs/`, `payload/config-groups/`, `payload/license/`, or `payload/.update*`. The installer rejects these paths, stages each archive, creates a full rollback copy, and always restores `app.json`, configs, config groups, and the license directory.

```sh
mkdir -p build/payload/bin
install -m 0755 sing-box build/payload/bin/sing-box
tar -C build -czf U50/packages/singbox-1.11.0.tar.gz payload
sha256sum U50/packages/singbox-1.11.0.tar.gz
```

## Offline Bundle

The browser sends raw bytes to the separate BusyBox-compatible upload CGI. Upload one `.zbox` file, maximum 100 MB, with this layout. A `.zbox` file is a gzip tar archive with a ZBOX-specific extension:

```text
update.json
update.json.sig
packages/panel-2.0.1.tar.gz
packages/xray-1.8.24.tar.gz
packages/singbox-1.11.0.tar.gz
```

Omit packages for components that are not being updated. The signed manifest and SHA-256 checks are identical for OTA and offline installation.

```sh
tar -C U50 -czf zbox-update-bundle.zbox update.json update.json.sig packages
```

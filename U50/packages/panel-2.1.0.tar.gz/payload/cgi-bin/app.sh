#!/bin/sh
# =============================================================================
# ZBOX AIO – Single CGI handler for all VPN panel operations
# =============================================================================

# --- Paths and Constants ---
BASE="/bin/zbox"
APP_JSON="$BASE/app.json"
CFG_DIR="$BASE/configs"
GROUP_DIR="$BASE/config-groups"
GEN_DIR="$BASE/generated"
LIC_DIR="$BASE/license"
SINGBOX="$BASE/bin/sing-box"
XRAY_BIN="$BASE/bin/xray"
VPN_VAL="$BASE/cgi-bin/vpn_validation"
LOG_FILE="/tmp/vpn.log"
LAT_CACHE="/tmp/latency_cache.json"
SP_LOG="/tmp/speedtest.log"
SP_TMP="/tmp/speedtest.tmp"
LOCK_FILE="/tmp/zbox_api.lock"
LAT_LOCK_FILE="/tmp/zbox_latency.lock"
PID_FILE="/tmp/vpn.pid"
VPN_IP_FILE="/tmp/vpn_ip.json"
ISP_IP_FILE="/tmp/isp_ip.json"
TUN_IFACE="tun0"
VPN_STARTING="/tmp/vpn_starting"
UPDATE_URL="https://raw.githubusercontent.com/oresanju/zbox/main/U50/update.json"
UPDATE_DIR="/tmp/zbox-update"
UPDATE_UPLOAD="$UPDATE_DIR/offline-bundle.tar.gz"

mkdir -p "$CFG_DIR" "$GEN_DIR" "$GROUP_DIR" 2>/dev/null

# =============================================================================
# CGI Helpers
# =============================================================================

POST_DATA=""
if [ "$REQUEST_METHOD" = "POST" ]; then
	if [ -n "$CONTENT_LENGTH" ] && [ "$CONTENT_LENGTH" -gt 0 ] 2>/dev/null; then
		POST_DATA=$(dd count=1 bs="$CONTENT_LENGTH" 2>/dev/null)
	fi
fi

content_json()  { echo "Content-Type: application/json"; echo ""; }
content_text()  { echo "Content-Type: text/plain";   echo ""; }

# Extract parameter from QUERY_STRING
qs_get() {
	echo "$QUERY_STRING" | tr '&' '\n' | grep "^$1=" | head -1 | cut -d= -f2-
}

# Extract parameter from POST body (form-urlencoded)
bp_get() {
	echo "$POST_DATA" | tr '&' '\n' | grep "^$1=" | head -1 | cut -d= -f2-
}

# URL decode – replaces + with space and %XX with characters
url_decode() {
	_str="$1"
	_str=$(echo "$_str" | sed 's/+/ /g')
	_dec=$(printf '%b' "$(echo "$_str" | sed 's/%/\\x/g')" 2>/dev/null)
	if [ -n "$_dec" ]; then
		echo "$_dec"
	else
		echo "$_str"
	fi
}

# Prevent path traversal in filenames
safe_name() {
	echo "$1" | sed 's/[\\\/]//g; s/\.\.//g'
}

is_wireguard_file() {
	grep -q '^[[:space:]]*\[Interface\]' "$1" 2>/dev/null
}

json_escape() {
	printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

# Lock for serializing exclusive operations
do_lock() {
	_id="${1:-generic}"
	_timeout="${2:-60}"
	_waited=0
	while [ -f "$LOCK_FILE" ]; do
		if [ "$_waited" -ge "$_timeout" ]; then
			return 1
		fi
		sleep 1
		_waited=$((_waited + 1))
	done
	echo "$_id" > "$LOCK_FILE"
	return 0
}

do_unlock() {
	rm -f "$LOCK_FILE"
}

# Latency scans are background work and must not block connect/disconnect.
do_latency_lock() {
	_timeout="${1:-30}"
	_waited=0
	while [ -f "$LAT_LOCK_FILE" ]; do
		if [ "$_waited" -ge "$_timeout" ]; then
			return 1
		fi
		sleep 1
		_waited=$((_waited + 1))
	done
	echo "latency" > "$LAT_LOCK_FILE"
	return 0
}

do_latency_unlock() {
	rm -f "$LAT_LOCK_FILE"
}

# Check if the real VPN process is currently running (via PID file only)
vpn_running() {
	if [ -f "$PID_FILE" ]; then
		_pid=$(head -n 1 "$PID_FILE")
		if [ -n "$_pid" ] && kill -0 "$_pid" 2>/dev/null; then
			return 0
		fi
	fi
	return 1
}

# Get PID of running VPN process
vpn_pid_type() {
	if [ -f "$PID_FILE" ]; then
		head -n 1 "$PID_FILE"
	else
		pgrep -x "xray" 2>/dev/null || pgrep -x "sing-box" 2>/dev/null
	fi
}

# =============================================================================
# JSON Helpers – read/write app.json (grep/cut for read, sed for write)
# =============================================================================

# Read a string value from a section: json_get "section" "key"
json_get() {
	grep -A20 "\"$1\":" "$APP_JSON" 2>/dev/null | grep "\"$2\":" | head -1 | cut -d'"' -f4
}

# Read a boolean value from a section
json_get_bool() {
	_val=$(grep -A20 "\"$1\":" "$APP_JSON" 2>/dev/null | grep "\"$2\":" | head -1 | grep -q "true" && echo "true" || echo "false")
	echo "${_val:-false}"
}

# Read a top-level string value
json_get_top() {
	grep "\"$1\":" "$APP_JSON" 2>/dev/null | head -1 | cut -d'"' -f4
}

# Set a string value within a section
json_set() {
	_tmp="${APP_JSON}.$$.$2.tmp"
	sed "s|\"$2\": \"[^\"]*\"|\"$2\": \"$3\"|g" "$APP_JSON" > "$_tmp" && [ -s "$_tmp" ] && mv "$_tmp" "$APP_JSON"
	rm -f "$_tmp" 2>/dev/null
}

# Set a boolean value within a section
json_set_bool() {
	_tmp="${APP_JSON}.$$.$2.tmp"
	sed "s|\"$2\": true|\"$2\": $3|g; s|\"$2\": false|\"$2\": $3|g" "$APP_JSON" > "$_tmp" && [ -s "$_tmp" ] && mv "$_tmp" "$APP_JSON"
	rm -f "$_tmp" 2>/dev/null
}

# Set a top-level string value
json_set_top() {
	_tmp="${APP_JSON}.$$.$1.tmp"
	sed "s|\"$1\": \"[^\"]*\"|\"$1\": \"$2\"|g" "$APP_JSON" > "$_tmp" && [ -s "$_tmp" ] && mv "$_tmp" "$APP_JSON"
	rm -f "$_tmp" 2>/dev/null
}

# Save the active config tab. Older app.json files are upgraded in place.
set_active_config_group() {
	_group="$1"
	_tmp="${APP_JSON}.$$.activeConfigGroup.tmp"
	if grep -q '"activeConfigGroup":' "$APP_JSON" 2>/dev/null; then
		sed "s|\"activeConfigGroup\": \"[^\"]*\"|\"activeConfigGroup\": \"$_group\"|g" "$APP_JSON" > "$_tmp" && [ -s "$_tmp" ] && mv "$_tmp" "$APP_JSON"
	else
		sed '$d' "$APP_JSON" | sed '$s/$/,/' > "$_tmp" || return 1
		echo "  \"activeConfigGroup\": \"$_group\"" >> "$_tmp"
		echo "}" >> "$_tmp"
		[ -s "$_tmp" ] && mv "$_tmp" "$APP_JSON"
	fi
	rm -f "$_tmp" 2>/dev/null
}

# Set a top-level string and append it if older app.json files do not have it.
json_set_top_ensure() {
	_key="$1"
	_val="$2"
	_tmp="${APP_JSON}.$$.$_key.tmp"
	[ -s "$APP_JSON" ] || return 1
	if grep -q "\"$_key\":" "$APP_JSON" 2>/dev/null; then
		json_set_top "$_key" "$_val"
	else
		sed '$d' "$APP_JSON" | sed '$s/$/,/' > "$_tmp" || return 1
		printf '  "%s": "%s"\n' "$_key" "$_val" >> "$_tmp"
		echo "}" >> "$_tmp"
		[ -s "$_tmp" ] && mv "$_tmp" "$APP_JSON"
	fi
	rm -f "$_tmp" 2>/dev/null
}

# =============================================================================
# Base64 / DNS Helpers
# =============================================================================

base64_decode() {
	echo "$1" | base64 -d 2>/dev/null || echo "$1"
}

get_dns_servers() {
	_dns="$1"
	case "$_dns" in
		google)     echo '"8.8.8.8","8.8.4.4"' ;;
		cloudflare) echo '"1.1.1.1","1.0.0.1"' ;;
		cloudflare-security) echo '"1.1.1.2"' ;;
		quad9)      echo '"9.9.9.9"' ;;
		opendns)    echo '"208.67.220.220"' ;;
		both)       echo '"8.8.8.8","1.1.1.1"' ;;
		*)          echo '"1.1.1.1"' ;;
	esac
}

dns_servers_json() {
	_dns="$1"
	case "$_dns" in
		google)     echo '"dns.google.com"' ;;
		cloudflare) echo '"cloudflare-dns.com"' ;;
		cloudflare-security) echo '"security.cloudflare-dns.com"' ;;
		quad9)      echo '"dns.quad9.net"' ;;
		opendns)    echo '"dns.opendns.com"' ;;
		both)       echo '"dns.google.com","cloudflare-dns.com"' ;;
		*)          echo '"cloudflare-dns.com"' ;;
	esac
}

# =============================================================================
# VPN Link Parsers – parse VLESS / Trojan to normalized JSON
# =============================================================================

# Extract a quoted string value from a compact JSON string
json_extract() {
	echo "$1" | tr ',' '\n' | grep "\"$2\":" | head -1 | cut -d'"' -f4
}

# Extract a numeric value from a compact JSON string
json_extract_num() {
	echo "$1" | tr ',' '\n' | grep "\"$2\":" | head -1 | cut -d: -f2 | sed 's/[^0-9]//g'
}

# Extract a quoted value from the multi-line $PARSED variable
parsed_get() {
	echo "$PARSED" | tr '\n' ' ' | tr ',' '\n' | grep "\"$1\":" | head -1 | cut -d'"' -f4
}

# Extract a numeric value from the multi-line $PARSED variable
parsed_get_num() {
	echo "$PARSED" | tr '\n' ' ' | tr ',' '\n' | grep "\"$1\":" | head -1 | cut -d: -f2 | sed 's/[^0-9]//g'
}

parsed_get_array() {
	echo "$PARSED" | tr '\n' ' ' | sed "s/.*\"$1\"[[:space:]]*:[[:space:]]*\(\[[^]]*\]\).*/\1/"
}

wg_conf_get() {
	_section="$1"
	_key="$2"
	printf '%s\n' "$_wg_cfg" | awk -v section="$_section" -v key="$_key" '
		function trim(s){gsub(/^[ \t]+|[ \t]+$/, "", s); return s}
		/^\[/ { in_section = ($0 == "[" section "]"); next }
		in_section && index($0, "=") {
			k=$0; sub(/=.*/, "", k); k=trim(k)
			v=$0; sub(/^[^=]*=/, "", v); v=trim(v)
			if (k == key) { print v; exit }
		}
	'
}

wg_conf_get_all() {
	_section="$1"
	_key="$2"
	printf '%s\n' "$_wg_cfg" | awk -v section="$_section" -v key="$_key" '
		function trim(s){gsub(/^[ \t]+|[ \t]+$/, "", s); return s}
		/^\[/ { in_section = ($0 == "[" section "]"); next }
		in_section && index($0, "=") {
			k=$0; sub(/=.*/, "", k); k=trim(k)
			v=$0; sub(/^[^=]*=/, "", v); v=trim(v)
			if (k == key) print v
		}
	'
}

# WireGuard has no standard profile-name field, so accept an optional panel-only
# comment such as: # ZBOX_NAME = Singapore 01
wg_conf_name() {
	printf '%s\n' "$_wg_cfg" | awk '
		match($0, /^#[ \t]*ZBOX_NAME[ \t]*=[ \t]*/) {
			name=$0
			sub(/^#[ \t]*ZBOX_NAME[ \t]*=[ \t]*/, "", name)
			gsub(/^[ \t]+|[ \t]+$/, "", name)
			print name
			exit
		}
	'
}

wireguard_json_array() {
	printf '%s\n' "$1" | awk '
		function trim(s){gsub(/^[ \t]+|[ \t]+$/, "", s); return s}
		BEGIN { first=1; printf "[" }
		{
			gsub(/,/, "\n")
			n=split($0, a, "\n")
			for (i=1; i<=n; i++) {
				v=trim(a[i])
				if (v == "") continue
				gsub(/\\/, "\\\\", v); gsub(/"/, "\\\"", v)
				if (!first) printf ","
				first=0
				printf "\"%s\"", v
			}
		}
		END { printf "]" }
	'
}

wireguard_num_array() {
	printf '%s' "$1" | sed 's/\[//g; s/\]//g; s/ //g' | awk -F, '
		BEGIN { printf "[" }
		{
			first=1
			for (i=1; i<=NF; i++) {
				if ($i !~ /^[0-9]+$/) continue
				if (!first) printf ","
				first=0
				printf "%d", $i
			}
		}
		END { printf "]" }
	'
}

parse_wireguard() {
	_wg_cfg=$(printf '%s\n' "$1" | sed 's/\[Interface\]/\
[Interface]\
/g; s/\[Peer\]/\
[Peer]\
/g; /^$/d')
	_private_key=$(wg_conf_get "Interface" "PrivateKey")
	_address=$(wg_conf_get_all "Interface" "Address")
	_dns=$(wg_conf_get "Interface" "DNS")
	_mtu=$(wg_conf_get "Interface" "MTU")
	_public_key=$(wg_conf_get "Peer" "PublicKey")
	_psk=$(wg_conf_get "Peer" "PresharedKey")
	_allowed_ips=$(wg_conf_get_all "Peer" "AllowedIPs")
	_endpoint=$(wg_conf_get "Peer" "Endpoint")
	_keepalive=$(wg_conf_get "Peer" "PersistentKeepalive")
	_reserved=$(wg_conf_get "Peer" "Reserved")
	[ -n "$_reserved" ] || _reserved=$(wg_conf_get "Interface" "Reserved")

	if [ -z "$_private_key" ] || [ -z "$_address" ] || [ -z "$_public_key" ] || [ -z "$_endpoint" ]; then
		echo "{}"
		return 1
	fi

	_host="${_endpoint%:*}"
	_port=$(printf '%s' "${_endpoint##*:}" | sed 's/[^0-9]//g')
	case "$_port" in *[!0-9]*|'') _port=51820 ;; esac
	[ -n "$_mtu" ] || _mtu=1420
	_alias=$(wg_conf_name)
	[ -n "$_alias" ] || _alias="$_host"

	_private_key=$(json_escape "$_private_key")
	_address_json=$(wireguard_json_array "$_address")
	_dns=$(json_escape "$_dns")
	_public_key=$(json_escape "$_public_key")
	_psk=$(json_escape "$_psk")
	_allowed_ips_json=$(wireguard_json_array "$_allowed_ips")
	_reserved_json=$(wireguard_num_array "$_reserved")
	_host=$(json_escape "$_host")
	_alias=$(json_escape "$_alias")

	cat <<JEOF
{
  "proto": "wg",
  "alias": "$_alias",
  "host": "$_host",
  "port": $_port,
  "privateKey": "$_private_key",
  "address": $_address_json,
  "dns": "$_dns",
  "publicKey": "$_public_key",
  "presharedKey": "$_psk",
  "allowedIPs": $_allowed_ips_json,
  "reserved": $_reserved_json,
  "keepalive": "$_keepalive",
  "mtu": $_mtu
}
JEOF
}

# Parse VLESS link: vless://uuid@host:port?params#alias
parse_vless() {
	_link="$1"

	_tmp="${_link#vless://}"

	_alias="${_tmp##*#}"
	if [ "$_alias" = "$_tmp" ]; then _alias=""; fi
	_alias=$(url_decode "$_alias")
	_tmp="${_tmp%%#*}"

	_params="${_tmp##*\?}"
	if [ "$_params" = "$_tmp" ]; then _params=""; else _tmp="${_tmp%%\?*}"; fi

	_remain="${_tmp##*@}"
	if [ "$_remain" = "$_tmp" ]; then echo "{}"; return 1; fi
	_uuid="${_tmp%%@*}"
	_host="${_remain%%:*}"
	_port="${_remain##*:}"
	if [ "$_port" = "$_host" ]; then _port="443"; fi

	_enc=""
	_sec=""
	_sni=""
	_fp=""
	_pbk=""
	_sid=""
	_net=""
	_path=""
	_hdr=""
	_flow=""
	_mode=""
	_allow_insecure="false"

	if [ -n "$_params" ]; then
		_oldIFS="$IFS"
		IFS='&'
		for _pair in $_params; do
			IFS='='
			set -- $_pair
			_k="$1"
			_v=$(url_decode "$2")
			case "$_k" in
				encryption) _enc="$_v" ;;
				security)   _sec="$_v" ;;
				sni)        _sni="$_v" ;;
				fp)         _fp="$_v" ;;
				pbk)        _pbk="$_v" ;;
				sid)        _sid="$_v" ;;
				type)       _net="$_v" ;;
				path)       _path="$_v" ;;
				host)       _hdr="$_v" ;;
				flow)       _flow="$_v" ;;
				mode)       _mode="$_v" ;;
				allowInsecure|allowinsecure)
					if [ "$_v" = "1" ] || [ "$_v" = "true" ]; then _allow_insecure="true"; fi
					;;
			esac
		done
		IFS="$_oldIFS"
	fi

	if [ -z "$_net" ]; then _net="tcp"; fi

	cat <<JEOF
{
  "proto": "vless",
  "uuid": "$_uuid",
  "host": "$_host",
  "port": $_port,
  "encryption": "${_enc:-none}",
  "security": "${_sec:-none}",
  "sni": "$_sni",
  "fingerprint": "${_fp:-chrome}",
  "publicKey": "$_pbk",
  "shortId": "$_sid",
  "network": "$_net",
  "path": "$_path",
  "hostHeader": "$_hdr",
  "flow": "$_flow",
  "mode": "${_mode:-auto}",
  "allowInsecure": "$_allow_insecure",
  "alias": "$_alias"
}
JEOF
}



# Parse any VPN link, return normalized JSON on stdout
parse_link() {
	_link="$1"
	case "$_link" in
		vless://*) parse_vless "$_link" ;;
		*'[Interface]'*) parse_wireguard "$_link" ;;
		trojan://*)
			_tmp="${_link#trojan://}"
			_alias="${_tmp##*#}"
			if [ "$_alias" = "$_tmp" ]; then _alias=""; fi
			_tmp="${_tmp%%#*}"; _tmp="${_tmp%%\?*}"
			_host="${_tmp%@*}"; _host="${_host##*@}"
			_port="${_host##*:}"
			if [ "$_port" = "$_host" ]; then _port="443"; fi
			_host="${_host%%:*}"
			cat <<JEOF
{"proto":"trojan","password":"","host":"$_host","port":$_port,"security":"tls","sni":"","network":"tcp","alias":"${_alias:-$_host}"}
JEOF
			;;
		*) echo "{}"; return 1 ;;
	esac
}

# =============================================================================
# Settings loader – reads app.json into global variables
# =============================================================================

get_settings() {
	MODE=$(json_get "vpn" "mode")
	if [ -z "$MODE" ]; then MODE="redirect"; fi
	CORE=$(json_get "vpn" "coreType")
	if [ -z "$CORE" ]; then CORE="xray"; fi
	DNS=$(json_get "network" "dns")
	if [ -z "$DNS" ]; then DNS="cloudflare"; fi
	IPV=$(json_get "network" "ipVersion")
	if [ -z "$IPV" ]; then IPV="prefer_ipv4"; fi
	IPR=$(json_get_bool "network" "ipResolve")
	if [ -z "$IPR" ]; then IPR="false"; fi
	BRIDGE=$(json_get "network" "bridgeInterface")
	if [ -z "$BRIDGE" ]; then BRIDGE="bridge0"; fi
	WAN=$(json_get "network" "wanInterface")
	if [ -z "$WAN" ]; then WAN="rmnet_data0"; fi
}

# =============================================================================
# Config Generators – build xray / sing-box config JSON from parsed link
# =============================================================================

# xray stream settings block (reads globals: sec net path hdr sni fp pbk sid)
xray_stream_block() {
	_sec="${sec:-none}"
	_net="${net:-tcp}"
	_sni="${sni:-}"
	_path="${path:-/}"
	_hdr="${hdr:-}"
	_fp="${fp:-chrome}"
	_pbk="${pbk:-}"
	_sid="${sid:-}"
	_mode="${mode:-auto}"
	_allow_insecure="${allowInsecure:-false}"

	echo '      "streamSettings": {'
	echo "        \"network\": \"$_net\","
	echo "        \"security\": \"$_sec\","

	case "$_net" in
		ws)
			echo '        "wsSettings": {'
			echo "          \"path\": \"$_path\""
			if [ -n "$_hdr" ]; then
				echo "          ,\"headers\": {\"Host\": \"$_hdr\"}"
			fi
			echo '        }'
			;;
		grpc)
			echo '        "grpcSettings": {'
			_subp="${_path#/}"
			echo "          \"serviceName\": \"$_subp\""
			echo '        }'
			;;
		httpupgrade)
			echo '        "httpupgradeSettings": {'
			echo "          \"host\": \"$_hdr\","
			echo "          \"path\": \"$_path\""
			echo '        }'
			;;
		xhttp)
			echo '        "xhttpSettings": {'
			echo "          \"host\": \"$_hdr\","
			echo "          \"path\": \"$_path\","
			echo "          \"mode\": \"$_mode\""
			echo '        }'
			;;
		kcp)
			echo '        "kcpSettings": {}'
			;;
		h2)
			echo '        "httpSettings": {'
			echo "          \"path\": \"$_path\""
			if [ -n "$_hdr" ]; then
				echo "          ,\"host\": [\"$_hdr\"]"
			fi
			echo '        }'
			;;
		*)
			echo '        "tcpSettings": {'
			if [ -n "$_hdr" ]; then
				echo "          \"header\": {\"type\": \"http\",\"request\": {\"headers\": {\"Host\": \"$_hdr\"}}}"
			fi
			echo '        }'
			;;
	esac

	case "$_sec" in
		tls)
			echo '        ,"tlsSettings": {'
			echo "          \"serverName\": \"${_sni:-$host}\""
			if [ "$_allow_insecure" = "true" ]; then
				echo '          ,"allowInsecure": true'
			fi
			if [ -n "$_fp" ]; then
				echo "          ,\"fingerprint\": \"$_fp\""
			fi
			echo '        }'
			;;
		reality)
			echo '        ,"realitySettings": {'
			echo "          \"serverName\": \"$_sni\","
			echo "          \"publicKey\": \"$_pbk\","
			echo "          \"shortId\": \"$_sid\","
			echo "          \"fingerprint\": \"$_fp\""
			echo '        }'
			;;
	esac

	echo '      }'
}

# Generate xray redirect config – SOCKS inbound on 127.0.0.1:1080 + dokodemo-door on 0.0.0.0:3131
gen_xray_redirect() {
	_proto="$1"
	_uuid="$2"
	_host="$3"
	_port="$4"
	_ipresolve="$5"
	_dns_opt="$6"

	sec=$(parsed_get "security")
	net=$(parsed_get "network")
	path=$(parsed_get "path")
	hdr=$(parsed_get "hostHeader")
	sni=$(parsed_get "sni")
	fp=$(parsed_get "fingerprint")
	pbk=$(parsed_get "publicKey")
	sid=$(parsed_get "shortId")
	flow=$(parsed_get "flow")
	mode=$(parsed_get "mode")
	allowInsecure=$(parsed_get "allowInsecure")

	if [ -z "$sec" ];  then sec="none"; fi
	if [ -z "$net" ];  then net="tcp"; fi
	if [ -z "$path" ]; then path="/"; fi
	if [ -z "$fp" ];   then fp="chrome"; fi
	if [ -z "$mode" ]; then mode="auto"; fi
	if [ -z "$allowInsecure" ]; then allowInsecure="false"; fi

	_domStrat="AsIs"
	if [ "$_ipresolve" = "true" ]; then _domStrat="IPIfNonMatch"; fi

	_dnsSrv=$(get_dns_servers "$_dns_opt")

	cat <<XEOF
{
  "log": {
    "loglevel": "warning",
    "access": "/tmp/vpn_access.log",
    "error": "/tmp/vpn_error.log"
  },
  "inbounds": [
    {
      "tag": "socks-in",
      "port": 1080,
      "listen": "127.0.0.1",
      "protocol": "socks",
      "settings": {
        "auth": "noauth",
        "udp": true
      }
    },
    {
      "tag": "vpn-in",
      "port": 3131,
      "protocol": "dokodemo-door",
      "settings": {
        "network": "tcp,udp",
        "followRedirect": true
      },
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      }
    }
  ],
  "outbounds": [
    {
      "tag": "proxy",
      "protocol": "$_proto",
      "settings": {
XEOF

	case "$_proto" in
		trojan)
			cat <<XEOF
        "servers": [{
          "address": "$_host",
          "port": $_port,
          "password": "$_uuid"
        }]
XEOF
			;;
		*)
			cat <<XEOF
        "vnext": [{
          "address": "$_host",
          "port": $_port,
          "users": [{
            "id": "$_uuid",
            "encryption": "none",
            "flow": "${flow:-}"
          }]
        }]
XEOF
			;;
	esac

	cat <<XEOF
      },
XEOF

	xray_stream_block

	cat <<XEOF
    },
    {
      "tag": "direct",
      "protocol": "freedom",
      "settings": {}
    }
  ],
  "routing": {
    "domainStrategy": "$_domStrat",
    "rules": [{
      "type": "field",
      "inboundTag": ["socks-in", "vpn-in"],
      "outboundTag": "proxy"
    }]
  },
  "dns": {
    "servers": [$_dnsSrv]
  }
}
XEOF
}

# Generate sing-box redirect config – SOCKS on 127.0.0.1:1080 + redirect on 0.0.0.0:3131
gen_singbox_redirect() {
	_proto="$1"
	_uuid="$2"
	_host="$3"
	_port="$4"
	_ipresolve="$5"
	_dns_opt="$6"

	get_settings

	sec=$(parsed_get "security")
	net=$(parsed_get "network")
	path=$(parsed_get "path")
	hdr=$(parsed_get "hostHeader")
	sni=$(parsed_get "sni")
	fp=$(parsed_get "fingerprint")
	pbk=$(parsed_get "publicKey")
	sid=$(parsed_get "shortId")
	flow=$(parsed_get "flow")

	if [ -z "$sec" ];  then sec="none"; fi
	if [ -z "$net" ];  then net="tcp"; fi
	if [ -z "$path" ]; then path="/"; fi
	if [ -z "$fp" ];   then fp="chrome"; fi

	_dnsSrvJson=$(get_dns_servers "$_dns_opt" | cut -d, -f1)

	cat <<SBOF
{
  "log": { "level": "info" },
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "listen_port": 1080
    },
    {
      "type": "direct",
      "tag": "vpn-in",
      "listen": "0.0.0.0",
      "listen_port": 3131,
      "override_address": "$WAN",
      "override_port": 3131,
      "sniff": true
    }
  ],
  "outbounds": [
    {
      "tag": "proxy",
      "type": "$_proto",
SBOF

	case "$_proto" in
		trojan)
			cat <<SBOF
      "server": "$_host",
      "server_port": $_port,
      "password": "$_uuid",
SBOF
			;;
		*)
			cat <<SBOF
      "server": "$_host",
      "server_port": $_port,
      "uuid": "$_uuid",
      "flow": "${flow:-}",
SBOF
			;;
	esac

	case "$net" in
		ws)
			cat <<SBOF
      "transport": {
        "type": "ws",
        "path": "$path"
SBOF
			if [ -n "$hdr" ]; then
				echo "        ,\"headers\": {\"Host\": \"$hdr\"}"
			fi
			cat <<SBOF
      },
SBOF
			;;
		grpc)
			_subp="${path#/}"
			cat <<SBOF
      "transport": {
        "type": "grpc",
        "service_name": "$_subp"
      },
SBOF
			;;
		h2)
			cat <<SBOF
      "transport": {
        "type": "http",
        "host": ["$hdr"],
        "path": "$path"
      },
SBOF
			;;
		*)
			cat <<SBOF
      "transport": { "type": "tcp" },
SBOF
			;;
	esac

	case "$sec" in
		tls)
			cat <<SBOF
      "tls": {
        "enabled": true,
        "server_name": "${sni:-$_host}",
        "utls": {
          "enabled": true,
          "fingerprint": "$fp"
        }
      }
SBOF
			;;
		reality)
			cat <<SBOF
      "tls": {
        "enabled": true,
        "server_name": "$sni",
        "reality": {
          "enabled": true,
          "public_key": "$pbk",
          "short_id": "$sid"
        }
      }
SBOF
			;;
		*)
			echo '      "tls": { "enabled": false }'
			;;
	esac

	cat <<SBOF
    },
    {
      "tag": "direct",
      "type": "direct"
    }
  ],
  "route": {
    "auto_detect_interface": true,
    "rules": [
      { "inbound": ["socks-in", "vpn-in"], "outbound": "proxy" }
    ]
  },
  "dns": {
    "servers": [
      { "tag": "dns-remote", "address": $_dnsSrvJson, "detour": "direct" },
      { "tag": "dns-direct", "address": "local", "detour": "direct" }
    ],
    "rules": [
      { "outbound": "any", "server": "dns-remote" }
    ]
  }
}
SBOF
}

# Generate sing-box tun config – SOCKS on 127.0.0.1:1080 + TUN
gen_singbox_tun() {
	_proto="$1"
	_uuid="$2"
	_host="$3"
	_port="$4"
	_ipresolve="$5"
	_dns_opt="$6"

	get_settings

	sec=$(parsed_get "security")
	net=$(parsed_get "network")
	path=$(parsed_get "path")
	hdr=$(parsed_get "hostHeader")
	sni=$(parsed_get "sni")
	fp=$(parsed_get "fingerprint")
	pbk=$(parsed_get "publicKey")
	sid=$(parsed_get "shortId")
	flow=$(parsed_get "flow")

	if [ -z "$sec" ];  then sec="none"; fi
	if [ -z "$net" ];  then net="tcp"; fi
	if [ -z "$path" ]; then path="/"; fi
	if [ -z "$fp" ];   then fp="chrome"; fi

	_dnsSrvJson=$(get_dns_servers "$_dns_opt" | cut -d, -f1)

	cat <<SBOF
{
  "log": { "level": "info" },
  "dns": {
    "servers": [
      { "tag": "dns-remote", "address": $_dnsSrvJson, "detour": "proxy" },
      { "tag": "dns-direct", "address": "local", "detour": "direct" }
    ],
    "rules": [
      { "outbound": "any", "server": "dns-remote" }
    ]
  },
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "listen_port": 1080
    },
    {
      "type": "tun",
      "tag": "tun-in",
      "interface_name": "$TUN_IFACE",
      "inet4_address": "172.19.0.1/30",
      "auto_route": true,
      "strict_route": true,
      "sniff": true
    }
  ],
  "outbounds": [
    {
      "tag": "proxy",
      "type": "$_proto",
SBOF

	case "$_proto" in
		trojan)
			cat <<SBOF
      "server": "$_host",
      "server_port": $_port,
      "password": "$_uuid",
SBOF
			;;
		*)
			cat <<SBOF
      "server": "$_host",
      "server_port": $_port,
      "uuid": "$_uuid",
      "flow": "${flow:-}",
SBOF
			;;
	esac

	case "$net" in
		ws)
			cat <<SBOF
      "transport": {
        "type": "ws",
        "path": "$path"
SBOF
			if [ -n "$hdr" ]; then
				echo "        ,\"headers\": {\"Host\": \"$hdr\"}"
			fi
			cat <<SBOF
      },
SBOF
			;;
		grpc)
			_subp="${path#/}"
			cat <<SBOF
      "transport": {
        "type": "grpc",
        "service_name": "$_subp"
      },
SBOF
			;;
		h2)
			cat <<SBOF
      "transport": {
        "type": "http",
        "host": ["$hdr"],
        "path": "$path"
      },
SBOF
			;;
		*)
			cat <<SBOF
      "transport": { "type": "tcp" },
SBOF
			;;
	esac

	case "$sec" in
		tls)
			cat <<SBOF
      "tls": {
        "enabled": true,
        "server_name": "${sni:-$_host}",
        "utls": { "enabled": true, "fingerprint": "$fp" }
      }
SBOF
			;;
		reality)
			cat <<SBOF
      "tls": {
        "enabled": true,
        "server_name": "$sni",
        "reality": { "enabled": true, "public_key": "$pbk", "short_id": "$sid" },
        "utls": { "enabled": true, "fingerprint": "$fp" }
      }
SBOF
			;;
		*)
			echo '      "tls": { "enabled": false }'
			;;
	esac

	cat <<SBOF
    },
    { "tag": "direct", "type": "direct" }
  ],
  "route": {
    "auto_detect_interface": true,
    "rules": [
      { "inbound": ["socks-in", "tun-in"], "outbound": "proxy" }
    ]
  }
}
SBOF
}

gen_singbox_wireguard_tun() {
	_dns_opt="$1"

	_host=$(parsed_get "host")
	_port=$(parsed_get_num "port")
	_private_key=$(parsed_get "privateKey")
	_address_json=$(parsed_get_array "address")
	case "$_address_json" in \[*\]) ;; *) _address_json='[]' ;; esac
	_public_key=$(parsed_get "publicKey")
	_psk=$(parsed_get "presharedKey")
	_reserved_json=$(parsed_get_array "reserved")
	_mtu=$(parsed_get_num "mtu")
	[ -n "$_port" ] || _port=51820
	[ -n "$_mtu" ] || _mtu=1420
	_dnsSrvJson=$(get_dns_servers "$_dns_opt" | cut -d, -f1)

	cat <<SBOF
{
  "log": { "level": "info" },
  "dns": {
    "servers": [
      { "tag": "dns-remote", "address": $_dnsSrvJson, "detour": "direct" },
      { "tag": "dns-direct", "address": "local", "detour": "direct" }
    ],
    "rules": [
      { "outbound": "any", "server": "dns-remote" }
    ]
  },
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "listen_port": 1080
    },
    {
      "type": "tun",
       "tag": "tun-in",
       "interface_name": "$TUN_IFACE",
       "address": ["172.19.0.1/30"],
       "mtu": $_mtu,
       "auto_route": true,
      "strict_route": true,
      "sniff": true
    }
  ],
  "outbounds": [
    {
      "tag": "proxy",
      "type": "wireguard",
      "server": "$_host",
      "server_port": $_port,
      "local_address": $_address_json,
      "private_key": "$_private_key",
      "peer_public_key": "$_public_key",
SBOF
	if [ -n "$_psk" ]; then
		echo "      \"pre_shared_key\": \"$_psk\","
	fi
	case "$_reserved_json" in
		\[[0-9]*,*) echo "      \"reserved\": $_reserved_json," ;;
		\[[0-9]*\]) echo "      \"reserved\": $_reserved_json," ;;
	esac
	cat <<SBOF
      "mtu": $_mtu
    },
    { "tag": "direct", "type": "direct" }
  ],
  "route": {
    "auto_detect_interface": true,
    "rules": [
      { "network": "udp", "port": 53, "outbound": "direct" },
      { "network": "tcp", "port": 53, "outbound": "direct" },
      { "inbound": ["socks-in", "tun-in"], "outbound": "proxy" }
    ],
    "final": "proxy"
  }
}
SBOF
}

# Generate an isolated SOCKS client for WireGuard latency checks. It must not
# create a TUN interface or install routes while the panel is testing servers.
gen_singbox_wireguard_latency() {
	_port="$1"
	_dns_opt="$2"

	_host=$(parsed_get "host")
	_port_cfg=$(parsed_get_num "port")
	_private_key=$(parsed_get "privateKey")
	_address_json=$(parsed_get_array "address")
	case "$_address_json" in \[*\]) ;; *) _address_json='[]' ;; esac
	_public_key=$(parsed_get "publicKey")
	_psk=$(parsed_get "presharedKey")
	_reserved_json=$(parsed_get_array "reserved")
	_mtu=$(parsed_get_num "mtu")
	[ -n "$_port_cfg" ] || _port_cfg=51820
	[ -n "$_mtu" ] || _mtu=1420
	_dnsSrvJson=$(get_dns_servers "$_dns_opt" | cut -d, -f1)

	cat <<SBOF
{
  "log": { "level": "warn" },
  "dns": {
    "servers": [
      { "tag": "dns-remote", "address": $_dnsSrvJson, "detour": "direct" }
    ]
  },
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "listen_port": $_port
    }
  ],
  "outbounds": [
    {
      "tag": "proxy",
      "type": "wireguard",
      "server": "$_host",
      "server_port": $_port_cfg,
      "local_address": $_address_json,
      "private_key": "$_private_key",
      "peer_public_key": "$_public_key",
SBOF
	if [ -n "$_psk" ]; then
		echo "      \"pre_shared_key\": \"$_psk\","
	fi
	case "$_reserved_json" in
		\[[0-9]*,*) echo "      \"reserved\": $_reserved_json," ;;
		\[[0-9]*\]) echo "      \"reserved\": $_reserved_json," ;;
	esac
	cat <<SBOF
      "mtu": $_mtu
    },
    { "tag": "direct", "type": "direct" }
  ],
  "route": {
    "auto_detect_interface": true,
    "rules": [
      { "inbound": ["socks-in"], "outbound": "proxy" }
    ],
    "final": "proxy"
  }
}
SBOF
}

# =============================================================================
# Config Management – generate / apply / select / delete / list / view
# =============================================================================

generate_config() {
	_file="$1"
	_filepath="$CFG_DIR/$_file"

	if [ ! -f "$_filepath" ]; then
		echo "{\"error\":\"Config file not found: $_file\"}"
		return 1
	fi

	_first_line=$(head -n 1 "$_filepath" 2>/dev/null | tr -d '\r\n')
	if is_wireguard_file "$_filepath"; then _link=$(cat "$_filepath" 2>/dev/null | tr -d '\r'); else _link="$_first_line"; fi
	if [ -z "$_link" ]; then
		echo "{\"error\":\"Empty config file\"}"
		return 1
	fi

	PARSED=$(parse_link "$_link")
	if [ "$PARSED" = "{}" ]; then
		echo "{\"error\":\"Could not parse VPN link\"}"
		return 1
	fi

	_proto=$(parsed_get "proto")
	_uuid=$(parsed_get "uuid")
	_host=$(parsed_get "host")
	_port=$(parsed_get_num "port")
	_alias=$(parsed_get "alias")

	get_settings
	if [ "$_proto" = "wg" ]; then
		_config=$(gen_singbox_wireguard_tun "$DNS")
		if [ -n "$_config" ]; then
			echo "$_config" > "$GEN_DIR/config.json"
			json_set_top "selectedConfig" "$_file"
			json_set_top "selectedConfigAlias" "${_alias:-$_file}"
			echo "{\"status\":\"ok\",\"message\":\"Config Selected for ${_alias:-$_file}\"}"
			return 0
		fi
		echo '{"error":"Failed to generate WireGuard config"}'
		return 1
	fi
	_net=$(parsed_get "network")
	if { [ "$CORE" = "singbox" ] || [ "$MODE" = "tun" ]; } && { [ "$_net" = "xhttp" ] || [ "$_net" = "httpupgrade" ]; }; then
		echo '{"error":"xhttp/httpupgrade requires XRAY redirect mode"}'
		return 1
	fi

	_config=""
	case "$CORE" in
		singbox)
			case "$MODE" in
				tun) _config=$(gen_singbox_tun "$_proto" "$_uuid" "$_host" "$_port" "$IPR" "$DNS") ;;
				*)   _config=$(gen_singbox_redirect "$_proto" "$_uuid" "$_host" "$_port" "$IPR" "$DNS") ;;
			esac
			;;
		*)
			case "$MODE" in
				tun) _config=$(gen_singbox_tun "$_proto" "$_uuid" "$_host" "$_port" "$IPR" "$DNS") ;;
				*)   _config=$(gen_xray_redirect "$_proto" "$_uuid" "$_host" "$_port" "$IPR" "$DNS") ;;
			esac
			;;
	esac

	if [ -n "$_config" ]; then
		echo "$_config" > "$GEN_DIR/config.json"
		json_set_top "selectedConfig" "$_file"
		json_set_top "selectedConfigAlias" "${_alias:-$_file}"
		echo "{\"status\":\"ok\",\"message\":\"Config Selected for ${_alias:-$_file}\"}"
		return 0
	else
		echo "{\"error\":\"Failed to generate config\"}"
		return 1
	fi
}

do_config_detail() {
	_file=$(qs_get "file")
	[ -z "$_file" ] && _file=$(bp_get "file")
	_file=$(safe_name "$_file")
	_filepath="$CFG_DIR/$_file"
	content_json

	if [ -z "$_file" ] || [ ! -f "$_filepath" ]; then
		echo '{"status":"error","error":"File not found"}'
		return
	fi

	_first_line=$(head -n 1 "$_filepath" 2>/dev/null | tr -d '\r\n')
	if is_wireguard_file "$_filepath"; then _link=$(cat "$_filepath" 2>/dev/null | tr -d '\r'); else _link="$_first_line"; fi
	PARSED=$(parse_link "$_link")
	if [ -z "$PARSED" ] || [ "$PARSED" = "{}" ]; then
		echo '{"status":"error","error":"Could not parse config"}'
		return
	fi

	_link_json=$(json_escape "$_link")
	_file_json=$(json_escape "$_file")
	echo '{'
	printf '  "status":"ok","file":"%s","link":"%s","parsed":' "$_file_json" "$_link_json"
	echo "$PARSED"
	echo '}'
}

do_config_update() {
	if vpn_running || [ -f "$VPN_STARTING" ]; then
		content_json
		echo '{"status":"error","error":"Disconnect VPN before editing configs"}'
		return
	fi

	_file=$(bp_get "file")
	[ -z "$_file" ] && _file=$(qs_get "file")
	_file=$(safe_name "$_file")
	_link=$(bp_get "link")
	_link=$(url_decode "$_link")
	_link=$(echo "$_link" | tr -d '\r\n')
	_filepath="$CFG_DIR/$_file"

	content_json
	if [ -z "$_file" ] || [ ! -f "$_filepath" ]; then
		echo '{"status":"error","error":"File not found"}'
		return
	fi
	if [ -z "$_link" ]; then
		echo '{"status":"error","error":"No link provided"}'
		return
	fi

	PARSED=$(parse_link "$_link")
	if [ -z "$PARSED" ] || [ "$PARSED" = "{}" ]; then
		echo '{"status":"error","error":"Invalid VPN link"}'
		return
	fi

	echo "$_link" > "$_filepath" || {
		echo '{"status":"error","error":"Could not save config"}'
		return
	}
	rm -f "$LAT_CACHE" /tmp/latency_cache_vless.json /tmp/latency_cache_wg.json

	_selected=$(json_get_top "selectedConfig")
	if [ "$_selected" = "$_file" ]; then
		_regen=$(generate_config "$_file" 2>/dev/null)
		if echo "$_regen" | grep -q '"error"'; then
			_warn=$(json_escape "$_regen")
			printf '{"status":"ok","warning":"%s"}\n' "$_warn"
			return
		fi
	fi

	_alias=$(parsed_get "alias")
	[ -n "$_alias" ] || _alias="$_file"
	_esc_alias=$(json_escape "$_alias")
	printf '{"status":"ok","alias":"%s","file":"%s"}\n' "$_esc_alias" "$_file"
}

# List all configs as JSON array
do_configs() {
	content_json

	if [ ! -d "$CFG_DIR" ]; then
		echo "[]"
		return
	fi

	_first=1
	_count=0
	echo "["
	for _f in "$CFG_DIR"/*.txt; do
		[ ! -f "$_f" ] && continue

		_file=$(basename "$_f")
		_first_line=$(head -n 1 "$_f" 2>/dev/null | tr -d '\r\n')
		if is_wireguard_file "$_f"; then _lnk=$(cat "$_f" 2>/dev/null | tr -d '\r'); else _lnk="$_first_line"; fi

		_proto="unknown"
		_alias="$_file"
		_alias="${_alias%.txt}"

		case "$_lnk" in
			vless://*)  _proto="vless" ;;
			trojan://*) _proto="trojan" ;;
			*'[Interface]'*) _proto="wg" ;;
		esac

		if [ "$_proto" = "wg" ]; then
			PARSED=$(parse_wireguard "$_lnk")
			_wg_alias=$(parsed_get "alias")
			[ -n "$_wg_alias" ] && _alias="$_wg_alias"
		else
			_link_alias=$(echo "$_lnk" | sed 's/.*#//; s/&.*//')
			if [ -n "$_link_alias" ] && [ "$_link_alias" != "$_lnk" ]; then
				_alias=$(url_decode "$_link_alias")
			fi
		fi

		_count=$((_count + 1))
		if [ "$_first" -ne 1 ]; then
			echo ","
		fi
		_first=0

		_esc_alias=$(echo "$_alias" | sed 's/\\/\\\\/g; s/"/\\"/g')
		printf '  {"alias":"%s","proto":"%s","file":"%s"}' "$_esc_alias" "$_proto" "$_file"
	done
	if [ "$_count" -gt 0 ]; then
		echo ""
	fi
	echo "]"
}

# Config groups are stored as small line-based files: first line is the group
# name and remaining lines are config filenames. API consumers receive JSON.
do_groups() {
	content_json
	echo "["
	_first=1
	for _g in "$GROUP_DIR"/*.group; do
		[ -f "$_g" ] || continue
		_id=$(basename "$_g" .group)
		_name=$(head -n 1 "$_g" 2>/dev/null)
		_name_json=$(printf '%s' "$_name" | sed 's/\\/\\\\/g; s/"/\\"/g')
		if [ "$_first" -ne 1 ]; then echo ","; fi
		_first=0
		printf '  {"id":"%s","name":"%s","configs":[' "$_id" "$_name_json"
		_cf_first=1
		tail -n +2 "$_g" 2>/dev/null | while IFS= read -r _cf; do
			[ -n "$_cf" ] || continue
			_cf_json=$(printf '%s' "$_cf" | sed 's/\\/\\\\/g; s/"/\\"/g')
			if [ "$_cf_first" -ne 1 ]; then printf ','; fi
			_cf_first=0
			printf '"%s"' "$_cf_json"
		done
		printf ']}'
	done
	[ "$_first" -ne 1 ] && echo ""
	echo "]"
}

do_group_save() {
	_id=$(url_decode "$(bp_get id)")
	_name=$(url_decode "$(bp_get name)")
	_name=$(printf '%s' "$_name" | tr -d '\r\n|' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
	if [ -z "$_name" ]; then
		content_json
		echo '{"status":"error","error":"Group name is required"}'
		return
	fi
	if [ -z "$_id" ]; then
		_slug=$(printf '%s' "$_name" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/_/g; s/__*/_/g; s/^_//; s/_$//')
		[ -n "$_slug" ] || _slug="group"
		_id="${_slug}_$(date +%s 2>/dev/null || echo 0)_$$"
	fi
	_id=$(printf '%s' "$_id" | sed 's/[^a-zA-Z0-9_-]//g')
	[ -n "$_id" ] || _id="group_$$"
	_tmp="$GROUP_DIR/.${_id}.tmp"
	echo "$_name" > "$_tmp" || {
		content_json
		echo '{"status":"error","error":"Could not save group"}'
		return
	}
	# Each checked config is sent as its own file= field. This avoids BusyBox
	# form-decoding differences that can truncate comma-separated membership.
	echo "$POST_DATA" | tr '&' '\n' | grep '^file=' | cut -d= -f2- | while IFS= read -r _cf; do
		_cf=$(safe_name "$(url_decode "$_cf")")
		[ -n "$_cf" ] && [ -f "$CFG_DIR/$_cf" ] && echo "$_cf"
	done >> "$_tmp"
	mv "$_tmp" "$GROUP_DIR/${_id}.group"
	content_json
	printf '{"status":"ok","id":"%s"}\n' "$_id"
}

do_group_delete() {
	_id=$(safe_name "$(qs_get id)")
	[ -n "$_id" ] || _id=$(safe_name "$(bp_get id)")
	if [ -f "$GROUP_DIR/${_id}.group" ]; then
		rm -f "$GROUP_DIR/${_id}.group"
		[ "$(json_get_top activeConfigGroup)" = "$_id" ] && set_active_config_group "all"
		content_json
		echo '{"status":"ok"}'
	else
		content_json
		echo '{"status":"error","error":"Group not found"}'
	fi
}

# Apply a new VPN link (save to configs directory)
do_apply() {
	_link="$POST_DATA"

	if echo "$POST_DATA" | grep -q '^link='; then
		_link=$(bp_get "link")
	fi
	_link=$(url_decode "$_link")
	_req_proto=$(bp_get "proto")
	[ -z "$_req_proto" ] && _req_proto=$(qs_get "proto")
	_config_name=$(bp_get "config_name")
	[ -z "$_config_name" ] && _config_name=$(qs_get "config_name")
	_config_name=$(url_decode "$_config_name" | tr '\r\n' '  ' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
	if [ "$_req_proto" = "wg" ] || printf '%s\n' "$_link" | grep -q '^\[Interface\]'; then
		_link=$(printf '%s\n' "$_link" | tr -d '\r')
		_req_proto="wg"
		if [ -n "$_config_name" ]; then
			_link=$(printf '%s\n' "$_link" | sed '/^#[[:space:]]*ZBOX_NAME[[:space:]]*=/d')
			_link="# ZBOX_NAME = $_config_name

$_link"
		fi
	else
		_link=$(echo "$_link" | tr -d '\r\n')
	fi

	if [ -z "$_link" ]; then
		content_json
		echo '{"status":"error","error":"No link provided"}'
		return
	fi

	_proto="Unknown"
	case "$_link" in
		vless://*)  _proto="VLESS" ;;
		trojan://*) _proto="Trojan" ;;
	esac
	if [ "$_req_proto" = "wg" ]; then
		PARSED=$(parse_wireguard "$_link")
		if [ -z "$PARSED" ] || [ "$PARSED" = "{}" ]; then
			content_json
			echo '{"status":"error","error":"Invalid WireGuard config"}'
			return
		fi
		_proto="WIREGUARD"
	fi

	if [ "$_req_proto" = "wg" ]; then
		_alias=$(parsed_get "alias")
	else
		_alias=$(echo "$_link" | sed 's/.*#//; s/&.*//')
		_alias=$(url_decode "$_alias")
		if [ "$_alias" = "$_link" ] || [ -z "$_alias" ]; then
			_alias=$(echo "$_link" | sed 's/.*@//; s/:.*//; s/\?.*//; s/#.*//')
		fi
	fi

	_base_name="${_proto}_${_alias}"
	_base_name=$(echo "$_base_name" | sed 's/[^a-zA-Z0-9_-]//g')
	_counter=1
	_filename="${_base_name}.txt"
	while [ -f "$CFG_DIR/$_filename" ]; do
		_filename="${_base_name}_${_counter}.txt"
		_counter=$((_counter + 1))
	done

	echo "$_link" > "$CFG_DIR/$_filename"
	rm -f "$LAT_CACHE" /tmp/latency_cache_vless.json /tmp/latency_cache_wg.json

	content_json
	_esc_alias=$(echo "$_alias" | sed 's/\\/\\\\/g; s/"/\\"/g')
	echo "{\"status\":\"ok\",\"alias\":\"$_esc_alias\",\"file\":\"$_filename\",\"proto\":\"$_proto\"}"
}

# Select a config and generate config.json
do_select() {
	_file=$(qs_get "file")
	if [ -z "$_file" ]; then
		_file=$(bp_get "file")
	fi
	_file=$(safe_name "$_file")
	_req_proto=$(bp_get "proto")
	case "$_req_proto" in wg|vless) ;; *) _req_proto="" ;; esac
	if [ -n "$_req_proto" ]; then
		_filepath="$CFG_DIR/$_file"
		_first_line=$(head -n 1 "$_filepath" 2>/dev/null | tr -d '\r\n')
		if is_wireguard_file "$_filepath"; then _link=$(cat "$_filepath" 2>/dev/null | tr -d '\r'); else _link="$_first_line"; fi
		PARSED=$(parse_link "$_link")
		_actual_proto=$(parsed_get "proto")
		if [ "$_actual_proto" != "$_req_proto" ]; then
			content_json
			echo '{"status":"error","error":"Selected config does not match the active protocol"}'
			return
		fi
	fi

	_ov_mode=$(bp_get "vpn_mode")
	_ov_core=$(bp_get "vpn_core")
	_ov_dns=$(bp_get "dns_type")
	_ov_ipv=$(bp_get "ip_version")
	_ov_ipr=$(bp_get "ip_resolve")

	if [ -n "$_ov_mode" ]; then json_set "vpn" "mode" "$_ov_mode"; fi
	if [ -n "$_ov_core" ]; then json_set "vpn" "coreType" "$_ov_core"; fi
	if [ -n "$_ov_dns" ];  then json_set "network" "dns" "$_ov_dns"; fi
	if [ -n "$_ov_ipv" ];  then json_set "network" "ipVersion" "$_ov_ipv"; fi
	if [ -n "$_ov_ipr" ]; then
		if [ "$_ov_ipr" = "on" ]; then
			json_set_bool "network" "ipResolve" "true"
		else
			json_set_bool "network" "ipResolve" "false"
		fi
	fi

	content_json
	generate_config "$_file"
}

# Delete a config file
do_delete() {
	_file=$(qs_get "file")
	if [ -z "$_file" ]; then
		_file=$(bp_get "file")
	fi
	_file=$(safe_name "$_file")

	_filepath="$CFG_DIR/$_file"

	if [ ! -f "$_filepath" ]; then
		content_json
		echo '{"success":false,"error":"File not found"}'
		return
	fi

	rm -f "$_filepath"
	rm -f "$LAT_CACHE" /tmp/latency_cache_vless.json /tmp/latency_cache_wg.json
	# Remove the deleted config from every group while preserving group names.
	for _g in "$GROUP_DIR"/*.group; do
		[ -f "$_g" ] || continue
		_g_tmp="${_g}.tmp"
		awk -v file="$_file" 'NR == 1 || $0 != file' "$_g" > "$_g_tmp" && mv "$_g_tmp" "$_g"
	done

	_selected=$(json_get_top "selectedConfig")
	if [ "$_selected" = "$_file" ]; then
		json_set_top "selectedConfig" ""
		json_set_top "selectedConfigAlias" ""
		rm -f "$GEN_DIR/config.json"
	fi

	content_json
	echo '{"success":true}'
}

# View generated config.json (plain text)
do_config_view() {
	if [ -f "$GEN_DIR/config.json" ]; then
		content_text
		cat "$GEN_DIR/config.json"
	else
		content_text
		echo "No config."
	fi
}

# =============================================================================
# iptables Helpers – redirect mode traffic to local proxy (port 3131)
# =============================================================================

add_iptables_rules() {
	_iface="$WAN"
	_port="3131"

	iptables -t nat -N ZBOX_VPN 2>/dev/null
	iptables -t nat -F ZBOX_VPN 2>/dev/null
	iptables -t nat -A ZBOX_VPN -d 0.0.0.0/8 -j RETURN
	iptables -t nat -A ZBOX_VPN -d 10.0.0.0/8 -j RETURN
	iptables -t nat -A ZBOX_VPN -d 100.64.0.0/10 -j RETURN
	iptables -t nat -A ZBOX_VPN -d 127.0.0.0/8 -j RETURN
	iptables -t nat -A ZBOX_VPN -d 169.254.0.0/16 -j RETURN
	iptables -t nat -A ZBOX_VPN -d 172.16.0.0/12 -j RETURN
	iptables -t nat -A ZBOX_VPN -d 192.168.0.0/16 -j RETURN
	iptables -t nat -A ZBOX_VPN -d 224.0.0.0/4 -j RETURN
	iptables -t nat -A ZBOX_VPN -p tcp -j REDIRECT --to-ports "$_port"

	iptables -t nat -D PREROUTING -j ZBOX_VPN 2>/dev/null
	iptables -t nat -I PREROUTING -j ZBOX_VPN
}

del_iptables_rules() {
	iptables -t nat -D PREROUTING -j ZBOX_VPN 2>/dev/null
	iptables -t nat -F ZBOX_VPN 2>/dev/null
	iptables -t nat -X ZBOX_VPN 2>/dev/null
}

# TUN traffic crosses the router's FORWARD chain before sing-box receives it.
# Keep these rules separate from redirect mode, which uses NAT PREROUTING.
add_tun_forward_rules() {
	iptables -N ZBOX_TUN 2>/dev/null
	iptables -F ZBOX_TUN 2>/dev/null
	iptables -A ZBOX_TUN -i "$BRIDGE" -o "$TUN_IFACE" -j ACCEPT
	iptables -A ZBOX_TUN -i "$TUN_IFACE" -o "$BRIDGE" -j ACCEPT

	iptables -D FORWARD -j ZBOX_TUN 2>/dev/null
	iptables -I FORWARD -j ZBOX_TUN
}

del_tun_forward_rules() {
	iptables -D FORWARD -j ZBOX_TUN 2>/dev/null
	iptables -F ZBOX_TUN 2>/dev/null
	iptables -X ZBOX_TUN 2>/dev/null
}

# =============================================================================
# VPN Operations – connect / disconnect / IP / connectivity helpers
# =============================================================================

# Get VPN IP through the SOCKS5 proxy on 127.0.0.1:1080
get_vpn_ip() {
	/bin/curl --socks5 127.0.0.1:1080 -s --max-time 5 http://ip-api.com/json 2>/dev/null
}

# Get ISP IP through the WAN interface directly
get_isp_ip() {
	/bin/curl --interface "$WAN" -s --max-time 10 http://ip-api.com/json 2>/dev/null
}

# Check if VPN traffic actually flows through SOCKS5 proxy
check_connectivity() {
	_code=$(/bin/curl --socks5-hostname 127.0.0.1:1080 -m 5 -s -o /dev/null -w "%{http_code}" http://www.gstatic.com/generate_204 2>/dev/null)
	[ "$_code" = "204" ]
}

watchdog_running() {
	if [ -f /tmp/vpn_watchdog.lock ]; then
		_wd_pid=$(cat /tmp/vpn_watchdog.lock 2>/dev/null)
		[ -n "$_wd_pid" ] && kill -0 "$_wd_pid" 2>/dev/null && return 0
	fi
	ps 2>/dev/null | grep '[w]atchdog.sh' >/dev/null 2>&1
}

stop_watchdog() {
	touch /tmp/vpn_watchdog.stop 2>/dev/null
	if [ -f /tmp/vpn_watchdog.lock ]; then
		_wd_pid=$(cat /tmp/vpn_watchdog.lock 2>/dev/null)
		[ -n "$_wd_pid" ] && kill "$_wd_pid" 2>/dev/null
	fi
	sleep 1
	ps 2>/dev/null | grep '[w]atchdog.sh' | awk '{print $1}' | while read _wd_pid; do
		[ -n "$_wd_pid" ] && kill "$_wd_pid" 2>/dev/null
	done
	sleep 1
	ps 2>/dev/null | grep '[w]atchdog.sh' | awk '{print $1}' | while read _wd_pid; do
		[ -n "$_wd_pid" ] && kill -9 "$_wd_pid" 2>/dev/null
	done
	rm -f /tmp/vpn_watchdog.lock
}

verify_license() {
	_key="$1"
	_pubkey="$LIC_DIR/public.pem"
	[ -n "$_key" ] && [ -f "$_pubkey" ] && [ -x "$VPN_VAL" ] || return 1

	_msn=$(cfg get modem_msn 2>/dev/null)
	_mac=$(cfg get wifi_mac_address 2>/dev/null)
	if [ -z "$_msn" ]; then _msn=$(json_get "system" "modemMsn"); fi
	if [ -z "$_mac" ]; then _mac=$(json_get "system" "wifiMac"); fi
	[ -n "$_msn" ] && [ -n "$_mac" ] || return 1

	"$VPN_VAL" "$_key" "$_pubkey" "$_msn" "$_mac" 2>/dev/null | grep -q "LICENSE VERIFIED"
}

do_connect() {
	get_settings
	_keep_fallback=$(qs_get "keep_fallback")

	_lic_key=$(json_get "license" "key")
	_lic_status=$(json_get "license" "status")
	if [ "$_lic_status" != "ACTIVATED" ]; then
		if verify_license "$_lic_key"; then
			json_set "license" "status" "ACTIVATED"
		else
			content_json
			echo '{"status":"error","message":"License not activated"}'
			return
		fi
	fi

	if vpn_running; then
		content_json
		echo '{"status":"success","message":"Already connected"}'
		return
	fi

	_cfg="$GEN_DIR/config.json"
	if [ ! -f "$_cfg" ]; then
		content_json
		echo '{"status":"error","message":"No config Selected. Select a config first."}'
		return
	fi

	_fallback_current=$(json_get_top "selectedConfig")
	if [ "$_keep_fallback" = "1" ]; then
		_fallback_main=$(json_get_top "fallbackMainConfig")
		json_set_top_ensure "fallbackCurrentConfig" "$_fallback_current"
		if [ -n "$_fallback_main" ] && [ "$_fallback_current" != "$_fallback_main" ]; then
			json_set_top_ensure "fallbackUsingBackup" "true"
		else
			json_set_top_ensure "fallbackUsingBackup" "false"
		fi
	else
		_fallback_group=$(json_get_top "activeConfigGroup")
		[ -n "$_fallback_group" ] || _fallback_group="all"
		json_set_top_ensure "fallbackMainConfig" "$_fallback_current"
		json_set_top_ensure "fallbackGroup" "$_fallback_group"
		json_set_top_ensure "fallbackCurrentConfig" "$_fallback_current"
		json_set_top_ensure "fallbackUsingBackup" "false"
	fi

	killall sing-box 2>/dev/null
	killall xray 2>/dev/null
	sleep 1

	touch "$VPN_STARTING"
	_run_core="$CORE"
	_run_mode="$MODE"
	_selected_file=$(json_get_top "selectedConfig")
	if [ -n "$_selected_file" ] && [ -f "$CFG_DIR/$_selected_file" ]; then
		if is_wireguard_file "$CFG_DIR/$_selected_file"; then
			_run_core="singbox"
			_run_mode="tun"
		fi
	fi

	if [ "$_run_core" = "singbox" ] || [ "$_run_mode" = "tun" ]; then
		if [ ! -x "$SINGBOX" ]; then
			rm -f "$VPN_STARTING"
			content_json
			echo '{"status":"error","message":"sing-box binary not found"}'
			return
		fi
		"$SINGBOX" run -c "$_cfg" >>"$LOG_FILE" 2>&1 &
	else
		if [ ! -x "$XRAY_BIN" ]; then
			rm -f "$VPN_STARTING"
			content_json
			echo '{"status":"error","message":"xray binary not found"}'
			return
		fi
		"$XRAY_BIN" run -c "$_cfg" >>"$LOG_FILE" 2>&1 &
	fi

	_pid=$!
	echo "$_pid" > "$PID_FILE"
	sleep 2

	if kill -0 "$_pid" 2>/dev/null; then
		rm -f "$VPN_STARTING"
		if [ "$_run_mode" = "redirect" ]; then
			add_iptables_rules
		else
			add_tun_forward_rules
		fi
		if [ "$(json_get_bool "vpn" "autofallback")" = "true" ] && [ -x "$BASE/cgi-bin/watchdog.sh" ]; then
			rm -f /tmp/vpn_watchdog.stop
			"$BASE/cgi-bin/watchdog.sh" >/dev/null 2>&1 &
		fi
		get_vpn_ip >"$VPN_IP_FILE" 2>/dev/null
		get_isp_ip >"$ISP_IP_FILE" 2>/dev/null
		content_json
		echo '{"status":"success","message":"VPN connected"}'
	else
		rm -f "$VPN_STARTING"
		rm -f "$PID_FILE"
		content_json
		echo '{"status":"error","message":"VPN process failed to start"}'
	fi
}

do_disconnect() {
	_keep_watchdog=$(qs_get "keep_watchdog")
	del_iptables_rules
	del_tun_forward_rules

	if [ -f "$PID_FILE" ]; then
		_pid=$(head -n 1 "$PID_FILE")
		kill "$_pid" 2>/dev/null
		rm -f "$PID_FILE"
	fi

	killall sing-box 2>/dev/null
	killall xray 2>/dev/null
	if [ "$_keep_watchdog" != "1" ]; then
		stop_watchdog
	fi
	sleep 2
	ip link del "$TUN_IFACE" 2>/dev/null

	rm -f "$VPN_IP_FILE" "$ISP_IP_FILE" "$VPN_STARTING"
	content_json
	echo '{"status":"ok","message":"VPN disconnected"}'
}

# =============================================================================
# Status – returns full VPN state as JSON
# =============================================================================

do_status() {
	get_settings

	_status="Disconnected"

	if vpn_running; then
		_status="Connected"
		rm -f "$VPN_STARTING"
	elif [ -f "$VPN_STARTING" ]; then
		_status="Connecting"
	elif [ -f "$PID_FILE" ]; then
		_pid=$(head -n 1 "$PID_FILE")
		if [ -n "$_pid" ] && ! kill -0 "$_pid" 2>/dev/null; then
			_status="Error"
		fi
	fi

	_vpn_ip=""
	_isp_ip=""
	_uptime_str=""
	_mem_str=""
	_usage_str=""
	_protocol=""

	_config_file=$(json_get_top "selectedConfig")
	if [ -z "$_config_file" ]; then _config_file="-"; fi
	_fallback_main=$(json_get_top "fallbackMainConfig")
	_fallback_group=$(json_get_top "fallbackGroup")
	_fallback_current=$(json_get_top "fallbackCurrentConfig")
	_fallback_using_backup=$(json_get_top "fallbackUsingBackup")
	[ -n "$_fallback_group" ] || _fallback_group="all"
	[ -n "$_fallback_using_backup" ] || _fallback_using_backup="false"

	# ISP IP always available (doesn't need VPN)
	_isp_json=""
	if [ -f "$ISP_IP_FILE" ]; then
		_isp_json=$(cat "$ISP_IP_FILE" 2>/dev/null)
	fi
	if [ -z "$_isp_json" ] || ! echo "$_isp_json" | grep -q "query"; then
		_isp_json=$(get_isp_ip)
		[ -n "$_isp_json" ] && echo "$_isp_json" > "$ISP_IP_FILE" 2>/dev/null
	fi
	if [ -n "$_isp_json" ]; then
		_isp_ip_line=$(echo "$_isp_json" | tr ',' '\n' | grep '"query"' | cut -d'"' -f4)
		_isp_isp=$(echo "$_isp_json" | tr ',' '\n' | grep '"isp"' | cut -d'"' -f4)
		_isp_city=$(echo "$_isp_json" | tr ',' '\n' | grep '"city"' | cut -d'"' -f4)
		_isp_country=$(echo "$_isp_json" | tr ',' '\n' | grep '"country"' | cut -d'"' -f4)
		[ -n "$_isp_ip_line" ] && _isp_ip="🌐 $_isp_ip_line | $_isp_isp | $_isp_city | $_isp_country" || _isp_ip="-"
	fi

	if [ "$_status" = "Connected" ]; then
		# Parse full VPN IP JSON
		_vpn_json=""
		if [ -f "$VPN_IP_FILE" ]; then
			_vpn_json=$(cat "$VPN_IP_FILE" 2>/dev/null)
		fi
		if [ -z "$_vpn_json" ] || ! echo "$_vpn_json" | grep -q "query"; then
			_vpn_json=$(get_vpn_ip)
		fi
		if [ -n "$_vpn_json" ]; then
			_vpn_ip_line=$(echo "$_vpn_json" | tr ',' '\n' | grep '"query"' | cut -d'"' -f4)
			_vpn_isp=$(echo "$_vpn_json" | tr ',' '\n' | grep '"isp"' | cut -d'"' -f4)
			_vpn_city=$(echo "$_vpn_json" | tr ',' '\n' | grep '"city"' | cut -d'"' -f4)
			_vpn_country=$(echo "$_vpn_json" | tr ',' '\n' | grep '"country"' | cut -d'"' -f4)
			[ -n "$_vpn_ip_line" ] && _vpn_ip="🛡️ $_vpn_ip_line | $_vpn_isp | $_vpn_city | $_vpn_country" || _vpn_ip="-"
		fi

		if [ -f "$CFG_DIR/$_config_file" ]; then
			if is_wireguard_file "$CFG_DIR/$_config_file"; then
				_protocol="WG"
			else
				_lnk=$(head -n 1 "$CFG_DIR/$_config_file" 2>/dev/null | tr -d '\r\n')
				case "$_lnk" in
					vless://*)  _protocol="VLESS" ;;
					trojan://*) _protocol="Trojan" ;;
				esac
			fi
		fi
	fi

	# Uptime with users and load
	if [ -f /proc/uptime ]; then
		_secs=$(awk '{print int($1)}' /proc/uptime 2>/dev/null)
		_d=$((_secs / 86400))
		_h=$(((_secs % 86400) / 3600))
		_m=$(((_secs % 3600) / 60))
		_s=$((_secs % 60))
		_users=$(awk 'NR > 1 {print $1}' /proc/net/arp 2>/dev/null | wc -l)
		_load=$(cat /proc/loadavg 2>/dev/null | awk '{print $1}')
		_level="Low"
		[ -n "$_load" ] && awk "BEGIN{if($_load>1.0)exit 1;if($_load>0.5)exit 2}" 2>/dev/null
		_rc=$?
		[ $_rc -eq 1 ] && _level="High"
		[ $_rc -eq 2 ] && _level="Medium"
		_uptime_str="⏱️ Uptime: ${_d}d ${_h}h ${_m}m ${_s}s | 👨‍💻 Users: ${_users:-0} | ⚡ Load: ${_load:-0} ($_level)"
	else
		_uptime_str="-"
	fi

	# Memory
	_mem_str=$(free 2>/dev/null | awk '/Mem:/{printf "%.0fMB / %.0fMB", $3/1024, $2/1024}' 2>/dev/null)
	[ -z "$_mem_str" ] && _mem_str="-"
	[ "$_mem_str" != "-" ] && _mem_str="🧠 $_mem_str"

	# Network usage
	get_network_stats() {
		tx_bytes=$(cfg get flux_total_tx_bytes 2>/dev/null)
		rx_bytes=$(cfg get flux_total_rx_bytes 2>/dev/null)

		tx_bytes=${tx_bytes:-0}
		rx_bytes=${rx_bytes:-0}

		# Use awk to handle unit conversion and formatting
		stats=$(awk -v tx="$tx_bytes" -v rx="$rx_bytes" '
		function format(bytes) {
			mb = bytes / 1048576
			if (mb >= 1024) {
				gb = mb / 1024
				# Round to 1 decimal place
				gb = sprintf("%.1f", gb)
				return gb "GB"
			} else {
				return sprintf("%d", mb) "MB"
			}
		}
		BEGIN {
			tx_fmt = format(tx)
			rx_fmt = format(rx)
			print "📤 " tx_fmt " / 📥 " rx_fmt
		}')

		echo "$stats"
	}

	# Get network usage
	_usage_str=$(get_network_stats)
	
	if [ -z "$_usage_str" ]; then _usage_str="-"; fi

	_model=$(json_get "system" "model")
	if [ -z "$_model" ]; then _model="Unknown"; fi

	# License status. Do not mutate stored activation during periodic status refreshes;
	# device IDs can be temporarily unavailable during boot/network changes.
	_lic_key=$(json_get "license" "key")
	_lic_status=$(json_get "license" "status")
	if [ -z "$_lic_status" ]; then _lic_status="NOT_ACTIVE"; fi
	if [ "$_lic_status" = "INVALID" ] && verify_license "$_lic_key"; then
		_lic_status="ACTIVATED"
		json_set "license" "status" "ACTIVATED"
	fi

	_autorun=$(json_get_bool "vpn" "autorun")
	if [ "$_autorun" = "true" ]; then _autorun="on"; else _autorun="off"; fi

	_autofallback=$(json_get_bool "vpn" "autofallback")
	if [ "$_autofallback" = "true" ]; then _autofallback="on"; else _autofallback="off"; fi
	_watchdog_running="off"
	watchdog_running && _watchdog_running="on"

	_vpn_type_display="xray"
	if [ "$CORE" = "singbox" ]; then _vpn_type_display="singbox"; fi
	if [ -f "$CFG_DIR/$_config_file" ] && is_wireguard_file "$CFG_DIR/$_config_file"; then
		_vpn_type_display="singbox"
		MODE="tun"
	fi

	cat <<JSON
{
  "status": "$_status",
  "model": "$_model",
  "config_file": "$_config_file",
  "fallback_main_config": "$_fallback_main",
  "fallback_group": "$_fallback_group",
  "fallback_current_config": "$_fallback_current",
  "fallback_using_backup": "$_fallback_using_backup",
  "isp_ip": "${_isp_ip:-}",
  "vpn_ip": "${_vpn_ip:-}",
  "uptime": "$_uptime_str",
  "memory": "$_mem_str",
  "usage": "$_usage_str",
  "vpn_mode": "$MODE",
  "vpn_type": "$_vpn_type_display",
  "protocol": "$_protocol",
  "autorun": "$_autorun",
  "autofallback": "$_autofallback",
  "watchdog_running": "$_watchdog_running",
  "license_status": "$_lic_status"
}
JSON
}

# =============================================================================
# Settings – read or update app.json settings
# =============================================================================

do_settings() {
	_set_name=$(qs_get "set")

	if [ -z "$_set_name" ]; then
		content_json
		cat "$APP_JSON"
		return
	fi

	_val=$(qs_get "value")
	if [ -z "$_val" ]; then
		_val=$(bp_get "value")
	fi

	case "$_set_name" in
		active_config_group)
			if vpn_running || [ -f "$VPN_STARTING" ]; then
				content_json
				echo '{"status":"error","error":"Disconnect VPN before changing group"}'
				return
			fi
			_val=$(printf '%s' "$_val" | sed 's/[^a-zA-Z0-9_-]//g')
			[ -n "$_val" ] || _val="all"
			if [ "$_val" != "all" ] && [ ! -f "$GROUP_DIR/${_val}.group" ]; then
				_val="all"
			fi
			set_active_config_group "$_val"
			;;
		active_protocol)
			case "$_val" in
				wg|vless) json_set_top_ensure "activeProtocol" "$_val" ;;
				*)
					content_json
					echo '{"error":"Invalid protocol"}'
					return
					;;
			esac
			;;
		mode)
			json_set "vpn" "mode" "$_val"
			;;
		coretype)
			json_set "vpn" "coreType" "$_val"
			;;
		dns)
			json_set "network" "dns" "$_val"
			;;
		ipversion)
			json_set "network" "ipVersion" "$_val"
			;;
		ipresolve)
			if [ "$_val" = "on" ]; then
				json_set_bool "network" "ipResolve" "true"
			elif [ "$_val" = "off" ]; then
				json_set_bool "network" "ipResolve" "false"
			else
				_cur=$(json_get_bool "network" "ipResolve")
				if [ "$_cur" = "true" ]; then
					json_set_bool "network" "ipResolve" "false"
				else
					json_set_bool "network" "ipResolve" "true"
				fi
			fi
			;;
		autorun)
			if [ "$_val" = "on" ]; then
				json_set_bool "vpn" "autorun" "true"
			elif [ "$_val" = "off" ]; then
				json_set_bool "vpn" "autorun" "false"
			else
				_cur=$(json_get_bool "vpn" "autorun")
				if [ "$_cur" = "true" ]; then
					json_set_bool "vpn" "autorun" "false"
				else
					json_set_bool "vpn" "autorun" "true"
				fi
			fi
			;;
		autofallback)
			if [ "$_val" = "on" ]; then
				json_set_bool "vpn" "autofallback" "true"
				stop_watchdog
			elif [ "$_val" = "off" ]; then
				json_set_bool "vpn" "autofallback" "false"
				stop_watchdog
			else
				_cur=$(json_get_bool "vpn" "autofallback")
				if [ "$_cur" = "true" ]; then
					json_set_bool "vpn" "autofallback" "false"
					stop_watchdog
				else
					json_set_bool "vpn" "autofallback" "true"
					stop_watchdog
				fi
			fi
			;;
		*)
			content_json
			echo "{\"error\":\"Unknown setting: $_set_name\"}"
			return
			;;
	esac

	content_json
	echo "{\"status\":\"ok\",\"set\":\"$_set_name\"}"
}

# =============================================================================
# Logs
# =============================================================================

do_logs() {
	content_text
	if [ -f "$LOG_FILE" ]; then
		tail -n 100 "$LOG_FILE" 2>/dev/null
	else
		echo "No log file."
	fi
}

tcp_port_listening() {
	_port_hex=$(printf "%04X" "$1" 2>/dev/null)
	[ -n "$_port_hex" ] || return 1
	awk -v p="$_port_hex" '$2 ~ ":" p "$" && $4 == "0A" { found=1 } END { exit found ? 0 : 1 }' /proc/net/tcp 2>/dev/null
}

# =============================================================================
# Latency testing with caching
# =============================================================================

do_latency() {
	_force=$(qs_get "force")
	_lat_proto=$(qs_get "proto")
	case "$_lat_proto" in wg|vless) ;; *) _lat_proto="vless" ;; esac
	LAT_CACHE="/tmp/latency_cache_${_lat_proto}.json"
	_tries=$(qs_get "tries")
	case "$_tries" in
		[1-9]|10) ;;
		*) _tries=4 ;;
	esac

	_cache_complete=$(tail -n 1 "$LAT_CACHE" 2>/dev/null | tr -d '[:space:]')
	if [ "$_force" != "1" ] && [ -f "$LAT_CACHE" ] && [ "$_cache_complete" = "]" ]; then
		_now=$(date +%s 2>/dev/null || echo 0)
		_cache_age=$(stat -c %Y "$LAT_CACHE" 2>/dev/null || stat -f %m "$LAT_CACHE" 2>/dev/null || echo 0)
		if [ "$_now" != "0" ] && [ "$_cache_age" != "0" ] && [ $((_now - _cache_age)) -lt 300 ]; then
			content_json
			cat "$LAT_CACHE"
			return
		fi
	fi

	if ! do_latency_lock 30; then
		content_json
		echo '[{"error":"Latency test already running"}]'
		return
	fi

	content_json
	_lat_cache_tmp="${LAT_CACHE}.$$"
	_lat_cache_cleanup() {
		rm -f "$_lat_cache_tmp"
		do_latency_unlock
	}
	trap '_lat_cache_cleanup; exit' HUP INT TERM

	get_settings
	if [ "$_lat_proto" = "wg" ]; then
		_lat_bin="$SINGBOX"
		_lat_run="run -c"
	else
		_lat_bin="$XRAY_BIN"
		_lat_run="run -config"
		[ "$MODE" = "tun" ] && _lat_bin="$SINGBOX" && _lat_run="run -c"
		[ "$CORE" = "singbox" ] && _lat_bin="$SINGBOX" && _lat_run="run -c"
	fi
	_lat_curl=$(command -v curl 2>/dev/null || echo /bin/curl)

	_port=21000

	{
		echo "["
		_first=1
		for _f in "$CFG_DIR"/*.txt; do
			[ ! -f "$_f" ] && continue
			# Main VPN control takes priority over background latency scans.
			if [ -f "$VPN_STARTING" ] || vpn_running; then break; fi
			_file=$(basename "$_f")
			_first_line=$(head -n 1 "$_f" 2>/dev/null | tr -d '\r\n')
			if is_wireguard_file "$_f"; then _lnk=$(cat "$_f" 2>/dev/null | tr -d '\r'); else _lnk="$_first_line"; fi
			_latency="null"

			PARSED=$(parse_link "$_lnk")
			if [ -n "$PARSED" ] && [ "$PARSED" != "{}" ]; then
				_proto=$(parsed_get "proto")
				[ "$_proto" = "$_lat_proto" ] || continue
				_uuid=$(parsed_get "uuid")
				_host=$(parsed_get "host")
				_port_cfg=$(parsed_get_num "port")
				IPR="false"

				# Generate config using SAME generator as normal VPN connection.
				# Keep all inbounds valid, but move them to per-test ports to avoid conflicts.
				_config=""
				_redir_port=$((_port + 1000))
				if [ "$_proto" = "wg" ]; then
					_config=$(gen_singbox_wireguard_latency "$_port" "$DNS")
				elif [ "$_lat_bin" = "$SINGBOX" ]; then
					_config=$(gen_singbox_redirect "$_proto" "$_uuid" "$_host" "$_port_cfg" "$IPR" "$DNS")
					_config=$(echo "$_config" | sed "s|\"listen_port\": 1080|\"listen_port\": $_port|g")
					_config=$(echo "$_config" | sed "s|3131|$_redir_port|g")
				else
					_config=$(gen_xray_redirect "$_proto" "$_uuid" "$_host" "$_port_cfg" "$IPR" "$DNS")
					_config=$(echo "$_config" | sed "s|\"port\": 1080,|\"port\": $_port,|g")
					_config=$(echo "$_config" | sed "s|3131|$_redir_port|g")
				fi

				if [ -n "$_config" ] && [ -x "$_lat_bin" ] && [ -x "$_lat_curl" ]; then
					_tmpdir="/tmp/lat_${_port}"
					mkdir -p "$_tmpdir"
					echo "$_config" > "$_tmpdir/config.json"

					"$_lat_bin" $_lat_run "$_tmpdir/config.json" >/dev/null 2>&1 &
					_sb_pid=$!
					_i=0
					_http_code="000"
					_time_total=""
					while [ "$_i" -lt "$_tries" ]; do
						if ! kill -0 "$_sb_pid" 2>/dev/null; then
							break
						fi
						_probe=$("$_lat_curl" --socks5-hostname "127.0.0.1:$_port" -m 1 -s -o /dev/null -w "%{http_code} %{time_total}" http://www.gstatic.com/generate_204 2>/dev/null)
						_probe_code=$(echo "$_probe" | awk '{print $1}')
						_probe_time=$(echo "$_probe" | awk '{print $2}')
						if [ -n "$_probe_code" ] && [ "$_probe_code" != "000" ]; then
							_http_code="$_probe_code"
							_time_total="$_probe_time"
							break
						fi
						sleep 1
						_i=$((_i + 1))
					done

					if [ "$_http_code" != "000" ] && { [ -z "$_time_total" ] || [ "$_time_total" = "0.000000" ] || { [ "$_http_code" != "204" ] && [ "$_http_code" != "200" ]; }; }; then
						_curl_out=$("$_lat_curl" --socks5-hostname "127.0.0.1:$_port" -m 5 -s -o /dev/null -w "%{http_code} %{time_total}" http://cp.cloudflare.com/generate_204 2>/dev/null)
						_http_code=$(echo "$_curl_out" | awk '{print $1}')
						_time_total=$(echo "$_curl_out" | awk '{print $2}')
					fi

					kill "$_sb_pid" 2>/dev/null
					sleep 1
					kill -9 "$_sb_pid" 2>/dev/null
					rm -rf "$_tmpdir"

					if { [ "$_http_code" = "204" ] || [ "$_http_code" = "200" ]; } && [ -n "$_time_total" ] && [ "$_time_total" != "0.000000" ]; then
						_latency_val=$(awk "BEGIN {printf \"%.0f\", $_time_total * 1000}")
						if [ "$_latency_val" -ge 10 ] && [ "$_latency_val" -le 10000 ]; then
							_latency="$_latency_val"
						fi
					fi
				fi
			fi

			if [ "$_first" -ne 1 ]; then echo ","; fi
			_first=0
			printf '  {"file":"%s","latency":%s}' "$_file" "$_latency"
			_port=$((_port + 1))
		done
		echo ""
		echo "]"
	} > "$_lat_cache_tmp"
	if mv "$_lat_cache_tmp" "$LAT_CACHE"; then
		cat "$LAT_CACHE"
	else
		echo '[]'
	fi
	trap - HUP INT TERM
	do_latency_unlock
}

# =============================================================================
# Speedtest
# =============================================================================

do_speedtest() {
	_log_only=$(qs_get "log")

	if [ "$_log_only" = "1" ]; then
		content_text
		if [ -f "$SP_LOG" ]; then
			cat "$SP_LOG"
		else
			echo "No speedtest log."
		fi
		return
	fi

	content_text
	echo "Running speed test..."
	rm -f "$SP_TMP"

	_start=$(date +%s 2>/dev/null || awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)

	wget -q -O "$SP_TMP" --timeout=60 "http://speedtest.tele2.net/1MB.zip" 2>/dev/null

	_end=$(date +%s 2>/dev/null || awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)

	if [ -f "$SP_TMP" ]; then
		_size=$(wc -c < "$SP_TMP" 2>/dev/null || echo 0)
		rm -f "$SP_TMP"
		_elapsed=$((_end - _start))
		if [ "$_elapsed" -gt 0 ] && [ "$_size" -gt 0 ]; then
			_speed=$(awk "BEGIN{printf \"%.2f\", $_size * 8 / $_elapsed / 1000000}" 2>/dev/null)
			echo "Download: ${_speed} Mbps (${_size} bytes in ${_elapsed}s)"

			_ts=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "unknown")
			_entry="{\"time\":\"$_ts\",\"speed\":\"$_speed\",\"bytes\":$_size,\"elapsed\":$_elapsed}"
			if [ -f "$SP_LOG" ]; then
				_tmp_log="${SP_LOG}.tmp"
				sed '$d' "$SP_LOG" > "$_tmp_log" 2>/dev/null
				echo ",$_entry" >> "$_tmp_log"
				echo "]" >> "$_tmp_log"
				mv "$_tmp_log" "$SP_LOG"
			else
				echo "[$_entry]" > "$SP_LOG"
			fi
		else
			echo "Speedtest failed: timing issue"
		fi
	else
		echo "Speedtest failed: could not download test file"
	fi
}

# =============================================================================
# License
# =============================================================================

do_license_status() {
	content_json
	_key=$(json_get "license" "key")
	_issue_date=$(json_get "license" "issueDate")
	_status=$(json_get "license" "status")
	if [ -z "$_status" ]; then _status="NOT_ACTIVE"; fi

	cat <<JSON
{
  "license_key": "$_key",
  "issue_date": "$_issue_date",
  "status": "$_status"
}
JSON
}

do_gen_token() {
	content_text

	# Read device IDs (try cfg first since this is ZTE U50)
	_msn=$(cfg get modem_msn 2>/dev/null)
	_mac=$(cfg get wifi_mac_address 2>/dev/null)

	# Fallback: try app.json
	if [ -z "$_msn" ]; then _msn=$(json_get "system" "modemMsn"); fi
	if [ -z "$_mac" ]; then _mac=$(json_get "system" "wifiMac"); fi

	# Fallback: /sys/class/net
	if [ -z "$_mac" ]; then
		_mac=$(cat /sys/class/net/wlan0/address 2>/dev/null || cat /sys/class/net/eth0/address 2>/dev/null)
	fi

	if [ -z "$_msn" ] || [ -z "$_mac" ]; then
		echo "Error: unable to read device identifiers"
		return
	fi

	# Save to app.json
	sed "s|\"modemMsn\": \"[^\"]*\"|\"modemMsn\": \"$_msn\"|g" "$APP_JSON" > "${APP_JSON}.tmp" && mv "${APP_JSON}.tmp" "$APP_JSON"
	sed "s|\"wifiMac\": \"[^\"]*\"|\"wifiMac\": \"$_mac\"|g" "$APP_JSON" > "${APP_JSON}.tmp" && mv "${APP_JSON}.tmp" "$APP_JSON"

	# Generate 4-byte nonce
	if [ -r /dev/urandom ]; then
		_nonce=$(od -A n -N4 -t x1 /dev/urandom 2>/dev/null | tr -d ' \n')
	else
		_nonce=$(date +%s%N 2>/dev/null | head -c 8)
	fi
	if [ -z "$_nonce" ]; then _nonce="00000000"; fi

	# Format: MSN:xxx;MAC:xxx;NONCE:xxx then base64url encode
	_payload="MSN:$_msn;MAC:$_mac;NONCE:$_nonce"

	# Base64url encode (strip padding, replace +/ with -_)
	if command -v base64 >/dev/null 2>&1; then
		_token=$(printf "%s" "$_payload" | base64 2>/dev/null | tr '+/' '-_' | tr -d '=\n\r ')
	elif command -v openssl >/dev/null 2>&1; then
		_token=$(printf "%s" "$_payload" | openssl base64 -A 2>/dev/null | tr '+/' '-_' | tr -d '=')
	else
		# Fallback: raw payload
		_token="$_payload"
	fi

	echo "$_token"
}

do_validate_license() {
	_key=$(qs_get "key")
	if [ -z "$_key" ]; then
		_key=$(bp_get "license_key")
	fi
	if [ -z "$_key" ]; then
		content_text
		echo "ERROR: No license key provided"
		return
	fi

	_key=$(url_decode "$_key")

	content_text
	_pubkey="$LIC_DIR/public.pem"

	if [ ! -f "$_pubkey" ]; then
		echo "ERROR: public.pem not found"
		return
	fi

	# Get device identifiers
	_msn=$(cfg get modem_msn 2>/dev/null)
	_mac=$(cfg get wifi_mac_address 2>/dev/null)
	if [ -z "$_msn" ]; then _msn=$(json_get "system" "modemMsn"); fi
	if [ -z "$_mac" ]; then _mac=$(json_get "system" "wifiMac"); fi

	if [ -z "$_msn" ] || [ -z "$_mac" ]; then
		echo "ERROR: Cannot read device identifiers"
		return
	fi

	if [ ! -x "$VPN_VAL" ]; then
		echo "ERROR: vpn_validation binary not found"
		return
	fi

	_output=$("$VPN_VAL" "$_key" "$_pubkey" "$_msn" "$_mac" 2>&1)
	_ret=$?

	if echo "$_output" | grep -q "LICENSE VERIFIED"; then
		json_set "license" "key" "$_key"
		json_set "license" "issueDate" "$(date +%Y-%m-%d 2>/dev/null || echo '')"
		json_set "license" "status" "ACTIVATED"
		echo "SUCCESS: License activated successfully"
	else
		echo "ERROR: ${_output:-Invalid license key}"
	fi
}

# =============================================================================
# Version
# =============================================================================

do_version() {
	content_text
	_ver=$(json_get_top "version")
	echo "${_ver:-2.0.0}"
}

# Secure update manifest fields are flat strings so they can be parsed by BusyBox sh.
update_json_value() { grep -m1 "\"$2\"" "$1" 2>/dev/null | sed 's/^[^:]*:[[:space:]]*"\([^"]*\)".*/\1/'; }
update_download() {
	case "$1" in https://*) ;; *) return 1;; esac
	if command -v curl >/dev/null 2>&1; then curl -fL --connect-timeout 15 --max-time 300 -o "$2" "$1" >/dev/null 2>&1
	elif command -v wget >/dev/null 2>&1; then wget -q -O "$2" "$1"; else return 1; fi
}
update_verify_signature() { command -v openssl >/dev/null 2>&1 && [ -s "$1" ] && [ -s "$2" ] && openssl dgst -sha256 -verify "$LIC_DIR/public.pem" -signature "$2" "$1" >/dev/null 2>&1; }
update_sha256() { if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'; else openssl dgst -sha256 "$1" 2>/dev/null | sed 's/^.*= //'; fi; }
update_newer() { awk -v a="$1" -v b="$2" 'BEGIN { split(a, x, "."); split(b, y, "."); for (i=1; i<=4; i++) { if (x[i]+0 > y[i]+0) exit 0; if (x[i]+0 < y[i]+0) exit 1 } exit 1 }'; }
update_installed() {
	case "$1" in
		panel) json_get_top version;;
		xray) [ -x "$XRAY_BIN" ] && "$XRAY_BIN" version 2>/dev/null | head -1 | sed 's/^Xray[[:space:]]*//; s/[[:space:]]*(Xray.*$//';;
		singbox)
			[ -x "$SINGBOX" ] || return
			_sb_version=$($SINGBOX version 2>&1)
			_sb_first=$(printf '%s\n' "$_sb_version" | head -1 | sed 's/^sing-box version[[:space:]]*//')
			if [ "$_sb_first" = "unknown" ]; then
				_sb_revision=$(printf '%s\n' "$_sb_version" | sed -n 's/^Revision:[[:space:]]*//p' | head -1 | cut -c1-8)
				printf 'unknown%s\n' "${_sb_revision:+ ($_sb_revision)}"
			else
				printf '%s\n' "$_sb_first" | sed 's/^[^0-9]*\([0-9][0-9.]*\).*$/\1/'
			fi
			;;
	esac
}
update_manifest_valid() {
	update_verify_signature "$1" "$2" || return 1
	[ "$(update_json_value "$1" schema)" = 1 ] || return 1
	for c in panel xray singbox; do
		v=$(update_json_value "$1" "${c}_version"); [ -n "$v" ] || continue
		u=$(update_json_value "$1" "${c}_url"); h=$(update_json_value "$1" "${c}_sha256")
		case "$v" in *[!0-9.]*|.*|*.) return 1;; esac; case "$u" in https://*) ;; *) return 1;; esac
		echo "$h" | grep -Eq '^[0-9a-fA-F]{64}$' || return 1
	done
}
update_versions_json() {
	m="$1"; available=false; sep=""; printf '{'
	for c in panel xray singbox; do
		i=$(update_installed "$c"); v=""; [ -n "$m" ] && v=$(update_json_value "$m" "${c}_version")
		[ -n "$v" ] && update_newer "$v" "${i:-0}" && available=true
		printf '%s"%s":{"installed":"%s","available":"%s"}' "$sep" "$c" "$(json_escape "${i:-not installed}")" "$(json_escape "$v")"; sep=,
	done
	printf ',"update_available":%s}' "$available"
}
do_update_status() { content_json; update_versions_json ""; }
do_update_check() {
	mkdir -p "$UPDATE_DIR"; m="$UPDATE_DIR/update.json"; s="$UPDATE_DIR/update.json.sig"
	if ! update_download "$UPDATE_URL" "$m" || ! update_download "$UPDATE_URL.sig" "$s" || ! update_manifest_valid "$m" "$s"; then content_json; echo '{"status":"error","message":"Unable to fetch or verify update manifest"}'; return; fi
	content_json; printf '{"status":"success",'; update_versions_json "$m" | sed 's/^{//'
}
update_restore_protected() { for p in app.json configs config-groups license; do rm -rf "$BASE/$p"; [ -e "$1/protected/$p" ] && cp -a "$1/protected/$p" "$BASE/$p"; done; }
update_apply_package() {
	# Refuse traversal and payloads that could replace user data or the verification key.
	tar -tzf "$1" 2>/dev/null | grep -Eq '(^/|(^|/)\.\.(/|$)|^payload/(app\.json|configs|config-groups|license)(/|$)|^payload/\.update)' && return 1
	mkdir -p "$2/extract" && tar -xzf "$1" -C "$2/extract" && [ -d "$2/extract/payload" ] && tar -C "$2/extract/payload" -cf - . | tar -C "$BASE" -xf -
}
do_update_install() {
	source=$(bp_get source); [ -n "$source" ] || source=$(qs_get source); component=$(bp_get component); [ -n "$component" ] || component=$(qs_get component); case "$component" in panel|xray|singbox|all) ;; *) component=all;; esac; stage="$UPDATE_DIR/stage.$$"; failed=""
	rm -rf "$stage"; mkdir -p "$stage/packages" "$stage/protected" || failed=1; m="$stage/update.json"; s="$stage/update.json.sig"
	if [ "$source" = ota ]; then update_download "$UPDATE_URL" "$m" && update_download "$UPDATE_URL.sig" "$s" || failed=1
	elif [ "$source" = upload ] && [ -s "$UPDATE_UPLOAD" ]; then tar -tzf "$UPDATE_UPLOAD" 2>/dev/null | grep -Eq '(^/|(^|/)\.\.(/|$))' && failed=1; tar -xzf "$UPDATE_UPLOAD" -C "$stage" 2>/dev/null || failed=1
	else failed=1; fi
	if [ -n "$failed" ] || ! update_manifest_valid "$m" "$s"; then rm -rf "$stage"; content_json; echo '{"status":"error","message":"Offline bundle or manifest signature is invalid"}'; return; fi
	for c in panel xray singbox; do [ "$component" = all ] || [ "$component" = "$c" ] || continue
		v=$(update_json_value "$m" "${c}_version"); i=$(update_installed "$c"); [ -n "$v" ] && update_newer "$v" "${i:-0}" || continue; n="${c}-${v}.tar.gz"
		[ "$source" = ota ] && update_download "$(update_json_value "$m" "${c}_url")" "$stage/packages/$n" || [ -s "$stage/packages/$n" ] || failed=1
		[ "$(update_sha256 "$stage/packages/$n")" = "$(update_json_value "$m" "${c}_sha256")" ] || failed=1
	done
	if [ -n "$failed" ]; then rm -rf "$stage"; content_json; echo '{"status":"error","message":"Package download or SHA-256 verification failed"}'; return; fi
	cp -a "$BASE/." "$stage/backup" || failed=1; for p in app.json configs config-groups license; do [ -e "$BASE/$p" ] && cp -a "$BASE/$p" "$stage/protected/$p"; done
	for c in panel xray singbox; do [ "$component" = all ] || [ "$component" = "$c" ] || continue; v=$(update_json_value "$m" "${c}_version"); i=$(update_installed "$c"); [ -n "$v" ] && update_newer "$v" "${i:-0}" || continue; update_apply_package "$stage/packages/${c}-${v}.tar.gz" "$stage" || failed=1; rm -rf "$stage/extract"; done
	update_restore_protected "$stage" || failed=1
	if [ -n "$failed" ]; then rm -rf "$BASE"; mkdir -p "$BASE"; cp -a "$stage/backup/." "$BASE/"; rm -rf "$stage"; content_json; echo '{"status":"error","message":"Installation failed and was rolled back"}'; return; fi
	if [ "$component" = all ] || [ "$component" = panel ]; then panel_version=$(update_json_value "$m" panel_version); panel_installed=$(update_installed panel); [ -n "$panel_version" ] && update_newer "$panel_version" "${panel_installed:-0}" && json_set_top "version" "$panel_version"; fi
	rm -f "$UPDATE_UPLOAD"; rm -rf "$stage"; content_json; echo '{"status":"success","message":"Verified update installed"}'
}

# =============================================================================
# Main Dispatcher
# =============================================================================

ACTION=$(qs_get "action")

# Also check REQUEST_URI for path-based routing
if [ -z "$ACTION" ]; then
	case "$REQUEST_URI" in
		*/api/vpn/connect)    ACTION="connect" ;;
		*/api/vpn/disconnect) ACTION="disconnect" ;;
		*/api/status)         ACTION="status" ;;
		*/api/vpn/logs)       ACTION="logs" ;;
		*/api/latency)        ACTION="latency" ;;
		*/api/version)        ACTION="version" ;;
		*/api/speedtest)      ACTION="speedtest" ;;
		*/api/license/status) ACTION="license_status" ;;
		*/api/license/token)  ACTION="gen_token" ;;
		*/api/config/current) ACTION="config" ;;
	esac

	if [ "$REQUEST_METHOD" = "DELETE" ]; then
		ACTION="delete"
		_path_file=$(echo "$REQUEST_URI" | sed 's|.*/configs/||; s/\?.*//')
		QUERY_STRING="file=${_path_file}"
	fi

	if [ "$REQUEST_METHOD" = "POST" ]; then
		case "$REQUEST_URI" in
			*/api/configs/select) ACTION="select" ;;
			*/api/configs/apply)  ACTION="apply" ;;
			*/api/vpn/mode|*/api/vpn/coretype|*/api/vpn/autorun|*/api/vpn/autofallback|*/api/network/dns|*/api/network/ipresolve)
				ACTION="settings"
				;;
			*/api/license/validate) ACTION="validate_license" ;;
		esac
	fi
fi

if [ -z "$ACTION" ]; then
	content_json
	cat <<JSON
{"error":"No action specified","usage":"?action=settings|configs|config_detail|config_update|apply|select|delete|config|connect|disconnect|status|logs|latency|version|speedtest|license_status|gen_token|validate_license|update_status|update_check|update_install"}
JSON
	exit 0
fi

case "$ACTION" in
	settings)
		do_settings
		;;
	configs)
		do_configs
		;;
	config_detail)
		do_config_detail
		;;
	config_update)
		do_config_update
		;;
	groups)
		do_groups
		;;
	group_save)
		do_group_save
		;;
	group_delete)
		do_group_delete
		;;
	apply)
		do_apply
		;;
	select)
		do_select
		;;
	delete)
		do_delete
		;;
	config)
		do_config_view
		;;
	connect)
		do_lock "connect" 10 || { content_json; echo '{"status":"error","message":"Another operation in progress"}'; exit 0; }
		do_connect
		do_unlock
		;;
	disconnect)
		do_lock "disconnect" 10 || { content_json; echo '{"status":"error","message":"Another operation in progress"}'; exit 0; }
		do_disconnect
		do_unlock
		;;
	status)
		content_json
		do_status
		;;
	logs)
		do_logs
		;;
	latency)
		do_latency
		;;
	version)
		do_version
		;;
	speedtest)
		do_speedtest
		;;
	license_status)
		do_license_status
		;;
	gen_token)
		do_gen_token
		;;
	validate_license)
		do_validate_license
		;;
	update_status)
		do_update_status
		;;
	update_check)
		do_update_check
		;;
	update_install)
		do_lock "update" 10 || { content_json; echo '{"status":"error","message":"Another operation in progress"}'; exit 0; }
		do_update_install
		do_unlock
		;;
	*)
		content_json
		echo "{\"error\":\"Unknown action: $ACTION\"}"
		;;
esac

exit 0

#!/bin/sh

echo "Content-Type: text/plain"
echo ""

if echo "$QUERY_STRING" | grep -q "action=log"; then
    if [ -f "/tmp/speedtest.log" ]; then
        cat "/tmp/speedtest.log"
    else
        echo "No speedtest log found."
    fi
    exit 0
fi

result=$(curl -s -o /dev/null -w "Download: %{speed_download} bytes/sec\nUpload: %{speed_upload} bytes/sec\n" \
    --socks5-hostname 127.0.0.1:1080 \
    "http://speedtest.tele2.net/100MB.zip" \
    -m 15 -r 0-1048576 2>&1)

ts="[$(date '+%Y-%m-%d %H:%M:%S')]"
echo "$ts $result" >> /tmp/speedtest.log

echo "$ts"
echo "$result"

#!/bin/sh
# Raw package receiver: multipart parsing is avoided so BusyBox never corrupts binary data.
UPDATE_DIR="/tmp/zbox-update"
UPDATE_UPLOAD="$UPDATE_DIR/offline-bundle.tar.gz"

echo "Content-Type: application/json"
echo ""

[ "$REQUEST_METHOD" = "POST" ] || { echo '{"status":"error","message":"POST required"}'; exit 0; }
case "${HTTP_X_ZBOX_FILENAME:-}" in *.zbox) ;; *) echo '{"status":"error","message":"Only .zbox bundles are accepted"}'; exit 0 ;; esac
case "${CONTENT_LENGTH:-}" in ''|*[!0-9]*) echo '{"status":"error","message":"Invalid upload length"}'; exit 0 ;; esac
[ "$CONTENT_LENGTH" -gt 0 ] 2>/dev/null && [ "$CONTENT_LENGTH" -le 104857600 ] 2>/dev/null || { echo '{"status":"error","message":"Bundle must be 1 to 100 MB"}'; exit 0; }
mkdir -p "$UPDATE_DIR" || { echo '{"status":"error","message":"Cannot create upload area"}'; exit 0; }
umask 077
dd of="${UPDATE_UPLOAD}.tmp" bs=4096 count=$(( (CONTENT_LENGTH + 4095) / 4096 )) 2>/dev/null
[ "$(wc -c < "${UPDATE_UPLOAD}.tmp" 2>/dev/null)" = "$CONTENT_LENGTH" ] || { rm -f "${UPDATE_UPLOAD}.tmp"; echo '{"status":"error","message":"Incomplete upload"}'; exit 0; }
mv "${UPDATE_UPLOAD}.tmp" "$UPDATE_UPLOAD"
echo '{"status":"success","message":"Bundle uploaded"}'

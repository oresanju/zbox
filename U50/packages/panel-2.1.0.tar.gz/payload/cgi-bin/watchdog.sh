#!/bin/sh

APP_JSON="/bin/zbox/app.json"
APP_SH="/bin/zbox/cgi-bin/app.sh"
CFG_DIR="/bin/zbox/configs"
GROUP_DIR="/bin/zbox/config-groups"
LOCK_FILE="/tmp/vpn_watchdog.lock"
STOP_FILE="/tmp/vpn_watchdog.stop"
STATE_FILE="/tmp/vpn_watchdog_state"
LOG_FILE="/tmp/vpn_fallback.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

json_get_top() {
    grep "\"$1\":" "$APP_JSON" 2>/dev/null | head -1 | cut -d'"' -f4
}

json_get_bool() {
    grep -A20 "\"$1\":" "$APP_JSON" 2>/dev/null | grep "\"$2\":" | head -1 | grep -q true && echo true || echo false
}

check_connectivity() {
    curl --socks5-hostname 127.0.0.1:1080 -m 5 -s -o /dev/null -w "%{http_code}" \
        "http://www.gstatic.com/generate_204" 2>/dev/null
}

group_configs() {
    _group="$1"
    if [ -z "$_group" ] || [ "$_group" = "all" ] || [ ! -f "$GROUP_DIR/${_group}.group" ]; then
        for _cfg in "$CFG_DIR"/*.txt; do
            [ -f "$_cfg" ] && basename "$_cfg"
        done
    else
        tail -n +2 "$GROUP_DIR/${_group}.group" 2>/dev/null | while IFS= read -r _cfg; do
            [ -n "$_cfg" ] && [ -f "$CFG_DIR/$_cfg" ] && echo "$_cfg"
        done
    fi
}

switch_config() {
    _file="$1"
    [ -n "$_file" ] && [ -f "$CFG_DIR/$_file" ] || return 1
    log "Switching VPN to $_file"
    QUERY_STRING='action=disconnect&keep_watchdog=1' "$APP_SH" >/dev/null 2>&1
    QUERY_STRING="action=select&file=$_file" "$APP_SH" >/dev/null 2>&1
    QUERY_STRING='action=connect&keep_fallback=1' "$APP_SH" >/dev/null 2>&1
    return $?
}

pick_backup() {
    _group="$1"
    _main="$2"
    _current="$3"
    group_configs "$_group" | while IFS= read -r _cfg; do
        [ "$_cfg" = "$_main" ] && continue
        [ "$_cfg" = "$_current" ] && continue
        echo "$_cfg"
        break
    done
}

acquire_lock() {
    if [ -f "$LOCK_FILE" ]; then
        _pid=$(cat "$LOCK_FILE" 2>/dev/null)
        if [ -n "$_pid" ] && kill -0 "$_pid" 2>/dev/null; then
            exit 0
        fi
    fi
    rm -f "$STOP_FILE"
    echo $$ > "$LOCK_FILE"
}

release_lock() {
    rm -f "$LOCK_FILE"
}

trap 'log "Watchdog exiting"; release_lock' INT TERM EXIT

acquire_lock
log "Watchdog started (PID: $$)"

failCount=0
lastMainCheck=0

while true; do
    if [ -f "$STOP_FILE" ]; then
        log "Watchdog stop requested"
        exit 0
    fi

    autofallback=$(json_get_bool "vpn" "autofallback")
    if [ "$autofallback" != "true" ]; then
        sleep 10
        continue
    fi

    mainConfig=$(json_get_top "fallbackMainConfig")
    fallbackGroup=$(json_get_top "fallbackGroup")
    currentConfig=$(json_get_top "fallbackCurrentConfig")
    usingBackup=$(json_get_top "fallbackUsingBackup")
    selectedConfig=$(json_get_top "selectedConfig")

    [ -n "$mainConfig" ] || mainConfig="$selectedConfig"
    [ -n "$currentConfig" ] || currentConfig="$selectedConfig"
    [ -n "$fallbackGroup" ] || fallbackGroup="all"

    status_code=$(check_connectivity)

    if [ "$status_code" = "204" ]; then
        failCount=0

        if [ "$usingBackup" = "true" ]; then
            now=$(date +%s 2>/dev/null || echo 0)
            if [ "$now" -gt 0 ] && [ $((now - lastMainCheck)) -ge 600 ]; then
                lastMainCheck=$now
                log "Checking if main server is back: $mainConfig"
                if switch_config "$mainConfig"; then
                    sleep 5
                    main_status=$(check_connectivity)
                    if [ "$main_status" = "204" ]; then
                        log "Main server restored: $mainConfig"
                    else
                        log "Main still down, returning to backup: $currentConfig"
                        switch_config "$currentConfig"
                    fi
                fi
            fi
        fi
    else
        failCount=$((failCount + 1))
        log "Connection check failed ($failCount/3). HTTP status: ${status_code:-timeout}"

        if [ "$failCount" -ge 3 ]; then
            backupConfig=$(pick_backup "$fallbackGroup" "$mainConfig" "$currentConfig")
            if [ -n "$backupConfig" ]; then
                if switch_config "$backupConfig"; then
                    log "Fallback active: $backupConfig (group: $fallbackGroup, main: $mainConfig)"
                    currentConfig="$backupConfig"
                fi
            else
                log "No backup config available in group: $fallbackGroup"
            fi
            failCount=0
        fi
    fi

    echo "failCount=$failCount" > "$STATE_FILE"
    sleep 10
done

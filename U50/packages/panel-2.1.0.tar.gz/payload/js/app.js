/* ZBOX VPN Panel v2.0 - Frontend JS */
const API = 'cgi-bin/app.sh';

const ZBOX = {
  state: {
    lastStatus: 'Disconnected',
    logInterval: null,
    latencyCache: null,
    latencyCacheTime: 0,
    latencyRequest: null,
    latencyProtocol: null,
    configs: [],
    configGroups: [],
    activeConfigGroup: 'all',
    fallbackGroup: 'all',
    fallbackMainConfig: '',
    fallbackCurrentConfig: '',
    fallbackUsingBackup: 'false',
    autoFallback: 'off',
    licenseActive: false,
    theme: 'light',
    protocolMode: 'vless',
    pendingWireGuardConfig: '',
    updateUploadComponent: 'all'
  },

  async api(action, opts = {}) {
    const { method = 'GET', body, params = {} } = opts;
    const qs = new URLSearchParams({ action, ...params }).toString();
    const url = API + '?' + qs;
    const fetchOpts = { method };
    if (body) {
      fetchOpts.headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
      fetchOpts.body = body instanceof URLSearchParams ? body.toString() : body;
    }
    const r = await fetch(url, fetchOpts);
    const ct = r.headers.get('content-type') || '';
    if (ct.includes('application/json')) return r.json();
    return r.text();
  },

  vpnLocked() {
    return this.state.lastStatus === 'Connected' || this.state.lastStatus === 'Connecting';
  },

  async init() {
    this.applyTheme();
    this.bindEvents();
    this.setupCollapsible();
    await this.loadSettings();
    this.setProtocolMode(this.state.protocolMode);
    this.refreshStatus();
    this.fetchVersion();
    this.checkLicense();
    setInterval(() => this.refreshStatus(), 5000);
    this.loadConfigs();
  },

  async loadSettings() {
    try {
      const s = await this.api('settings');
      this.applySettingsToUI(s);
    } catch (e) { console.log('Settings fallback'); }
  },

  applySettingsToUI(s) {
    const mode = s.vpn?.mode || 'redirect';
    const coreType = s.vpn?.coreType || 'xray';
    const dns = s.network?.dns || 'cloudflare';
    const ipv = s.network?.ipVersion || 'prefer_ipv4';
    const ipr = s.network?.ipResolve === true || s.network?.ipResolve === 'on';
    this.state.activeConfigGroup = s.activeConfigGroup || 'all';
    this.state.protocolMode = s.activeProtocol === 'wg' ? 'wg' : 'vless';

    document.querySelectorAll('input[name="vpn-mode"]').forEach(r => { r.checked = r.value === mode; });
    document.querySelectorAll('input[name="redirect-engine"]').forEach(r => { r.checked = r.value === coreType; });
    const dnsEl = document.getElementById('dns-select');
    if (dnsEl) dnsEl.value = dns;
    document.querySelectorAll('input[name="ipversion"]').forEach(r => { r.checked = r.value === ipv; });
    const irToggle = document.getElementById('ip-resolve-toggle');
    if (irToggle) irToggle.checked = ipr;
    this.updateToggleLabel('ip-resolve');
    const engineCtr = document.getElementById('redirect-engine-container');
    if (engineCtr) engineCtr.style.display = mode === 'redirect' ? 'block' : 'none';
  },

  bindEvents() {
    document.getElementById('theme-toggle').addEventListener('click', (e) => { e.stopPropagation(); this.toggleTheme(); });
    document.getElementById('apply').addEventListener('click', (e) => { e.preventDefault(); this.applyConfig(); });
    document.getElementById('manual-vless').addEventListener('click', () => this.openManualVlessEditor());
    document.querySelectorAll('.protocol-pills [data-protocol]').forEach(btn => {
      btn.addEventListener('click', () => this.setProtocolMode(btn.dataset.protocol, true));
    });
    document.getElementById('connect').addEventListener('click', (e) => { e.preventDefault(); if (!e.target.disabled) this.doConnect(); });
    document.getElementById('disconnect').addEventListener('click', (e) => { e.preventDefault(); if (!e.target.disabled) this.doDisconnect(); });

    document.getElementById('autorun-toggle').addEventListener('change', function() {
      const on = this.checked;
      const label = this.closest('.toggle-wrap').querySelector('.toggle-label');
      const sub = this.closest('.toggle-wrap').querySelector('.tile-labels span');
      if (label) { label.textContent = 'Autorun: ' + (on ? 'ON' : 'OFF'); label.className = 'toggle-label ' + (on ? 'on' : 'off'); }
      if (sub) sub.textContent = on ? 'ON' : 'OFF';
      ZBOX.api('settings', { params: { set: 'autorun', value: on ? 'on' : 'off' } }).catch(e => console.error('autorun API error:', e));
    });
    document.getElementById('autofallback-toggle').addEventListener('change', function() {
      const on = this.checked;
      const label = this.closest('.toggle-wrap').querySelector('.toggle-label');
      const sub = this.closest('.toggle-wrap').querySelector('.tile-labels span');
      if (label) { label.textContent = 'Auto Fallback: ' + (on ? 'ON' : 'OFF'); label.className = 'toggle-label ' + (on ? 'on' : 'off'); }
      if (sub) sub.textContent = on ? 'ON' : 'OFF';
      ZBOX.api('settings', { params: { set: 'autofallback', value: on ? 'on' : 'off' } }).catch(e => console.error('autofallback API error:', e));
    });
    document.getElementById('ip-resolve-toggle').addEventListener('change', function() {
      ZBOX.updateToggleLabel('ip-resolve');
      ZBOX.api('settings', { params: { set: 'ipresolve', value: this.checked ? 'on' : 'off' } }).catch(e => console.error('ipresolve API error:', e));
    });

    document.getElementById('toggle-log').addEventListener('click', () => this.toggleLogs());
    document.getElementById('sing-box-log').addEventListener('click', () => this.toggleLogSize());

    document.getElementById('show-config-link').addEventListener('click', (e) => {
      e.preventDefault();
      const link = document.getElementById('show-config-link');
      if (link.textContent === '[View]') { this.showConfig(); }
      else { document.getElementById('config-panel-row').style.display = 'none'; link.textContent = '[View]'; }
    });
    document.getElementById('speedtest-link').addEventListener('click', (e) => { e.preventDefault(); this.runSpeedTest(); });
    document.getElementById('close-config').addEventListener('click', () => {
      document.getElementById('config-panel-row').style.display = 'none';
      document.getElementById('show-config-link').textContent = '[View]';
      document.getElementById('config-json-text').textContent = '';
      document.getElementById('speedtest-result').textContent = '';
    });

    document.querySelectorAll('input[name="vpn-mode"]').forEach(r => {
      r.addEventListener('change', function() {
        document.getElementById('vpn-mode-text').textContent = this.value.toUpperCase();
        document.getElementById('redirect-engine-container').style.display = ZBOX.state.protocolMode === 'wg' ? 'none' : (this.value === 'redirect' ? 'block' : 'none');
        ZBOX.api('settings', { params: { set: 'mode', value: this.value } });
      });
    });
    document.querySelectorAll('input[name="redirect-engine"]').forEach(r => {
      r.addEventListener('change', function() {
        ZBOX.api('settings', { params: { set: 'coretype', value: this.value } });
      });
    });

    document.getElementById('dns-select').addEventListener('change', function() {
      ZBOX.api('settings', { params: { set: 'dns', value: this.value } });
    });
    document.querySelectorAll('input[name="ipversion"]').forEach(r => {
      r.addEventListener('change', function() {
        ZBOX.api('settings', { params: { set: 'ipversion', value: this.value } });
      });
    });

    document.getElementById('suggest-best').addEventListener('click', () => this.suggestBest());
    document.getElementById('add-config-group').addEventListener('click', () => {
      if (this.vpnLocked()) { this.showToast('Disconnect VPN before editing groups', 'warning'); return; }
      this.openConfigGroupModal();
    });
    document.getElementById('cancel-config-group').addEventListener('click', () => this.closeConfigGroupModal());
    document.getElementById('save-config-group').addEventListener('click', () => this.saveConfigGroup());
    document.getElementById('delete-config-group').addEventListener('click', () => this.deleteConfigGroup());
    document.getElementById('group-select-all').addEventListener('click', () => {
      document.querySelectorAll('#config-group-checklist input[type="checkbox"]').forEach(c => { c.checked = true; });
    });
    document.getElementById('group-clear-all').addEventListener('click', () => {
      document.querySelectorAll('#config-group-checklist input[type="checkbox"]').forEach(c => { c.checked = false; });
    });
    document.getElementById('cancel-vless-editor').addEventListener('click', () => this.closeVlessEditor());
    document.getElementById('save-vless-editor').addEventListener('click', () => this.saveVlessEditor());
    ['ve-alias','ve-uuid','ve-host','ve-port','ve-transport','ve-security','ve-path','ve-host-header','ve-xhttp-mode','ve-sni','ve-allow-insecure','ve-fp','ve-pbk','ve-sid','ve-flow'].forEach(id => {
      document.getElementById(id).addEventListener('input', () => this.refreshVlessEditor());
      document.getElementById(id).addEventListener('change', () => this.refreshVlessEditor());
    });
    document.getElementById('cancel-license').addEventListener('click', () => this.hideLicenseModal());
    document.getElementById('validate-license').addEventListener('click', () => this.validateLicenseForm());
    document.getElementById('copy-token').addEventListener('click', () => this.copyToken());
    document.getElementById('close-license-info').addEventListener('click', () => this.hideLicenseModal());
    document.getElementById('license-status').addEventListener('click', () => this.showLicenseModal());
    document.getElementById('open-update-center').addEventListener('click', () => this.openUpdateCenter());
    document.getElementById('close-update').addEventListener('click', () => this.closeUpdateCenter());
    document.getElementById('check-update').addEventListener('click', () => this.checkForUpdates());
    const dropzone = document.getElementById('offline-dropzone');
    dropzone.addEventListener('click', () => document.getElementById('offline-package').click());
    dropzone.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); document.getElementById('offline-package').click(); } });
    ['dragenter', 'dragover'].forEach(type => dropzone.addEventListener(type, e => { e.preventDefault(); dropzone.classList.add('dragover'); }));
    ['dragleave', 'drop'].forEach(type => dropzone.addEventListener(type, e => { e.preventDefault(); dropzone.classList.remove('dragover'); }));
    dropzone.addEventListener('drop', e => this.uploadOfflineUpdate(e.dataTransfer.files[0], this.state.updateUploadComponent));
    document.getElementById('offline-package').addEventListener('change', (e) => this.uploadOfflineUpdate(e.target.files[0], this.state.updateUploadComponent));
    document.getElementById('cancel-wireguard-name').addEventListener('click', () => this.closeWireGuardNameModal());
    document.getElementById('save-wireguard-name').addEventListener('click', () => this.saveWireGuardConfig());
  },

  setProtocolMode(mode, persist = false) {
    const previousMode = this.state.protocolMode;
    this.state.protocolMode = mode === 'wg' ? 'wg' : 'vless';
    const isWg = this.state.protocolMode === 'wg';
    if (previousMode !== this.state.protocolMode) this.state.activeConfigGroup = 'all';
    if (persist && previousMode !== this.state.protocolMode) {
      this.api('settings', { params: { set: 'active_protocol', value: this.state.protocolMode } }).catch(() => {});
    }
    document.querySelectorAll('.protocol-pills [data-protocol]').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.protocol === this.state.protocolMode);
    });
    document.getElementById('vpn-input-label').textContent = isWg ? 'Paste your WireGuard config:' : 'Paste your VPN link:';
    document.getElementById('vless').placeholder = isWg ? '[Interface]\nPrivateKey = ...\nAddress = ...\n\n[Peer]\nPublicKey = ...\nEndpoint = host:51820' : 'vless://...';
    document.getElementById('manual-vless').style.display = isWg ? 'none' : '';
    document.querySelectorAll('.vless-setting').forEach(el => { el.style.display = isWg ? 'none' : ''; });
    if (!isWg) {
      const mode = document.querySelector('input[name="vpn-mode"]:checked')?.value || 'redirect';
      document.getElementById('redirect-engine-container').style.display = mode === 'redirect' ? 'block' : 'none';
    }
    this.renderConfigGroupTabs();
    this.renderConfigCards();
    if (previousMode !== this.state.protocolMode && this.state.configs.length) this.fetchLatency();
  },

  setupCollapsible() {
    document.querySelectorAll('.card-header').forEach(header => {
      header.addEventListener('click', function(e) {
        if (this.classList.contains('static-card-header')) return;
        e.stopPropagation();
        const card = this.closest('.card');
        const body = card.querySelector('.card-body');
        const arrow = this.querySelector('.arrow');
        if (card.classList.contains('status-card') && card.classList.contains('connected-summary')) {
          card.classList.remove('connected-summary');
          if (arrow) arrow.classList.remove('open');
          return;
        }
        const title = this.querySelector('h2')?.textContent.trim();
        if (title === 'VPN Setting') {
          const ss = card.querySelector('.settings-section');
          if (ss) ss.style.display = ss.style.display === 'none' ? '' : 'none';
          arrow.classList.toggle('open');
        } else {
          if (body.style.display === 'none') { body.style.display = 'block'; arrow.classList.remove('open'); }
          else { body.style.display = 'none'; arrow.classList.add('open'); }
        }
      });
    });
  },

  applyTheme() {
    const saved = localStorage.getItem('zbox-theme');
    const toggle = document.getElementById('theme-toggle');
    if (saved === 'dark') {
      document.body.classList.add('dark');
      if (toggle) toggle.className = 'theme-toggle dark-mode';
      this.state.theme = 'dark';
    } else {
      document.body.classList.remove('dark');
      if (toggle) toggle.className = 'theme-toggle light';
      this.state.theme = 'light';
    }
  },

  toggleTheme() {
    const toggle = document.getElementById('theme-toggle');
    if (this.state.theme === 'light') {
      document.body.classList.add('dark');
      if (toggle) toggle.className = 'theme-toggle dark-mode';
      this.state.theme = 'dark';
      localStorage.setItem('zbox-theme', 'dark');
    } else {
      document.body.classList.remove('dark');
      if (toggle) toggle.className = 'theme-toggle light';
      this.state.theme = 'light';
      localStorage.setItem('zbox-theme', 'light');
      if (label) label.textContent = 'Light';
    }
  },

  async doConnect() {
    const btn = document.getElementById('connect');
    const orig = btn.textContent;
    btn.disabled = true; btn.textContent = 'Connecting...';
    try {
      const isActive = await this.checkLicense();
      if (!isActive) { this.showToast('License not activated', 'error'); setTimeout(() => this.showLicenseModal(), 1000); return; }
      const data = await this.api('connect', { method: 'POST' });
      if (data.status === 'success') {
        document.getElementById('vpn-status').textContent = 'Connected';
        document.getElementById('vpn-status').style.color = 'green';
        this.updateButtons('Connected');
        this.refreshStatus();
      } else {
        this.showToast(data.message || 'Connection failed', 'error');
      }
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { setTimeout(() => { btn.disabled = false; btn.textContent = orig; }, 2000); }
  },

  async doDisconnect() {
    const btn = document.getElementById('disconnect');
    const orig = btn.textContent;
    btn.disabled = true; btn.textContent = 'Disconnecting...';
    try {
      await this.api('disconnect', { method: 'POST' });
      document.getElementById('vpn-status').textContent = 'Disconnected';
      document.getElementById('vpn-status').style.color = 'red';
      document.getElementById('vpn-ip').textContent = '-';
      document.getElementById('isp-ip').textContent = '-';
      document.getElementById('speedtest-link').style.display = 'none';
      if (this.state.logInterval) clearInterval(this.state.logInterval);
      this.updateButtons('Disconnected');
      document.querySelector('.card_icon').style.display = 'none';
      document.getElementById('vpn-icons-container').style.display = 'none';
      this.refreshStatus();
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { setTimeout(() => { btn.disabled = false; btn.textContent = orig; }, 2000); }
  },

  updateButtons(status) {
    const c = document.getElementById('connect');
    const d = document.getElementById('disconnect');
    const best = document.getElementById('suggest-best');
    c.classList.remove('btn-primary', 'btn-success');
    d.classList.remove('btn-danger');
    if (status === 'Connected') {
      c.style.display = 'none'; d.style.display = '';
      c.disabled = true; d.disabled = false; d.classList.add('btn-danger');
      if (best) best.style.display = 'none';
    }
    else if (status === 'Connecting') {
      c.style.display = ''; d.style.display = 'none';
      c.disabled = true; d.disabled = true; c.classList.add('btn-success');
      if (best) best.style.display = 'none';
    }
    else {
      c.style.display = ''; d.style.display = 'none';
      c.disabled = false; c.classList.add('btn-success'); d.disabled = true;
      if (best) best.style.display = '';
    }
  },

  async applyConfig() {
    const link = document.getElementById('vless').value.trim();
    const isWg = this.state.protocolMode === 'wg';
    if (!link) { this.showToast(isWg ? 'Paste a WireGuard config' : 'Paste a VPN link', 'warning'); return; }
    if (isWg) {
      this.openWireGuardNameModal(link);
      return;
    }
    await this.submitConfig(link, 'vless');
  },

  async submitConfig(link, proto, configName = '') {
    try {
      const data = await this.api('apply', { method: 'POST', body: new URLSearchParams({ link, proto, config_name: configName }) });
      if (data.status === 'ok') {
        this.showToast('Saved: ' + data.alias, 'success');
        this.detectProtocol(link);
        document.getElementById('vless').value = '';
        this.loadConfigs();
      } else { this.showToast('Error: ' + (data.error || ''), 'error'); }
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
  },

  openWireGuardNameModal(link) {
    this.state.pendingWireGuardConfig = link;
    const input = document.getElementById('wireguard-config-name');
    input.value = '';
    document.getElementById('wireguard-name-modal').classList.add('show');
    setTimeout(() => input.focus(), 0);
  },

  closeWireGuardNameModal() {
    this.state.pendingWireGuardConfig = '';
    document.getElementById('wireguard-name-modal').classList.remove('show');
  },

  async saveWireGuardConfig() {
    const name = document.getElementById('wireguard-config-name').value.replace(/[\r\n]/g, ' ').trim();
    if (!name) { this.showToast('Enter a WireGuard config name', 'warning'); return; }
    const link = this.state.pendingWireGuardConfig;
    this.closeWireGuardNameModal();
    await this.submitConfig(link, 'wg', name);
  },

  async loadConfigs(latencyData) {
    const cnt = document.getElementById('config-list');
    cnt.innerHTML = '<div style="padding:10px;color:var(--text-muted)">Loading...</div>';
    try {
      const [configs, groups] = await Promise.all([this.api('configs'), this.api('groups')]);
      this.state.configs = Array.isArray(configs) ? configs : [];
      this.state.configGroups = Array.isArray(groups) ? groups : [];
      const validTabs = ['all', ...this.state.configGroups.map(g => g.id)];
      if (!validTabs.includes(this.state.activeConfigGroup)) this.state.activeConfigGroup = 'all';
      this.renderConfigGroupTabs();
      this.renderConfigCards();
      if (latencyData && Array.isArray(latencyData)) { this.updateLatencies(latencyData); }
      else { this.fetchLatency(); }
    } catch (e) { cnt.textContent = 'Failed to load configs'; }
  },

  configsForActiveGroup() {
    const proto = this.state.protocolMode === 'wg' ? 'wg' : 'vless';
    const protocolConfigs = this.state.configs.filter(c => c.proto === proto);
    if (this.state.activeConfigGroup === 'all') return protocolConfigs;
    const group = this.state.configGroups.find(g => g.id === this.state.activeConfigGroup);
    const members = new Set(group?.configs || []);
    return protocolConfigs.filter(c => members.has(c.file));
  },

  renderConfigCards() {
    const cnt = document.getElementById('config-list');
    const configs = this.configsForActiveGroup();
    cnt.innerHTML = '';
    const protocolConfigs = this.state.configs.filter(c => c.proto === (this.state.protocolMode === 'wg' ? 'wg' : 'vless'));
    if (!protocolConfigs.length) {
      cnt.innerHTML = `<div style="grid-column:1/-1;padding:10px;color:var(--text-muted)">No ${this.state.protocolMode === 'wg' ? 'WireGuard' : 'VLESS'} configs yet. Paste a config and click Apply.</div>`;
      return;
    }
    if (!configs.length) {
      cnt.innerHTML = '<div style="grid-column:1/-1;padding:10px;color:var(--text-muted)">No configs in this group.</div>';
      return;
    }
    configs.forEach(cfg => {
        const card = document.createElement('div');
        card.className = 'config-card';
        card.dataset.file = cfg.file;
        const connected = this.vpnLocked();
        const fallbackOn = this.state.autoFallback === 'on';
        const isMain = connected && cfg.file === this.state.fallbackMainConfig;
        const isCurrent = connected && cfg.file === this.state.fallbackCurrentConfig;
        const role = fallbackOn && connected ? (isMain ? '<span class="config-role main">MAIN</span>' : '<span class="config-role backup">BACKUP</span>') : '';
        if (isCurrent) card.classList.add('current');
        const active = isCurrent ? '<span class="config-active">ACTIVE</span>' : '';
        const protoLabel = cfg.proto === 'wg' ? 'WG' : cfg.proto.toUpperCase();
        card.innerHTML = `<div class="name">${this.esc(cfg.alias)}</div><div class="meta"><span class="proto ${cfg.proto}">${protoLabel}</span>${role}${active}<span class="latency" id="lat-${this.escId(cfg.file)}"></span></div><button class="edit-btn" type="button" title="Edit config">&#9998;</button><button class="close-btn" type="button" title="Delete config">×</button>`;
        if (cfg.proto === 'wg') card.querySelector('.edit-btn').style.display = 'none';
        card.addEventListener('click', (e) => { if (!e.target.closest('button')) this.selectConfig(cfg); });
        card.querySelector('.edit-btn').addEventListener('click', (e) => {
          e.stopPropagation();
          if (this.vpnLocked()) { this.showToast('Disconnect VPN before editing servers', 'warning'); return; }
          if (cfg.proto === 'wg') { this.showToast('WireGuard edit is not available yet', 'info'); return; }
          this.openVlessEditor(cfg.file);
        });
        card.querySelector('.close-btn').addEventListener('click', (e) => {
          e.stopPropagation();
          if (this.vpnLocked()) { this.showToast('Disconnect VPN before deleting servers', 'warning'); return; }
          if (confirm('Delete ' + cfg.file + '?')) this.deleteConfig(cfg.file, card);
        });
        cnt.appendChild(card);
    });
    if (Array.isArray(this.state.latencyCache)) this.updateLatencies(this.state.latencyCache);
  },

  renderConfigGroupTabs() {
    const tabs = document.getElementById('config-group-tabs');
    const connected = this.vpnLocked();
    const addBtn = document.getElementById('add-config-group');
    if (addBtn) addBtn.style.display = connected ? 'none' : '';
    let definitions = [
      { id: 'all', name: 'ALL', count: this.configsForProtocol().length, system: true },
      ...this.state.configGroups.map(g => ({ ...g, count: (g.configs || []).filter(f => this.configsForProtocol().some(c => c.file === f)).length }))
    ];
    definitions = definitions.filter(group => group.system || group.count > 0 || group.id === this.state.activeConfigGroup);
    if (connected) definitions = definitions.filter(group => group.id === this.state.activeConfigGroup);
    tabs.innerHTML = '';
    definitions.forEach(group => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'config-group-tab' + (group.id === this.state.activeConfigGroup ? ' active' : '') + (connected ? ' locked' : '');
      btn.disabled = connected;
      btn.innerHTML = `${this.esc(group.name)} <span class="group-count">(${group.count})</span>${group.system ? '' : '<span class="group-edit" title="Edit group">&#9998;</span>'}`;
      btn.addEventListener('click', e => {
        if (connected) { this.showToast('Disconnect VPN before changing group', 'warning'); return; }
        if (!group.system && e.target.closest('.group-edit')) { this.openConfigGroupModal(group.id); return; }
        this.selectConfigGroup(group.id);
      });
      tabs.appendChild(btn);
    });
  },

  configsForProtocol() {
    const proto = this.state.protocolMode === 'wg' ? 'wg' : 'vless';
    return this.state.configs.filter(c => c.proto === proto);
  },

  async selectConfigGroup(id) {
    if (this.vpnLocked()) { this.showToast('Disconnect VPN before changing group', 'warning'); return; }
    this.state.activeConfigGroup = id;
    this.renderConfigGroupTabs();
    this.renderConfigCards();
    try { await this.api('settings', { params: { set: 'active_config_group', value: id } }); } catch (e) {}
  },

  openConfigGroupModal(id = '') {
    if (this.vpnLocked()) { this.showToast('Disconnect VPN before editing groups', 'warning'); return; }
    const group = this.state.configGroups.find(g => g.id === id);
    document.getElementById('config-group-modal-title').textContent = group ? 'Edit Config Group' : 'Add Config Group';
    document.getElementById('config-group-id').value = group?.id || '';
    document.getElementById('config-group-name').value = group?.name || '';
    document.getElementById('delete-config-group').style.display = group ? 'inline-flex' : 'none';
    const selected = new Set(group?.configs || []);
    const list = document.getElementById('config-group-checklist');
    list.innerHTML = '';
    const protocolConfigs = this.configsForProtocol();
    if (!protocolConfigs.length) {
      list.innerHTML = '<div style="padding:12px;color:var(--text-muted)">No configurations available.</div>';
    } else {
      protocolConfigs.forEach(cfg => {
        const label = document.createElement('label');
        label.className = 'config-group-check-item';
        const check = document.createElement('input');
        check.type = 'checkbox'; check.value = cfg.file; check.checked = selected.has(cfg.file);
        const name = document.createElement('span');
        name.textContent = `${cfg.alias} (${cfg.proto.toUpperCase()})`;
        label.append(check, name);
        list.appendChild(label);
      });
    }
    document.getElementById('config-group-modal').classList.add('show');
    setTimeout(() => document.getElementById('config-group-name').focus(), 0);
  },

  closeConfigGroupModal() {
    document.getElementById('config-group-modal').classList.remove('show');
  },

  async saveConfigGroup() {
    const id = document.getElementById('config-group-id').value;
    const name = document.getElementById('config-group-name').value.trim();
    if (!name) { this.showToast('Enter a group name', 'warning'); return; }
    const files = [...document.querySelectorAll('#config-group-checklist input:checked')].map(c => c.value);
    const btn = document.getElementById('save-config-group');
    btn.disabled = true;
    try {
      const form = new URLSearchParams({ id, name });
      files.forEach(file => form.append('file', file));
      const data = await this.api('group_save', { method: 'POST', body: form });
      if (data.status !== 'ok') throw new Error(data.error || 'Could not save group');
      this.state.activeConfigGroup = data.id;
      await this.api('settings', { params: { set: 'active_config_group', value: data.id } });
      this.closeConfigGroupModal();
      await this.loadConfigs(this.state.latencyCache);
      this.showToast(id ? 'Group updated' : 'Group created', 'success');
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { btn.disabled = false; }
  },

  async deleteConfigGroup() {
    const id = document.getElementById('config-group-id').value;
    const group = this.state.configGroups.find(g => g.id === id);
    if (!id || !confirm(`Delete group "${group?.name || id}"? Config files will not be deleted.`)) return;
    try {
      const data = await this.api('group_delete', { method: 'POST', body: new URLSearchParams({ id }) });
      if (data.status !== 'ok') throw new Error(data.error || 'Could not delete group');
      this.state.activeConfigGroup = 'all';
      this.closeConfigGroupModal();
      await this.loadConfigs(this.state.latencyCache);
      this.showToast('Group deleted', 'info');
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
  },

  async selectConfig(cfg) {
    if (this.vpnLocked()) { this.showToast('Disconnect VPN before changing server', 'warning'); return; }
    const vpnMode = document.querySelector('input[name="vpn-mode"]:checked')?.value || 'redirect';
    const dnsType = document.getElementById('dns-select')?.value || 'cloudflare';
    const ipVersion = document.querySelector('input[name="ipversion"]:checked')?.value || 'prefer_ipv4';
    const ipResolve = document.getElementById('ip-resolve-toggle')?.checked ? 'on' : 'off';
    try {
      const data = await this.api('select', { method: 'POST', body: new URLSearchParams({ file: cfg.file, vpn_mode: vpnMode, dns_type: dnsType, ip_version: ipVersion, ip_resolve: ipResolve }) });
      if (data.status === 'ok') {
        document.getElementById('config-file').textContent = 'config.json #' + cfg.alias;
        document.getElementById('show-config-link').style.display = 'inline';
        this.showToast(data.message ? this.stripTxt(data.message) : 'Config selected', 'success');
      } else {
        document.getElementById('config-file').textContent = '-';
        document.getElementById('show-config-link').style.display = 'none';
        document.getElementById('speedtest-link').style.display = 'none';
        this.showToast(data.error || 'Failed', 'error');
      }
    } catch (e) {
      document.getElementById('config-file').textContent = '-';
      this.showToast('Error: ' + e.message, 'error');
    }
  },

  async deleteConfig(file, cardEl) {
    try {
      const data = await this.api('delete', { params: { file } });
      if (data.success) { await this.loadConfigs(this.state.latencyCache); this.showToast('Deleted', 'info'); }
      else { alert('Failed: ' + data.error); }
    } catch (e) { alert('Network error'); }
  },

  vlessField(id) { return document.getElementById('ve-' + id); },

  setVlessForm(parsed = {}, mode = 'edit') {
    this.vlessField('alias').value = parsed.alias || '';
    this.vlessField('uuid').value = parsed.uuid || '';
    this.vlessField('host').value = parsed.host || '';
    this.vlessField('port').value = parsed.port || '443';
    this.vlessField('transport').value = parsed.network || 'tcp';
    this.vlessField('security').value = parsed.security || 'none';
    this.vlessField('path').value = parsed.path || '';
    this.vlessField('host-header').value = parsed.hostHeader || '';
    this.vlessField('xhttp-mode').value = parsed.mode || 'auto';
    this.vlessField('sni').value = parsed.sni || '';
    this.vlessField('allow-insecure').checked = parsed.allowInsecure === 'true' || parsed.allowInsecure === true;
    this.vlessField('fp').value = parsed.fingerprint || 'chrome';
    this.vlessField('pbk').value = parsed.publicKey || '';
    this.vlessField('sid').value = parsed.shortId || '';
    this.vlessField('flow').value = parsed.flow || '';
    document.getElementById('vless-edit-mode').value = mode;
    this.vlessField('transport').disabled = mode === 'edit';
    this.vlessField('security').disabled = mode === 'edit';
    this.refreshVlessEditor();
  },

  async openVlessEditor(file) {
    try {
      const data = await this.api('config_detail', { params: { file } });
      if (data.status !== 'ok') throw new Error(data.error || 'Could not load config');
      if (data.parsed?.proto !== 'vless') { this.showToast('Only VLESS edit is supported here', 'warning'); return; }
      document.getElementById('vless-editor-title').textContent = 'Edit VLESS';
      document.getElementById('vless-edit-file').value = file;
      this.setVlessForm(data.parsed, 'edit');
      document.getElementById('vless-editor-modal').classList.add('show');
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
  },

  openManualVlessEditor() {
    if (this.vpnLocked()) { this.showToast('Disconnect VPN before adding servers', 'warning'); return; }
    document.getElementById('vless-editor-title').textContent = 'Manual VLESS';
    document.getElementById('vless-edit-file').value = '';
    this.setVlessForm({ port: '443', encryption: 'none', network: 'ws', security: 'tls', path: '/', mode: 'auto', fingerprint: 'chrome' }, 'manual');
    document.getElementById('vless-editor-modal').classList.add('show');
  },

  closeVlessEditor() { document.getElementById('vless-editor-modal').classList.remove('show'); },

  refreshVlessEditor() {
    const mode = document.getElementById('vless-edit-mode').value;
    const transport = this.vlessField('transport').value;
    const security = this.vlessField('security').value;
    const showAll = mode === 'manual';
    const showPath = showAll || ['ws', 'grpc', 'h2', 'httpupgrade', 'xhttp'].includes(transport);
    const showHost = showAll || ['ws', 'h2', 'httpupgrade', 'xhttp'].includes(transport);
    const showXhttp = showAll || transport === 'xhttp';
    const showTls = showAll || security === 'tls' || security === 'reality';
    const showReality = showAll || security === 'reality';
    document.querySelectorAll('.ve-path-field').forEach(el => { el.style.display = showPath ? '' : 'none'; });
    document.querySelectorAll('.ve-host-header-field').forEach(el => { el.style.display = showHost ? '' : 'none'; });
    document.querySelectorAll('.ve-xhttp-field').forEach(el => { el.style.display = showXhttp ? '' : 'none'; });
    document.querySelectorAll('.ve-tls-field').forEach(el => { el.style.display = showTls ? '' : 'none'; });
    document.querySelectorAll('.ve-reality-field').forEach(el => { el.style.display = showReality ? '' : 'none'; });
    document.getElementById('ve-preview').value = this.buildVlessLink();
  },

  buildVlessLink() {
    const uuid = this.vlessField('uuid').value.trim();
    const host = this.vlessField('host').value.trim();
    const port = this.vlessField('port').value.trim() || '443';
    const alias = this.vlessField('alias').value.trim();
    const transport = this.vlessField('transport').value;
    const security = this.vlessField('security').value;
    const params = new URLSearchParams();
    params.set('security', security || 'none');
    params.set('encryption', 'none');
    params.set('type', transport || 'tcp');
    const path = this.vlessField('path').value.trim();
    const hostHeader = this.vlessField('host-header').value.trim();
    const flow = this.vlessField('flow').value.trim();
    const sni = this.vlessField('sni').value.trim();
    const allowInsecure = this.vlessField('allow-insecure').checked;
    const fp = this.vlessField('fp').value.trim();
    const pbk = this.vlessField('pbk').value.trim();
    const sid = this.vlessField('sid').value.trim();
    if (path) params.set('path', path);
    if (hostHeader) params.set('host', hostHeader);
    if (transport === 'xhttp') params.set('mode', this.vlessField('xhttp-mode').value || 'auto');
    if (flow) params.set('flow', flow);
    if (sni) params.set('sni', sni);
    if (allowInsecure && security === 'tls') params.set('allowInsecure', '1');
    if (fp && (security === 'tls' || security === 'reality')) params.set('fp', fp);
    if (security === 'reality') {
      if (pbk) params.set('pbk', pbk);
      if (sid) params.set('sid', sid);
    }
    return `vless://${encodeURIComponent(uuid)}@${host}:${port}?${params.toString()}${alias ? '#' + encodeURIComponent(alias) : ''}`;
  },

  async saveVlessEditor() {
    const link = this.buildVlessLink();
    if (!this.vlessField('uuid').value.trim() || !this.vlessField('host').value.trim()) { this.showToast('UUID and address are required', 'warning'); return; }
    const btn = document.getElementById('save-vless-editor');
    btn.disabled = true;
    try {
      const mode = document.getElementById('vless-edit-mode').value;
      const file = document.getElementById('vless-edit-file').value;
      const body = mode === 'manual'
        ? new URLSearchParams({ link })
        : new URLSearchParams({ file, link });
      const data = await this.api(mode === 'manual' ? 'apply' : 'config_update', { method: 'POST', body });
      if (data.status !== 'ok') throw new Error(data.error || 'Could not save config');
      this.closeVlessEditor();
      await this.loadConfigs(this.state.latencyCache);
      this.showToast(mode === 'manual' ? 'VLESS added' : 'VLESS updated', 'success');
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { btn.disabled = false; }
  },

  async fetchLatency() {
    if (this.state.latencyRequest) return this.state.latencyRequest;
    const protocol = this.state.protocolMode;
    this.state.latencyProtocol = protocol;
    this.state.latencyRequest = this.api('latency', { params: { proto: protocol } });
    try {
      const data = await this.state.latencyRequest;
      if (protocol === this.state.protocolMode && Array.isArray(data) && !data[0]?.error) { this.state.latencyCache = data; this.state.latencyCacheTime = Date.now(); this.updateLatencies(data); }
      return data;
    } catch (e) {
      return null;
    } finally {
      this.state.latencyRequest = null;
      this.state.latencyProtocol = null;
      if (protocol !== this.state.protocolMode) this.fetchLatency();
    }
  },

  updateLatencies(data) {
    data.forEach(item => {
      const el = document.getElementById('lat-' + this.escId(item.file));
      if (el && item.latency !== null) el.textContent = item.latency + ' ms';
    });
  },

  async suggestBest() {
    const btn = document.getElementById('suggest-best');
    const orig = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner mini-spinner"></span>';
    this.showToast('Testing best server...', 'info', 2500);
    const t = setTimeout(() => { btn.disabled = false; btn.innerHTML = orig; this.showToast('Timed out', 'error'); }, 60000);
    try {
      const protocol = this.state.protocolMode;
      if (this.state.latencyRequest && this.state.latencyProtocol !== protocol) {
        await this.state.latencyRequest;
      }
      const data = this.state.latencyRequest
        ? await this.state.latencyRequest
        : await this.api('latency', { params: { force: '1', proto: protocol } });
      clearTimeout(t);
      if (!Array.isArray(data) || !data.length) throw new Error('No results');
      const visibleFiles = new Set(this.configsForProtocol().map(cfg => cfg.file));
      const valid = data.filter(d => d.latency !== null && visibleFiles.has(d.file));
      if (!valid.length) throw new Error('All servers failed');
      const best = valid.reduce((a, b) => a.latency < b.latency ? a : b);
      this.showToast(`Succesfully Select Best Server: ${this.displayFile(best.file)} (${best.latency} ms)`, 'success', 7000);
      const vpnMode = document.querySelector('input[name="vpn-mode"]:checked')?.value || 'redirect';
      const dnsType = document.getElementById('dns-select')?.value || 'cloudflare';
      const ipVersion = document.querySelector('input[name="ipversion"]:checked')?.value || 'prefer_ipv4';
      const ipResolve = document.getElementById('ip-resolve-toggle')?.checked ? 'on' : 'off';
      await this.api('select', { method: 'POST', body: new URLSearchParams({ file: best.file, proto: protocol, vpn_mode: vpnMode, dns_type: dnsType, ip_version: ipVersion, ip_resolve: ipResolve }) });
      this.loadConfigs(data);
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { clearTimeout(t); btn.disabled = false; btn.innerHTML = orig; }
  },

  async refreshStatus() {
    try {
      const data = await this.api('status');
      this.renderStatus(data);
    } catch (e) {}
  },

  renderStatus(data) {
    const wasConnected = this.state.lastStatus === 'Connected';
    const nextConnected = data.status === 'Connected';
    const nextGroup = data.fallback_group || this.state.activeConfigGroup || 'all';
    const groupChanged = nextConnected && this.state.activeConfigGroup !== nextGroup;
    this.state.fallbackGroup = nextGroup;
    this.state.fallbackMainConfig = data.fallback_main_config || '';
    this.state.fallbackCurrentConfig = data.fallback_current_config || data.config_file || '';
    this.state.fallbackUsingBackup = data.fallback_using_backup || 'false';
    this.state.autoFallback = data.autofallback || 'off';
    if (nextConnected) this.state.activeConfigGroup = nextGroup;

    document.getElementById('model-name').textContent = data.model || '-';
    document.getElementById('config-file').textContent = this.displayFile(data.config_file || '-');
    if (data.config_file && data.config_file !== '-') { document.getElementById('show-config-link').style.display = 'inline'; }
    else { document.getElementById('show-config-link').style.display = 'none'; document.getElementById('speedtest-link').style.display = 'none'; }
    document.getElementById('isp-ip').textContent = data.isp_ip || '-';
    document.getElementById('vpn-ip').textContent = data.vpn_ip || '-';
    this.renderVpnCountry(data.vpn_ip || '', data.status);
    document.getElementById('uptime').textContent = data.uptime || '-';
    document.getElementById('memory').textContent = data.memory || '-';
    document.getElementById('usage').textContent = data.usage || '-';
    const sEl = document.getElementById('vpn-status');
    sEl.textContent = data.status;
    sEl.style.color = data.status === 'Connected' ? 'green' : 'red';
    this.updateButtons(data.status);
    this.toggleCards(data.status === 'Connected');
    const statusCard = document.querySelector('.status-card');
    if (statusCard) {
      if (!wasConnected && nextConnected) statusCard.classList.add('connected-summary');
      if (!nextConnected) statusCard.classList.remove('connected-summary');
    }
    document.getElementById('speedtest-link').style.display = data.status === 'Connected' ? 'inline' : 'none';

    const licEl = document.getElementById('license-status');
    if (data.license_status === 'ACTIVATED') { licEl.textContent = 'ACTIVATED'; licEl.style.color = 'green'; this.state.licenseActive = true; }
    else { licEl.textContent = 'NOT ACTIVE'; licEl.style.color = 'red'; this.state.licenseActive = false; }

    const at = document.getElementById('autorun-toggle');
    const al = at.closest('.toggle-wrap')?.querySelector('.toggle-label');
    const as = at.closest('.toggle-wrap')?.querySelector('.tile-labels span');
    if (!data.config_file || data.config_file === '-') { at.checked = false; at.disabled = true; if (al) { al.textContent = 'Autorun: OFF'; al.className = 'toggle-label disabled'; } if (as) as.textContent = 'OFF'; }
    else { at.disabled = false; at.checked = data.autorun === 'on'; if (al) { al.textContent = 'Autorun: ' + (data.autorun === 'on' ? 'ON' : 'OFF'); al.className = 'toggle-label ' + (data.autorun === 'on' ? 'on' : 'off'); } if (as) as.textContent = data.autorun === 'on' ? 'ON' : 'OFF'; }

    const af = document.getElementById('autofallback-toggle');
    const afl = af.closest('.toggle-wrap')?.querySelector('.toggle-label');
    const afs = af.closest('.toggle-wrap')?.querySelector('.tile-labels span');
    if (!data.config_file || data.config_file === '-') { af.checked = false; af.disabled = true; if (afl) { afl.textContent = 'Auto Fallback: OFF'; afl.className = 'toggle-label disabled'; } if (afs) afs.textContent = 'OFF'; }
    else { af.disabled = false; af.checked = data.autofallback === 'on'; if (afl) { afl.textContent = 'Auto Fallback: ' + (data.autofallback === 'on' ? 'ON' : 'OFF'); afl.className = 'toggle-label ' + (data.autofallback === 'on' ? 'on' : 'off'); } if (afs) afs.textContent = data.autofallback === 'on' ? 'ON' : 'OFF'; }

    this.updateToggleLabel('ip-resolve');

    const icons = document.getElementById('vpn-icons-container');
    if (data.status === 'Connected') {
      icons.style.display = 'flex';
      document.getElementById('vpn-core-name').textContent = data.vpn_mode === 'redirect' ? (data.vpn_type === 'singbox' ? 'SING-BOX' : 'XRAY CORE') : 'SING-BOX';
      document.getElementById('vpn-mode-text').textContent = (data.vpn_mode || 'redirect').toUpperCase();
      document.getElementById('core-protocol-alt').textContent = (data.protocol || '').toUpperCase();
    } else { icons.style.display = 'none'; }
    this.state.lastStatus = data.status;
    if (wasConnected !== nextConnected || groupChanged) {
      this.renderConfigGroupTabs();
      this.renderConfigCards();
    }
  },

  toggleCards(connected) {
    document.querySelectorAll('.card').forEach(card => {
      const t = card.querySelector('h2')?.textContent.trim();
      if (t === 'VPN Control') card.style.display = connected ? 'none' : 'block';
      if (t === 'VPN Setting') {
        const ss = card.querySelector('.settings-section');
        const ar = card.querySelector('.arrow');
        if (connected) { if (ss) ss.style.display = 'none'; if (ar) ar.classList.add('open'); }
        else { if (ss) ss.style.display = ''; if (ar) ar.classList.remove('open'); }
      }
    });
  },

  renderVpnCountry(vpnIpText, status) {
    const elements = [document.getElementById('vpn-country'), document.getElementById('connected-status-country')].filter(Boolean);
    if (!elements.length) return;
    if (status !== 'Connected' || !vpnIpText || vpnIpText === '-') {
      elements.forEach(el => { el.style.display = 'none'; el.textContent = ''; });
      return;
    }
    const parts = vpnIpText.split('|').map(p => p.trim()).filter(Boolean);
    const country = parts[parts.length - 1] || '';
    const code = this.countryFlagCode(country);
    if (!country) {
      elements.forEach(el => { el.style.display = 'none'; el.textContent = ''; });
      return;
    }
    const flag = code
      ? `<span class="flag flag-img" title="${this.esc(country)}" style="background-image:url('img/${code}.png')"></span>`
      : `<span class="flag flag-code" title="${this.esc(country)}">${this.esc(country.slice(0, 2).toUpperCase() || '?')}</span>`;
    elements.forEach(el => { el.innerHTML = flag; el.style.display = 'flex'; });
  },

  countryFlagCode(country) {
    const map = {
      'Malaysia': 'my', 'Singapore': 'sg', 'Indonesia': 'id', 'Thailand': 'th', 'Vietnam': 'vn',
      'Philippines': 'ph', 'Cambodia': 'kh', 'Japan': 'jp', 'South Korea': 'kr', 'Korea': 'kr',
      'Hong Kong': 'hk', 'Taiwan': 'tw', 'China': 'cn', 'India': 'in', 'United States': 'us',
      'United Kingdom': 'gb', 'Germany': 'de', 'France': 'fr', 'Netherlands': 'nl', 'Canada': 'ca',
      'Australia': 'au', 'Russia': 'ru', 'Brazil': 'br', 'Turkey': 'tr', 'United Arab Emirates': 'ae'
    };
    return map[country] || '';
  },

  toggleLogs() {
    const log = document.getElementById('sing-box-log');
    const btn = document.getElementById('toggle-log');
    if (log.style.display === 'block') { log.style.display = 'none'; btn.textContent = 'Show Logs'; if (this.state.logInterval) clearInterval(this.state.logInterval); }
    else { log.style.display = 'block'; btn.textContent = 'Hide Logs'; this.fetchLog(); this.state.logInterval = setInterval(() => { if (document.getElementById('vpn-status').textContent === 'Connected') this.fetchLog(); }, 2000); }
  },

  toggleLogSize() { document.getElementById('sing-box-log').classList.toggle('expanded'); },

  async fetchLog() {
    try {
      const text = await this.api('logs');
      const lines = text.split('\n').slice(-20);
      document.getElementById('sing-box-log').textContent = lines.join('\n');
      document.getElementById('sing-box-log').scrollTop = document.getElementById('sing-box-log').scrollHeight;
    } catch (e) {}
  },

  async showConfig() {
    try {
      const text = await this.api('config');
      document.getElementById('config-json-text').textContent = text;
      document.getElementById('config-json-text').style.display = 'block';
      document.getElementById('speedtest-result').style.display = 'none';
      document.getElementById('config-panel-row').style.display = 'block';
      document.getElementById('show-config-link').textContent = '[Hide]';
    } catch (e) {
      document.getElementById('config-json-text').textContent = 'Failed to load config';
      document.getElementById('config-panel-row').style.display = 'block';
      document.getElementById('show-config-link').textContent = '[Hide]';
    }
  },

  async runSpeedTest() {
    const resultEl = document.getElementById('speedtest-result');
    const configEl = document.getElementById('config-json-text');
    resultEl.style.display = 'block'; configEl.style.display = 'none';
    document.getElementById('config-panel-row').style.display = 'block';
    document.getElementById('show-config-link').textContent = '[Hide]';
    document.getElementById('speedtest-link').style.pointerEvents = 'none';
    document.getElementById('speedtest-link').style.opacity = '0.6';
    try {
      const text = await this.api('speedtest');
      resultEl.textContent = text;
    } catch (e) { resultEl.textContent = 'Failed: ' + e.message; }
    finally { document.getElementById('speedtest-link').style.pointerEvents = 'auto'; document.getElementById('speedtest-link').style.opacity = '1'; }
  },

  async checkLicense() {
    try {
      const data = await this.api('license_status');
      this.state.licenseActive = data.status === 'ACTIVATED';
      return this.state.licenseActive;
    } catch { return false; }
  },

  async showLicenseModal() {
    const active = await this.checkLicense();
    if (active) await this.showLicenseInfo();
    else await this.showActivationForm();
  },

  async showActivationForm() {
    try {
      const token = await this.api('gen_token');
      document.getElementById('device-token').value = (token || '').trim();
      document.getElementById('license-key').value = '';
      document.getElementById('license-message').style.display = 'none';
      document.getElementById('license-activation-form').style.display = 'block';
      document.getElementById('license-info').style.display = 'none';
      document.getElementById('license-modal-title').textContent = 'License Activation Required';
      document.getElementById('license-modal-overlay').classList.add('show');
    } catch (e) { this.showToast('Failed to get token', 'error'); }
  },

  async showLicenseInfo() {
    try {
      const data = await this.api('license_status');
      document.getElementById('activated-license-key').value = data.license_key || '';
      document.getElementById('license-issue-date').textContent = data.issue_date || '-';
      document.getElementById('license-activation-status').textContent = data.status || '';
      document.getElementById('license-info').style.display = 'block';
      document.getElementById('license-activation-form').style.display = 'none';
      document.getElementById('license-modal-title').textContent = 'License Info';
      document.getElementById('license-modal-overlay').classList.add('show');
    } catch { document.getElementById('license-modal-overlay').classList.add('show'); }
  },

  hideLicenseModal() { document.getElementById('license-modal-overlay').classList.remove('show'); },

  async validateLicenseForm() {
    const key = document.getElementById('license-key').value.trim();
    if (!key) { this.showLicenseMsg('Enter a license key', 'red'); return; }
    const btn = document.getElementById('validate-license');
    btn.disabled = true; btn.textContent = 'Validating...';
    try {
      const text = await this.api('validate_license', { params: { key } });
      if (text.includes('SUCCESS')) {
        this.showLicenseMsg('✓ Activated!', 'green');
        setTimeout(() => { this.hideLicenseModal(); this.refreshStatus(); this.showToast('License activated!', 'success'); }, 2000);
      } else { this.showLicenseMsg(text.replace('ERROR: ', ''), 'red'); }
    } catch (e) { this.showLicenseMsg('Network error: ' + e.message, 'red'); }
    finally { btn.disabled = false; btn.textContent = 'Activate License'; }
  },

  showLicenseMsg(msg, color) {
    const el = document.getElementById('license-message');
    el.innerHTML = '<div style="color:' + color + '">' + msg + '</div>';
    el.style.display = 'block';
  },

  copyToken() { const el = document.getElementById('device-token'); el.select(); document.execCommand('copy'); this.showToast('Copied!', 'success'); },

  async fetchVersion() {
    try { const t = await this.api('version'); document.getElementById('version-text').textContent = (t || '').trim() || 'n/a'; }
    catch { document.getElementById('version-text').textContent = 'n/a'; }
  },

  updateVersions(data) {
    const items = [['ZBOX Panel', 'panel', data.panel], ['Xray Core', 'xray', data.xray], ['sing-box Core', 'singbox', data.singbox]];
    document.getElementById('update-versions').innerHTML = items.map(([name, component, value]) => {
      const available = value?.available || '';
      const installed = value?.installed || 'not installed';
      const installedLabel = installed === 'not installed' || installed.startsWith('unknown') ? installed : `v${installed}`;
      const canUpdate = component === 'panel' && available && available !== value?.installed;
      const action = component === 'panel'
        ? `<button class="btn btn-primary btn-sm update-component" data-component="panel" ${canUpdate ? '' : 'disabled'}>Update</button>`
        : `<button class="btn btn-outline btn-sm update-component" data-component="${component}">Change</button>`;
      return `<div class="update-version-row"><div><strong>${name}</strong><span>${this.esc(installedLabel)}${available ? ` | available: v${this.esc(available)}` : ''}</span></div>${action}</div>`;
    }).join('');
    document.querySelectorAll('.update-component').forEach(btn => btn.addEventListener('click', () => this.updateComponent(btn.dataset.component)));
  },

  setUpdateMessage(message, type = '') {
    const el = document.getElementById('update-message');
    el.textContent = message;
    el.className = 'update-message ' + type;
  },

  async openUpdateCenter() {
    document.getElementById('update-modal-overlay').classList.add('show');
    this.setUpdateMessage('');
    try {
      const data = await this.api('update_status');
      this.updateVersions(data);
    } catch { this.setUpdateMessage('Unable to read installed versions.', 'error'); }
  },

  closeUpdateCenter() { document.getElementById('update-modal-overlay').classList.remove('show'); },

  async checkForUpdates() {
    const btn = document.getElementById('check-update');
    btn.disabled = true; this.setUpdateMessage('Checking signed manifest...');
    try {
      const data = await this.api('update_check');
      if (data.status !== 'success') throw new Error(data.message || 'Signature verification failed');
      this.updateVersions(data);
      this.setUpdateMessage(data.update_available ? 'Verified update available.' : 'All components are current.', 'success');
    } catch (e) { this.setUpdateMessage(e.message || 'Update check failed.', 'error'); }
    finally { btn.disabled = false; }
  },

  async updateComponent(component) {
    if (component !== 'panel') {
      this.state.updateUploadComponent = component;
      this.setUpdateMessage(`Choose a signed ${component === 'xray' ? 'Xray' : 'sing-box'} update package.`, '');
      document.getElementById('offline-package').click();
      return;
    }
    if (!confirm('Install the verified ZBOX Panel update? The panel will reload.')) return;
    const btn = document.querySelector('.update-component[data-component="panel"]');
    btn.disabled = true; this.setUpdateMessage('Downloading, verifying, and staging update...');
    try {
      const data = await this.api('update_install', { method: 'POST', body: new URLSearchParams({ source: 'ota', component }) });
      if (data.status !== 'success') throw new Error(data.message || 'Installation failed');
      this.setUpdateMessage('Update installed. Reloading panel...', 'success');
      setTimeout(() => location.reload(), 1500);
    } catch (e) { this.setUpdateMessage(e.message || 'Installation failed.', 'error'); btn.disabled = false; }
  },

  async uploadOfflineUpdate(file, component = 'all') {
    if (!file) return;
    if (!file.name.endsWith('.zbox')) { this.setUpdateMessage('Choose a .zbox offline bundle.', 'error'); return; }
    const dropzone = document.getElementById('offline-dropzone');
    dropzone.style.pointerEvents = 'none'; this.setUpdateMessage('Uploading offline bundle...');
    try {
      const r = await fetch('cgi-bin/update-upload.sh', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-Zbox-Filename': file.name }, body: file });
      const data = await r.json();
      if (data.status !== 'success') throw new Error(data.message || 'Upload failed');
      this.setUpdateMessage('Verifying and staging offline bundle...');
      const result = await this.api('update_install', { method: 'POST', body: new URLSearchParams({ source: 'upload', component }) });
      if (result.status !== 'success') throw new Error(result.message || 'Installation failed');
      this.setUpdateMessage('Offline update installed. Reloading panel...', 'success');
      setTimeout(() => location.reload(), 1500);
    } catch (e) { this.setUpdateMessage(e.message || 'Offline update failed.', 'error'); }
    finally { dropzone.style.pointerEvents = ''; document.getElementById('offline-package').value = ''; this.state.updateUploadComponent = 'all'; }
  },

  detectProtocol(link) {
    let p = 'Unknown';
    if (link.startsWith('vless://')) p = 'VLESS';
    else if (link.startsWith('trojan://')) p = 'Trojan';
    else if (link.includes('[Interface]')) p = 'WG';
    else p = 'Unknown';
    document.getElementById('core-protocol-alt').textContent = p;
  },

  updateToggleLabel(type) {
    if (type === 'ip-resolve') {
      const t = document.getElementById('ip-resolve-toggle');
      const l = t.closest('.toggle-wrap')?.querySelector('.toggle-label');
      const sub = t.closest('.toggle-wrap')?.querySelector('.tile-labels span');
      if (l) { const o = t.checked; l.textContent = 'IP Resolve: ' + (o ? 'ON' : 'OFF'); l.className = 'toggle-label ' + (o ? 'on' : 'off'); }
      if (sub) sub.textContent = t.checked ? 'ON' : 'OFF';
    }
  },

  showToast(msg, type, dur) {
    document.querySelectorAll('.toast').forEach(t => t.remove());
    const toast = document.createElement('div');
    toast.className = 'toast ' + (type || 'info');
    toast.innerHTML = msg + '<span class="toast-close" onclick="this.parentElement.remove()">×</span>';
    document.body.appendChild(toast);
    const d = dur || 3000;
    setTimeout(() => { if (toast.parentNode) { toast.style.opacity = '0'; setTimeout(() => { if (toast.parentNode) toast.remove(); }, 300); } }, d);
  },

  esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; },

  displayFile(s) { return (s || '').replace(/\.txt\b/g, ''); },

  stripTxt(s) { return (s || '').replace(/\.txt\b/g, ''); },

  escId(s) { return s.replace(/[.#\s()]/g, '_'); }
};

document.addEventListener('DOMContentLoaded', () => setTimeout(() => ZBOX.init(), 100));

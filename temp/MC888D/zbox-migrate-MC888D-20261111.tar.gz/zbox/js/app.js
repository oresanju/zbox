/* ZBOX VPN Panel v2.0 - Frontend JS */
const API = 'cgi-bin/app.sh';

const ZBOX = {
  state: {
    lastStatus: 'Disconnected',
    logInterval: null,
    latencyCache: null,
    latencyCacheTime: 0,
    latencyRequest: null,
    latencyProtocol: null,
    configs: [],
    configGroups: [],
    activeConfigGroup: 'all',
    fallbackGroup: 'all',
    fallbackMainConfig: '',
    fallbackCurrentConfig: '',
    fallbackUsingBackup: 'false',
    autoFallback: 'off',
    licenseActive: false,
    theme: 'light',
    protocolMode: 'vless',
    pendingWireGuardConfig: '',
    customCoreComponent: '',
    updateDetails: null,
    updateProgressTimer: null,
    updateAvailable: false,
    lastUpdateCheck: null,
    speedtestRunning: false
  },

  async api(action, opts = {}) {
    const { method = 'GET', body, params = {} } = opts;
    const qs = new URLSearchParams({ action, ...params, ...(method === 'GET' ? { _: Date.now() } : {}) }).toString();
    const url = API + '?' + qs;
    const fetchOpts = { method, cache: 'no-store' };
    if (body) {
      fetchOpts.headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
      fetchOpts.body = body instanceof URLSearchParams ? body.toString() : body;
    }
    const r = await fetch(url, fetchOpts);
    const ct = r.headers.get('content-type') || '';
    if (ct.includes('application/json')) return r.json();
    return r.text();
  },

  vpnLocked() {
    return this.state.lastStatus === 'Connected' || this.state.lastStatus === 'Connecting';
  },

  async init() {
    this.applyTheme();
    this.bindEvents();
    this.setupCollapsible();
    await this.loadSettings();
    this.setProtocolMode(this.state.protocolMode);
    this.refreshStatus();
    this.fetchVersion();
    this.checkLicense();
    setInterval(() => this.refreshStatus(), 5000);
    this.loadConfigs();
  },

  async loadSettings() {
    try {
      const s = await this.api('settings');
      this.applySettingsToUI(s);
    } catch (e) { console.log('Settings fallback'); }
  },

  applySettingsToUI(s) {
    const mode = s.vpn?.mode || 'redirect';
    const coreType = s.vpn?.coreType || 'xray';
    const dns = s.network?.dns || 'cloudflare';
    const ipr = s.network?.ipResolve === true || s.network?.ipResolve === 'on';
    const logLevel = s.vpn?.logLevel || 'info';
    const ntp = s.time || {};
    const autoCheckUpdate = s.update?.autoCheck === true;
    this.state.activeConfigGroup = s.activeConfigGroup || 'all';
    this.state.protocolMode = s.activeProtocol === 'wg' ? 'wg' : 'vless';

    document.querySelectorAll('input[name="vpn-mode"]').forEach(r => { r.checked = r.value === mode; });
    document.querySelectorAll('input[name="redirect-engine"]').forEach(r => { r.checked = r.value === coreType; });
    const dnsEl = document.getElementById('dns-select');
    if (dnsEl) dnsEl.value = dns;
    const logLevelEl = document.getElementById('log-level-select');
    if (logLevelEl) logLevelEl.value = logLevel;
    document.getElementById('ntp-server-select').value = ntp.server || 'pool.ntp.org';
    document.getElementById('timezone-select').value = ntp.timezone || 'GMT-8';
    document.getElementById('ntp-auto-sync').checked = ntp.autoSync !== false;
    document.getElementById('auto-check-update').checked = autoCheckUpdate;
    document.getElementById('ntp-last-sync').textContent = 'Last sync: ' + (ntp.lastSync || 'Never');
    const tun = s.network?.tunnelIpMode || 'dual';
    const ipModeEl = document.getElementById('ip-mode-select');
    if (ipModeEl) ipModeEl.value = tun;
    // migrate legacy mssClamp value, then read the new keys
    let mssVal = s.network?.mssOverride;
    if (!mssVal) {
      const legacy = s.network?.mssClamp;
      mssVal = legacy === 'off' ? 'off' : legacy === '1200' ? '1200' : 'auto-pmtu';
    }
    const mssEl = document.getElementById('mss-select');
    if (mssEl) mssEl.value = mssVal;
    const mtuEl = document.getElementById('mtu-select');
    if (mtuEl) mtuEl.value = s.network?.wanMtu || '1500';
    const lan6El = document.getElementById('lanipv6-select');
    if (lan6El) lan6El.value = s.network?.lanIpv6 === 'off' ? 'off' : 'on';
    ZBOX.api('modem_ttl').then(r => {
      const el = document.getElementById('modem-ttl-select');
      const cur = document.getElementById('modem-ttl-current');
      if (cur) cur.textContent = 'Current: ' + (r.ttl || '0') + (r.ttl === '0' ? ' (Disabled)' : '');
      if (el && r.ttl && ['0','64','65'].includes(r.ttl)) { el.value = r.ttl; } else if (el) { el.value = '64'; }
    }).catch(() => {});
    const irToggle = document.getElementById('ip-resolve-toggle');
    if (irToggle) irToggle.checked = ipr;
    this.updateToggleLabel('ip-resolve');
    const engineCtr = document.getElementById('redirect-engine-container');
    if (engineCtr) engineCtr.style.display = mode === 'redirect' ? 'block' : 'none';
  },

  bindEvents() {
    document.getElementById('theme-toggle').addEventListener('click', (e) => { e.stopPropagation(); this.toggleTheme(); });
    document.getElementById('open-panel-settings').addEventListener('click', (e) => { e.stopPropagation(); this.openPanelSettings(); });
    document.getElementById('close-panel-settings').addEventListener('click', () => this.closePanelSettings());
    document.getElementById('apply').addEventListener('click', (e) => { e.preventDefault(); this.applyConfig(); });
    document.getElementById('manual-vless').addEventListener('click', () => this.openManualVlessEditor());
    document.getElementById('upload-wireguard').addEventListener('click', () => {
      if (this.vpnLocked()) { this.showToast('Disconnect VPN before adding servers', 'warning'); return; }
      document.getElementById('wireguard-file').click();
    });
    document.getElementById('wireguard-file').addEventListener('change', (e) => this.uploadWireGuardFile(e.target.files[0]));
    document.querySelectorAll('.protocol-pills [data-protocol]').forEach(btn => {
      btn.addEventListener('click', () => this.setProtocolMode(btn.dataset.protocol, true));
    });
    document.getElementById('connect').addEventListener('click', (e) => { e.preventDefault(); if (!e.target.disabled) this.doConnect(); });
    document.getElementById('disconnect').addEventListener('click', (e) => { e.preventDefault(); if (!e.target.disabled) this.doDisconnect(); });

    document.getElementById('autorun-toggle').addEventListener('change', function() {
      const on = this.checked;
      const label = this.closest('.toggle-wrap').querySelector('.toggle-label');
      const sub = this.closest('.toggle-wrap').querySelector('.tile-labels span');
      if (label) { label.textContent = 'Autorun: ' + (on ? 'ON' : 'OFF'); label.className = 'toggle-label ' + (on ? 'on' : 'off'); }
      if (sub) sub.textContent = on ? 'ON' : 'OFF';
      ZBOX.api('settings', { params: { set: 'autorun', value: on ? 'on' : 'off' } }).catch(e => console.error('autorun API error:', e));
    });
    document.getElementById('autofallback-toggle').addEventListener('change', function() {
      const on = this.checked;
      const label = this.closest('.toggle-wrap').querySelector('.toggle-label');
      const sub = this.closest('.toggle-wrap').querySelector('.tile-labels span');
      if (label) { label.textContent = 'Auto Fallback: ' + (on ? 'ON' : 'OFF'); label.className = 'toggle-label ' + (on ? 'on' : 'off'); }
      if (sub) sub.textContent = on ? 'ON' : 'OFF';
      ZBOX.api('settings', { params: { set: 'autofallback', value: on ? 'on' : 'off' } }).catch(e => console.error('autofallback API error:', e));
    });
    document.getElementById('ip-resolve-toggle').addEventListener('change', function() {
      ZBOX.updateToggleLabel('ip-resolve');
      ZBOX.api('settings', { params: { set: 'ipresolve', value: this.checked ? 'on' : 'off' } }).catch(e => console.error('ipresolve API error:', e));
    });

    document.getElementById('toggle-log').addEventListener('click', () => this.toggleLogs());
    document.getElementById('sing-box-log').addEventListener('click', () => this.toggleLogSize());

    document.getElementById('show-config-link').addEventListener('click', (e) => {
      e.preventDefault();
      const link = document.getElementById('show-config-link');
      if (link.textContent === '[View]') { this.showConfig(); }
      else { document.getElementById('config-panel-row').style.display = 'none'; link.textContent = '[View]'; }
    });
    document.getElementById('speedtest-link').addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); this.runSpeedTest(); });
    document.getElementById('close-config').addEventListener('click', () => {
      document.getElementById('config-panel-row').style.display = 'none';
      document.getElementById('show-config-link').textContent = '[View]';
      document.getElementById('config-json-text').textContent = '';
    });
    document.getElementById('close-speedtest').addEventListener('click', () => {
      document.getElementById('speedtest-panel-row').style.display = 'none';
      document.getElementById('speedtest-result').textContent = '';
    });

    document.querySelectorAll('input[name="vpn-mode"]').forEach(r => {
      r.addEventListener('change', function() {
        document.getElementById('vpn-mode-text').textContent = this.value.toUpperCase();
        document.getElementById('redirect-engine-container').style.display = ZBOX.state.protocolMode === 'wg' ? 'none' : (this.value === 'redirect' ? 'block' : 'none');
        ZBOX.api('settings', { params: { set: 'mode', value: this.value } });
      });
    });
    document.querySelectorAll('input[name="redirect-engine"]').forEach(r => {
      r.addEventListener('change', function() {
        ZBOX.api('settings', { params: { set: 'coretype', value: this.value } });
      });
    });

    document.getElementById('dns-select').addEventListener('change', function() {
      ZBOX.api('settings', { params: { set: 'dns', value: this.value } });
    });
    document.getElementById('log-level-select').addEventListener('change', function() {
      ZBOX.api('settings', { params: { set: 'loglevel', value: this.value } });
    });
    document.getElementById('auto-check-update').addEventListener('change', function() { ZBOX.api('settings', { params: { set: 'autocheckupdate', value: this.checked ? 'on' : 'off' } }); });
    document.getElementById('ntp-server-select').addEventListener('change', function() { ZBOX.api('settings', { params: { set: 'ntpserver', value: this.value } }); });
    document.getElementById('timezone-select').addEventListener('change', function() { ZBOX.api('settings', { params: { set: 'timezone', value: this.value } }); });
    document.getElementById('ntp-auto-sync').addEventListener('change', function() { ZBOX.api('settings', { params: { set: 'ntpautosync', value: this.checked ? 'on' : 'off' } }); });
    document.getElementById('sync-time-now').addEventListener('click', async function() { this.disabled = true; try { const r = await ZBOX.api('time_sync', { method: 'POST' }); if (r.status !== 'ok') throw new Error(r.error); document.getElementById('ntp-last-sync').textContent = 'Last sync: ' + r.time; } catch (e) { ZBOX.showToast('Time sync failed: ' + e.message, 'error'); } finally { this.disabled = false; } });
    const ipModeSel = document.getElementById('ip-mode-select');
    if (ipModeSel) ipModeSel.addEventListener('change', function() {
      ZBOX.api('settings', { params: { set: 'tunnelipmode', value: this.value } });
      ZBOX.showToast('IP Mode saved. Reconnect VPN to apply.', 'info');
    });
    const mssSel = document.getElementById('mss-select');
    if (mssSel) mssSel.addEventListener('change', function() {
      ZBOX.api('settings', { params: { set: 'msoverride', value: this.value } });
      ZBOX.showToast('TCP MSS Override saved. Reconnect VPN to apply.', 'info');
    });
    const mtuSel = document.getElementById('mtu-select');
    if (mtuSel) mtuSel.addEventListener('change', function() {
      ZBOX.api('settings', { params: { set: 'wanmtu', value: this.value } });
      ZBOX.showToast('WAN MTU saved. Reconnect VPN to apply.', 'info');
    });
    const lan6Sel = document.getElementById('lanipv6-select');
    if (lan6Sel) lan6Sel.addEventListener('change', function() {
      ZBOX.api('settings', { params: { set: 'lanipv6', value: this.value } });
      ZBOX.showToast('LAN IPv6 saved. Reconnect VPN to apply.', 'info');
    });
    const tabVpn = document.getElementById('settings-tab-vpn');
    const tabModem = document.getElementById('settings-tab-modem');
    const paneVpn = document.getElementById('settings-pane-vpn');
    const paneModem = document.getElementById('settings-pane-modem');
    if (tabVpn && tabModem && paneVpn && paneModem) {
      const pick = (which) => {
        const vpn = which === 'vpn';
        tabVpn.classList.toggle('active', vpn);
        tabModem.classList.toggle('active', !vpn);
        tabVpn.setAttribute('aria-selected', vpn);
        tabModem.setAttribute('aria-selected', !vpn);
        paneVpn.classList.toggle('active', vpn);
        paneModem.classList.toggle('active', !vpn);
      };
      tabVpn.addEventListener('click', () => pick('vpn'));
      tabModem.addEventListener('click', () => pick('modem'));
    }
    const ttlSel = document.getElementById('modem-ttl-select');
    if (ttlSel) ttlSel.addEventListener('change', async function() {
      ttlSel.disabled = true;
      try {
        const r = await ZBOX.api('modem_ttl', { params: { value: this.value } });
        if (r.status !== 'ok') throw new Error(r.error || 'failed');
        ZBOX.showToast('TTL set to ' + this.value + (this.value === '0' ? ' (disabled)' : '') + '.', 'success');
        ZBOX.loadSettings && ZBOX.loadSettings();
      } catch (e) {
        ZBOX.showToast('TTL setting failed: ' + e.message, 'error');
      } finally { ttlSel.disabled = false; }
    });
    const rebootBtn = document.getElementById('modem-reboot');
    if (rebootBtn) rebootBtn.addEventListener('click', async function() {
      if (!confirm('Restart the modem now? The VPN and this page will drop for about a minute.')) return;
      rebootBtn.disabled = true;
      try {
        await ZBOX.api('modem_reboot', { method: 'POST' });
        ZBOX.showToast('Rebooting modem…', 'info');
      } catch (e) {
        ZBOX.showToast('Reboot command sent.', 'info');
      }
    });

    document.getElementById('suggest-best').addEventListener('click', () => this.suggestBest());
    document.getElementById('add-config-group').addEventListener('click', () => {
      if (this.vpnLocked()) { this.showToast('Disconnect VPN before editing groups', 'warning'); return; }
      this.openConfigGroupModal();
    });
    document.getElementById('cancel-config-group').addEventListener('click', () => this.closeConfigGroupModal());
    document.getElementById('save-config-group').addEventListener('click', () => this.saveConfigGroup());
    document.getElementById('delete-config-group').addEventListener('click', () => this.deleteConfigGroup());
    document.getElementById('group-select-all').addEventListener('click', () => {
      document.querySelectorAll('#config-group-checklist input[type="checkbox"]').forEach(c => { c.checked = true; });
    });
    document.getElementById('group-clear-all').addEventListener('click', () => {
      document.querySelectorAll('#config-group-checklist input[type="checkbox"]').forEach(c => { c.checked = false; });
    });
    document.getElementById('cancel-vless-editor').addEventListener('click', () => this.closeVlessEditor());
    document.getElementById('save-vless-editor').addEventListener('click', () => this.saveVlessEditor());
    ['ve-alias','ve-uuid','ve-host','ve-port','ve-transport','ve-security','ve-path','ve-host-header','ve-xhttp-mode','ve-sni','ve-allow-insecure','ve-fp','ve-pbk','ve-sid','ve-flow'].forEach(id => {
      document.getElementById(id).addEventListener('input', () => this.refreshVlessEditor());
      document.getElementById(id).addEventListener('change', () => this.refreshVlessEditor());
    });
    document.getElementById('cancel-license').addEventListener('click', () => this.hideLicenseModal());
    document.getElementById('validate-license').addEventListener('click', () => this.validateLicenseForm());
    document.getElementById('copy-token').addEventListener('click', () => this.copyToken());
    document.getElementById('delete-license').addEventListener('click', () => this.deleteLicense());
    document.getElementById('close-license-info').addEventListener('click', () => this.hideLicenseModal());
    document.getElementById('license-status').addEventListener('click', () => this.showLicenseModal());
    document.getElementById('open-update-center').addEventListener('click', () => this.openUpdateCenter());
    document.getElementById('close-update').addEventListener('click', () => this.closeUpdateCenter());
    document.getElementById('check-update').addEventListener('click', () => this.checkForUpdates());
    document.getElementById('close-update-details').addEventListener('click', () => this.closeUpdateDetails());
    document.getElementById('install-update-details').addEventListener('click', () => {
      const component = this.state.updateDetails?.component;
      if (component) this.updateComponent(component);
    });
    const dropzone = document.getElementById('offline-dropzone');
    dropzone.addEventListener('click', () => document.getElementById('offline-package').click());
    dropzone.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); document.getElementById('offline-package').click(); } });
    ['dragenter', 'dragover'].forEach(type => dropzone.addEventListener(type, e => { e.preventDefault(); dropzone.classList.add('dragover'); }));
    ['dragleave', 'drop'].forEach(type => dropzone.addEventListener(type, e => { e.preventDefault(); dropzone.classList.remove('dragover'); }));
    dropzone.addEventListener('drop', e => this.uploadOfflineUpdate(e.dataTransfer.files[0]));
    document.getElementById('offline-package').addEventListener('change', (e) => this.uploadOfflineUpdate(e.target.files[0]));
    document.getElementById('custom-core-package').addEventListener('change', (e) => this.uploadCustomCore(e.target.files[0], this.state.customCoreComponent));
    document.getElementById('close-update-progress').addEventListener('click', () => document.getElementById('update-progress-modal').classList.remove('show'));
    document.getElementById('cancel-wireguard-name').addEventListener('click', () => this.closeWireGuardNameModal());
    document.getElementById('save-wireguard-name').addEventListener('click', () => this.saveWireGuardConfig());
    document.getElementById('cancel-wireguard-editor').addEventListener('click', () => this.closeWireGuardEditor());
    document.getElementById('save-wireguard-editor').addEventListener('click', () => this.saveWireGuardEditor());
  },

  setProtocolMode(mode, persist = false) {
    const previousMode = this.state.protocolMode;
    this.state.protocolMode = mode === 'wg' ? 'wg' : 'vless';
    const isWg = this.state.protocolMode === 'wg';
    if (previousMode !== this.state.protocolMode) this.state.activeConfigGroup = 'all';
    if (persist && previousMode !== this.state.protocolMode) {
      this.api('settings', { params: { set: 'active_protocol', value: this.state.protocolMode } }).catch(() => {});
    }
    document.querySelectorAll('.protocol-pills [data-protocol]').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.protocol === this.state.protocolMode);
    });
    document.getElementById('vpn-input-label').textContent = isWg ? 'Paste your WireGuard config:' : 'Paste your VPN link:';
    document.getElementById('vless').placeholder = isWg ? '[Interface]\nPrivateKey = ...\nAddress = ...\n\n[Peer]\nPublicKey = ...\nEndpoint = host:51820' : 'vless://...';
    document.getElementById('manual-vless').style.display = isWg ? 'none' : '';
    document.getElementById('upload-wireguard').style.display = isWg ? '' : 'none';
    document.querySelectorAll('.vless-setting').forEach(el => { el.style.display = isWg ? 'none' : ''; });
    if (!isWg) {
      const mode = document.querySelector('input[name="vpn-mode"]:checked')?.value || 'redirect';
      document.getElementById('redirect-engine-container').style.display = mode === 'redirect' ? 'block' : 'none';
    }
    this.renderConfigGroupTabs();
    this.renderConfigCards();
    if (previousMode !== this.state.protocolMode && this.state.configs.length) this.fetchLatency();
  },

  setupCollapsible() {
    const statusCard = document.querySelector('.status-card');
    const statusTile = statusCard?.querySelector('.status-main-tile');
    statusTile?.addEventListener('click', () => {
      if (this.state.lastStatus === 'Connected' && statusCard.classList.contains('connected-summary')) this.toggleConnectedStatusCard();
    });
    document.querySelectorAll('.card-header').forEach(header => {
      header.addEventListener('click', function(e) {
        if (this.classList.contains('static-card-header')) return;
        e.stopPropagation();
        const card = this.closest('.card');
        const body = card.querySelector('.card-body');
        const arrow = this.querySelector('.arrow');
        if (card.classList.contains('status-card') && ZBOX.state.lastStatus === 'Connected') {
          ZBOX.toggleConnectedStatusCard();
          return;
        }
        if (body.style.display === 'none') { body.style.display = 'block'; arrow.classList.remove('open'); }
        else { body.style.display = 'none'; arrow.classList.add('open'); }
      });
    });
  },

  toggleConnectedStatusCard() {
    const card = document.querySelector('.status-card');
    if (!card) return;
    const compact = card.classList.toggle('connected-summary');
    card.querySelector('.card-body').style.display = 'block';
    card.querySelector('.status-main-tile').setAttribute('aria-expanded', String(!compact));
  },

  openPanelSettings() { document.getElementById('panel-settings-modal').classList.add('show'); },

  closePanelSettings() { document.getElementById('panel-settings-modal').classList.remove('show'); },

  applyTheme() {
    const saved = localStorage.getItem('zbox-theme');
    const toggle = document.getElementById('theme-toggle');
    if (saved === 'dark') {
      document.body.classList.add('dark');
      if (toggle) toggle.className = 'theme-toggle dark-mode';
      this.state.theme = 'dark';
    } else {
      document.body.classList.remove('dark');
      if (toggle) toggle.className = 'theme-toggle light';
      this.state.theme = 'light';
    }
  },

  toggleTheme() {
    const toggle = document.getElementById('theme-toggle');
    if (this.state.theme === 'light') {
      document.body.classList.add('dark');
      if (toggle) toggle.className = 'theme-toggle dark-mode';
      this.state.theme = 'dark';
      localStorage.setItem('zbox-theme', 'dark');
    } else {
      document.body.classList.remove('dark');
      if (toggle) toggle.className = 'theme-toggle light';
      this.state.theme = 'light';
      localStorage.setItem('zbox-theme', 'light');
    }
  },

  async doConnect() {
    const btn = document.getElementById('connect');
    const orig = btn.textContent;
    btn.disabled = true; btn.textContent = 'Connecting...';
    try {
      const isActive = await this.checkLicense();
      if (!isActive) { this.showToast('License not activated', 'error'); setTimeout(() => this.showLicenseModal(), 1000); return; }
      const data = await this.api('connect', { method: 'POST' });
      if (data.status === 'success') {
        document.getElementById('vpn-status').textContent = 'Connected';
        document.getElementById('vpn-status').style.color = 'green';
        this.updateButtons('Connected');
        this.refreshStatus();
      } else {
        this.showToast(data.message || 'Connection failed', 'error');
      }
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { setTimeout(() => { btn.disabled = false; btn.textContent = orig; }, 2000); }
  },

  async doDisconnect() {
    const btn = document.getElementById('disconnect');
    const orig = btn.textContent;
    btn.disabled = true; btn.textContent = 'Disconnecting...';
    try {
      await this.api('disconnect', { method: 'POST' });
      document.getElementById('vpn-status').textContent = 'Disconnected';
      document.getElementById('vpn-status').style.color = 'red';
      document.getElementById('vpn-ip').textContent = '-';
      document.getElementById('isp-ip').textContent = '-';
      document.getElementById('speedtest-link').style.display = 'inline-grid';
      if (this.state.logInterval) clearInterval(this.state.logInterval);
      this.updateButtons('Disconnected');
      document.querySelector('.card_icon').style.display = 'none';
      document.getElementById('vpn-icons-container').style.display = 'none';
      this.refreshStatus();
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { setTimeout(() => { btn.disabled = false; btn.textContent = orig; }, 2000); }
  },

  updateButtons(status) {
    const c = document.getElementById('connect');
    const d = document.getElementById('disconnect');
    const best = document.getElementById('suggest-best');
    c.classList.remove('btn-primary', 'btn-success');
    d.classList.remove('btn-danger');
    if (status === 'Connected') {
      c.style.display = 'none'; d.style.display = '';
      c.disabled = true; d.disabled = false; d.classList.add('btn-danger');
      if (best) best.style.display = 'none';
    }
    else if (status === 'Connecting') {
      c.style.display = ''; d.style.display = 'none';
      c.disabled = true; d.disabled = true; c.classList.add('btn-success');
      if (best) best.style.display = 'none';
    }
    else {
      c.style.display = ''; d.style.display = 'none';
      c.disabled = false; c.classList.add('btn-success'); d.disabled = true;
      if (best) best.style.display = '';
    }
  },

  async applyConfig() {
    const link = document.getElementById('vless').value.trim();
    const isWg = this.state.protocolMode === 'wg';
    if (!link) { this.showToast(isWg ? 'Paste a WireGuard config' : 'Paste a VPN link', 'warning'); return; }
    if (isWg) {
      this.openWireGuardNameModal(link);
      return;
    }
    await this.submitConfig(link, 'vless');
  },

  async submitConfig(link, proto, configName = '') {
    try {
      const data = await this.api('apply', { method: 'POST', body: new URLSearchParams({ link, proto, config_name: configName }) });
      if (data.status === 'ok') {
        this.showToast('Saved: ' + data.alias, 'success');
        this.detectProtocol(link);
        document.getElementById('vless').value = '';
        this.loadConfigs();
      } else { this.showToast('Error: ' + (data.error || ''), 'error'); }
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
  },

  openWireGuardNameModal(link) {
    this.state.pendingWireGuardConfig = link;
    const input = document.getElementById('wireguard-config-name');
    input.value = '';
    document.getElementById('wireguard-name-modal').classList.add('show');
    setTimeout(() => input.focus(), 0);
  },

  closeWireGuardNameModal() {
    this.state.pendingWireGuardConfig = '';
    document.getElementById('wireguard-name-modal').classList.remove('show');
  },

  async saveWireGuardConfig() {
    const name = document.getElementById('wireguard-config-name').value.replace(/[\r\n]/g, ' ').trim();
    if (!name) { this.showToast('Enter a WireGuard config name', 'warning'); return; }
    const link = this.state.pendingWireGuardConfig;
    this.closeWireGuardNameModal();
    await this.submitConfig(link, 'wg', name);
  },

  async uploadWireGuardFile(file) {
    const input = document.getElementById('wireguard-file');
    if (!file) return;
    if (!/\.(conf|txt)$/i.test(file.name)) { this.showToast('Choose a WireGuard .conf or .txt file', 'warning'); input.value = ''; return; }
    try {
      const config = (await file.text()).replace(/\r/g, '');
      if (!/^\s*\[Interface\]/m.test(config) || !/^\s*\[Peer\]/m.test(config)) throw new Error('File is not a WireGuard config');
      this.openWireGuardNameModal(config);
    } catch (e) { this.showToast(e.message || 'Could not read WireGuard file', 'error'); }
    finally { input.value = ''; }
  },

  async loadConfigs(latencyData) {
    const cnt = document.getElementById('config-list');
    cnt.innerHTML = '<div style="padding:10px;color:var(--text-muted)">Loading...</div>';
    try {
      const [configs, groups] = await Promise.all([this.api('configs'), this.api('groups')]);
      this.state.configs = Array.isArray(configs) ? configs : [];
      this.state.configGroups = Array.isArray(groups) ? groups : [];
      const validTabs = ['all', ...this.state.configGroups.map(g => g.id)];
      if (!validTabs.includes(this.state.activeConfigGroup)) this.state.activeConfigGroup = 'all';
      this.renderConfigGroupTabs();
      this.renderConfigCards();
      if (latencyData && Array.isArray(latencyData)) { this.updateLatencies(latencyData); }
      else { this.fetchLatency(); }
    } catch (e) { cnt.textContent = 'Failed to load configs'; }
  },

  configsForActiveGroup() {
    const proto = this.state.protocolMode === 'wg' ? 'wg' : 'vless';
    const protocolConfigs = this.state.configs.filter(c => c.proto === proto);
    if (this.state.activeConfigGroup === 'all') return protocolConfigs;
    const group = this.state.configGroups.find(g => g.id === this.state.activeConfigGroup);
    const members = new Set(group?.configs || []);
    return protocolConfigs.filter(c => members.has(c.file));
  },

  renderConfigCards() {
    const cnt = document.getElementById('config-list');
    const configs = this.configsForActiveGroup();
    cnt.innerHTML = '';
    const protocolConfigs = this.state.configs.filter(c => c.proto === (this.state.protocolMode === 'wg' ? 'wg' : 'vless'));
    if (!protocolConfigs.length) {
      cnt.innerHTML = `<div style="grid-column:1/-1;padding:10px;color:var(--text-muted)">No ${this.state.protocolMode === 'wg' ? 'WireGuard' : 'VLESS'} configs yet. Paste a config and click Apply.</div>`;
      return;
    }
    if (!configs.length) {
      cnt.innerHTML = '<div style="grid-column:1/-1;padding:10px;color:var(--text-muted)">No configs in this group.</div>';
      return;
    }
    configs.forEach(cfg => {
        const card = document.createElement('div');
        card.className = 'config-card';
        card.dataset.file = cfg.file;
        const connected = this.vpnLocked();
        const fallbackOn = this.state.autoFallback === 'on';
        const isMain = connected && cfg.file === this.state.fallbackMainConfig;
        const isCurrent = connected && cfg.file === this.state.fallbackCurrentConfig;
        const role = fallbackOn && connected ? (isMain ? '<span class="config-role main">MAIN</span>' : '<span class="config-role backup">BACKUP</span>') : '';
        if (isCurrent) card.classList.add('current');
        const active = isCurrent ? '<span class="config-active">ACTIVE</span>' : '';
        const protoLabel = cfg.proto === 'wg' ? 'WG' : cfg.proto.toUpperCase();
        card.innerHTML = `<div class="name">${this.esc(cfg.alias)}</div><div class="meta"><span class="proto ${cfg.proto}">${protoLabel}</span>${role}${active}<span class="latency" id="lat-${this.escId(cfg.file)}"></span></div><button class="edit-btn" type="button" title="Edit config">&#9998;</button><button class="close-btn" type="button" title="Delete config">×</button>`;
        card.addEventListener('click', (e) => { if (!e.target.closest('button')) this.selectConfig(cfg); });
        card.querySelector('.edit-btn').addEventListener('click', (e) => {
          e.stopPropagation();
          if (this.vpnLocked()) { this.showToast('Disconnect VPN before editing servers', 'warning'); return; }
          if (cfg.proto === 'wg') this.openWireGuardEditor(cfg.file);
          else this.openVlessEditor(cfg.file);
        });
        card.querySelector('.close-btn').addEventListener('click', (e) => {
          e.stopPropagation();
          if (this.vpnLocked()) { this.showToast('Disconnect VPN before deleting servers', 'warning'); return; }
          if (confirm('Delete ' + cfg.file + '?')) this.deleteConfig(cfg.file, card);
        });
        cnt.appendChild(card);
    });
    if (Array.isArray(this.state.latencyCache)) this.updateLatencies(this.state.latencyCache);
  },

  renderConfigGroupTabs() {
    const tabs = document.getElementById('config-group-tabs');
    const connected = this.vpnLocked();
    const addBtn = document.getElementById('add-config-group');
    if (addBtn) addBtn.style.display = connected ? 'none' : '';
    let definitions = [
      { id: 'all', name: 'ALL', count: this.configsForProtocol().length, system: true },
      ...this.state.configGroups.map(g => ({ ...g, count: (g.configs || []).filter(f => this.configsForProtocol().some(c => c.file === f)).length }))
    ];
    definitions = definitions.filter(group => group.system || group.count > 0 || group.id === this.state.activeConfigGroup);
    if (connected) definitions = definitions.filter(group => group.id === this.state.activeConfigGroup);
    tabs.innerHTML = '';
    definitions.forEach(group => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'config-group-tab' + (group.id === this.state.activeConfigGroup ? ' active' : '') + (connected ? ' locked' : '');
      btn.disabled = connected;
      btn.innerHTML = `${this.esc(group.name)} <span class="group-count">(${group.count})</span>${group.system ? '' : '<span class="group-edit" title="Edit group">&#9998;</span>'}`;
      btn.addEventListener('click', e => {
        if (connected) { this.showToast('Disconnect VPN before changing group', 'warning'); return; }
        if (!group.system && e.target.closest('.group-edit')) { this.openConfigGroupModal(group.id); return; }
        this.selectConfigGroup(group.id);
      });
      tabs.appendChild(btn);
    });
  },

  configsForProtocol() {
    const proto = this.state.protocolMode === 'wg' ? 'wg' : 'vless';
    return this.state.configs.filter(c => c.proto === proto);
  },

  async selectConfigGroup(id) {
    if (this.vpnLocked()) { this.showToast('Disconnect VPN before changing group', 'warning'); return; }
    this.state.activeConfigGroup = id;
    this.renderConfigGroupTabs();
    this.renderConfigCards();
    try { await this.api('settings', { params: { set: 'active_config_group', value: id } }); } catch (e) {}
  },

  openConfigGroupModal(id = '') {
    if (this.vpnLocked()) { this.showToast('Disconnect VPN before editing groups', 'warning'); return; }
    const group = this.state.configGroups.find(g => g.id === id);
    document.getElementById('config-group-modal-title').textContent = group ? 'Edit Config Group' : 'Add Config Group';
    document.getElementById('config-group-id').value = group?.id || '';
    document.getElementById('config-group-name').value = group?.name || '';
    document.getElementById('delete-config-group').style.display = group ? 'inline-flex' : 'none';
    const selected = new Set(group?.configs || []);
    const list = document.getElementById('config-group-checklist');
    list.innerHTML = '';
    const protocolConfigs = this.configsForProtocol();
    if (!protocolConfigs.length) {
      list.innerHTML = '<div style="padding:12px;color:var(--text-muted)">No configurations available.</div>';
    } else {
      protocolConfigs.forEach(cfg => {
        const label = document.createElement('label');
        label.className = 'config-group-check-item';
        const check = document.createElement('input');
        check.type = 'checkbox'; check.value = cfg.file; check.checked = selected.has(cfg.file);
        const name = document.createElement('span');
        name.textContent = `${cfg.alias} (${cfg.proto.toUpperCase()})`;
        label.append(check, name);
        list.appendChild(label);
      });
    }
    document.getElementById('config-group-modal').classList.add('show');
    setTimeout(() => document.getElementById('config-group-name').focus(), 0);
  },

  closeConfigGroupModal() {
    document.getElementById('config-group-modal').classList.remove('show');
  },

  async saveConfigGroup() {
    const id = document.getElementById('config-group-id').value;
    const name = document.getElementById('config-group-name').value.trim();
    if (!name) { this.showToast('Enter a group name', 'warning'); return; }
    const files = [...document.querySelectorAll('#config-group-checklist input:checked')].map(c => c.value);
    const btn = document.getElementById('save-config-group');
    btn.disabled = true;
    try {
      const form = new URLSearchParams({ id, name });
      files.forEach(file => form.append('file', file));
      const data = await this.api('group_save', { method: 'POST', body: form });
      if (data.status !== 'ok') throw new Error(data.error || 'Could not save group');
      this.state.activeConfigGroup = data.id;
      await this.api('settings', { params: { set: 'active_config_group', value: data.id } });
      this.closeConfigGroupModal();
      await this.loadConfigs(this.state.latencyCache);
      this.showToast(id ? 'Group updated' : 'Group created', 'success');
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { btn.disabled = false; }
  },

  async deleteConfigGroup() {
    const id = document.getElementById('config-group-id').value;
    const group = this.state.configGroups.find(g => g.id === id);
    if (!id || !confirm(`Delete group "${group?.name || id}"? Config files will not be deleted.`)) return;
    try {
      const data = await this.api('group_delete', { method: 'POST', body: new URLSearchParams({ id }) });
      if (data.status !== 'ok') throw new Error(data.error || 'Could not delete group');
      this.state.activeConfigGroup = 'all';
      this.closeConfigGroupModal();
      await this.loadConfigs(this.state.latencyCache);
      this.showToast('Group deleted', 'info');
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
  },

  async selectConfig(cfg) {
    if (this.vpnLocked()) { this.showToast('Disconnect VPN before changing server', 'warning'); return; }
    const vpnMode = document.querySelector('input[name="vpn-mode"]:checked')?.value || 'redirect';
    const dnsType = document.getElementById('dns-select')?.value || 'cloudflare';
    const ipVersion = ({ ipv4: 'prefer_ipv4', ipv6: 'prefer_ipv6', dual: 'prefer_ipv4' })[document.getElementById('ip-mode-select')?.value] || 'prefer_ipv4';
    const ipResolve = document.getElementById('ip-resolve-toggle')?.checked ? 'on' : 'off';
    try {
      const data = await this.api('select', { method: 'POST', body: new URLSearchParams({ file: cfg.file, vpn_mode: vpnMode, dns_type: dnsType, ip_version: ipVersion, ip_resolve: ipResolve }) });
      if (data.status === 'ok') {
        document.getElementById('config-file').textContent = 'config.json #' + cfg.alias;
        document.getElementById('show-config-link').style.display = 'inline';
        this.showToast(data.message ? this.stripTxt(data.message) : 'Config selected', 'success');
      } else {
        document.getElementById('config-file').textContent = '-';
        document.getElementById('show-config-link').style.display = 'none';
        document.getElementById('speedtest-link').style.display = 'inline-grid';
        this.showToast(data.error || 'Failed', 'error');
      }
    } catch (e) {
      document.getElementById('config-file').textContent = '-';
      this.showToast('Error: ' + e.message, 'error');
    }
  },

  async deleteConfig(file, cardEl) {
    try {
      const data = await this.api('delete', { params: { file } });
      if (data.success) { await this.loadConfigs(this.state.latencyCache); this.showToast('Deleted', 'info'); }
      else { alert('Failed: ' + data.error); }
    } catch (e) { alert('Network error'); }
  },

  vlessField(id) { return document.getElementById('ve-' + id); },

  setVlessForm(parsed = {}, mode = 'edit') {
    this.vlessField('alias').value = parsed.alias || '';
    this.vlessField('uuid').value = parsed.uuid || '';
    this.vlessField('host').value = parsed.host || '';
    this.vlessField('port').value = parsed.port || '443';
    this.vlessField('transport').value = parsed.network || 'tcp';
    this.vlessField('security').value = parsed.security || 'none';
    this.vlessField('path').value = parsed.path || '';
    this.vlessField('host-header').value = parsed.hostHeader || '';
    this.vlessField('xhttp-mode').value = parsed.mode || 'auto';
    this.vlessField('sni').value = parsed.sni || '';
    this.vlessField('allow-insecure').checked = parsed.allowInsecure === 'true' || parsed.allowInsecure === true;
    this.vlessField('fp').value = parsed.fingerprint || 'chrome';
    this.vlessField('pbk').value = parsed.publicKey || '';
    this.vlessField('sid').value = parsed.shortId || '';
    this.vlessField('flow').value = parsed.flow || '';
    document.getElementById('vless-edit-mode').value = mode;
    this.vlessField('transport').disabled = mode === 'edit';
    this.vlessField('security').disabled = mode === 'edit';
    this.refreshVlessEditor();
  },

  async openVlessEditor(file) {
    try {
      const data = await this.api('config_detail', { params: { file } });
      if (data.status !== 'ok') throw new Error(data.error || 'Could not load config');
      if (data.parsed?.proto !== 'vless') { this.showToast('Only VLESS edit is supported here', 'warning'); return; }
      document.getElementById('vless-editor-title').textContent = 'Edit VLESS';
      document.getElementById('vless-edit-file').value = file;
      this.setVlessForm(data.parsed, 'edit');
      document.getElementById('vless-editor-modal').classList.add('show');
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
  },

  openManualVlessEditor() {
    if (this.vpnLocked()) { this.showToast('Disconnect VPN before adding servers', 'warning'); return; }
    document.getElementById('vless-editor-title').textContent = 'Manual VLESS';
    document.getElementById('vless-edit-file').value = '';
    this.setVlessForm({ port: '443', encryption: 'none', network: 'ws', security: 'tls', path: '/', mode: 'auto', fingerprint: 'chrome' }, 'manual');
    document.getElementById('vless-editor-modal').classList.add('show');
  },

  closeVlessEditor() { document.getElementById('vless-editor-modal').classList.remove('show'); },

  async openWireGuardEditor(file) {
    try {
      const data = await this.api('config_detail', { params: { file } });
      if (data.status !== 'ok') throw new Error(data.error || 'Could not load config');
      if (data.parsed?.proto !== 'wg') throw new Error('This is not a WireGuard config');
      document.getElementById('wireguard-edit-file').value = file;
      document.getElementById('wireguard-edit-name').value = data.parsed.alias || '';
      const config = data.link_b64 ? atob(data.link_b64) : (data.link || '');
      document.getElementById('wireguard-edit-config').value = config.replace(/^\s*#\s*ZBOX_NAME\s*=.*(?:\r?\n)?/m, '');
      document.getElementById('wireguard-editor-modal').classList.add('show');
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
  },

  closeWireGuardEditor() { document.getElementById('wireguard-editor-modal').classList.remove('show'); },

  async saveWireGuardEditor() {
    const file = document.getElementById('wireguard-edit-file').value;
    const name = document.getElementById('wireguard-edit-name').value.replace(/[\r\n]/g, ' ').trim();
    const link = document.getElementById('wireguard-edit-config').value.replace(/\r/g, '').trim();
    if (!name) { this.showToast('Enter a WireGuard config name', 'warning'); return; }
    if (!/^\s*\[Interface\]/m.test(link) || !/^\s*\[Peer\]/m.test(link)) { this.showToast('Enter a valid WireGuard config', 'warning'); return; }
    const btn = document.getElementById('save-wireguard-editor');
    btn.disabled = true;
    try {
      const data = await this.api('config_update', { method: 'POST', body: new URLSearchParams({ file, link, config_name: name }) });
      if (data.status !== 'ok') throw new Error(data.error || 'Could not save config');
      this.closeWireGuardEditor();
      await this.loadConfigs(this.state.latencyCache);
      this.showToast('WireGuard updated', 'success');
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { btn.disabled = false; }
  },

  refreshVlessEditor() {
    const mode = document.getElementById('vless-edit-mode').value;
    const transport = this.vlessField('transport').value;
    const security = this.vlessField('security').value;
    const showAll = mode === 'manual';
    const showPath = showAll || ['ws', 'grpc', 'h2', 'httpupgrade', 'xhttp'].includes(transport);
    const showHost = showAll || ['ws', 'h2', 'httpupgrade', 'xhttp'].includes(transport);
    const showXhttp = showAll || transport === 'xhttp';
    const showTls = showAll || security === 'tls' || security === 'reality';
    const showReality = showAll || security === 'reality';
    document.querySelectorAll('.ve-path-field').forEach(el => { el.style.display = showPath ? '' : 'none'; });
    document.querySelectorAll('.ve-host-header-field').forEach(el => { el.style.display = showHost ? '' : 'none'; });
    document.querySelectorAll('.ve-xhttp-field').forEach(el => { el.style.display = showXhttp ? '' : 'none'; });
    document.querySelectorAll('.ve-tls-field').forEach(el => { el.style.display = showTls ? '' : 'none'; });
    document.querySelectorAll('.ve-reality-field').forEach(el => { el.style.display = showReality ? '' : 'none'; });
    document.getElementById('ve-preview').value = this.buildVlessLink();
  },

  buildVlessLink() {
    const uuid = this.vlessField('uuid').value.trim();
    const host = this.vlessField('host').value.trim();
    const port = this.vlessField('port').value.trim() || '443';
    const alias = this.vlessField('alias').value.trim();
    const transport = this.vlessField('transport').value;
    const security = this.vlessField('security').value;
    const params = new URLSearchParams();
    params.set('security', security || 'none');
    params.set('encryption', 'none');
    params.set('type', transport || 'tcp');
    const path = this.vlessField('path').value.trim();
    const hostHeader = this.vlessField('host-header').value.trim();
    const flow = this.vlessField('flow').value.trim();
    const sni = this.vlessField('sni').value.trim();
    const allowInsecure = this.vlessField('allow-insecure').checked;
    const fp = this.vlessField('fp').value.trim();
    const pbk = this.vlessField('pbk').value.trim();
    const sid = this.vlessField('sid').value.trim();
    if (path) params.set('path', path);
    if (hostHeader) params.set('host', hostHeader);
    if (transport === 'xhttp') params.set('mode', this.vlessField('xhttp-mode').value || 'auto');
    if (flow) params.set('flow', flow);
    if (sni) params.set('sni', sni);
    if (allowInsecure && security === 'tls') params.set('allowInsecure', '1');
    if (fp && (security === 'tls' || security === 'reality')) params.set('fp', fp);
    if (security === 'reality') {
      if (pbk) params.set('pbk', pbk);
      if (sid) params.set('sid', sid);
    }
    return `vless://${encodeURIComponent(uuid)}@${host}:${port}?${params.toString()}${alias ? '#' + encodeURIComponent(alias) : ''}`;
  },

  async saveVlessEditor() {
    const link = this.buildVlessLink();
    if (!this.vlessField('uuid').value.trim() || !this.vlessField('host').value.trim()) { this.showToast('UUID and address are required', 'warning'); return; }
    const btn = document.getElementById('save-vless-editor');
    btn.disabled = true;
    try {
      const mode = document.getElementById('vless-edit-mode').value;
      const file = document.getElementById('vless-edit-file').value;
      const body = mode === 'manual'
        ? new URLSearchParams({ link })
        : new URLSearchParams({ file, link });
      const data = await this.api(mode === 'manual' ? 'apply' : 'config_update', { method: 'POST', body });
      if (data.status !== 'ok') throw new Error(data.error || 'Could not save config');
      this.closeVlessEditor();
      await this.loadConfigs(this.state.latencyCache);
      this.showToast(mode === 'manual' ? 'VLESS added' : 'VLESS updated', 'success');
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { btn.disabled = false; }
  },

  async fetchLatency() {
    if (this.state.latencyRequest) return this.state.latencyRequest;
    const protocol = this.state.protocolMode;
    this.state.latencyProtocol = protocol;
    this.state.latencyRequest = this.api('latency', { params: { proto: protocol } });
    try {
      const data = await this.state.latencyRequest;
      if (protocol === this.state.protocolMode && Array.isArray(data) && !data[0]?.error) { this.state.latencyCache = data; this.state.latencyCacheTime = Date.now(); this.updateLatencies(data); }
      return data;
    } catch (e) {
      return null;
    } finally {
      this.state.latencyRequest = null;
      this.state.latencyProtocol = null;
      if (protocol !== this.state.protocolMode) this.fetchLatency();
    }
  },

  updateLatencies(data) {
    data.forEach(item => {
      const el = document.getElementById('lat-' + this.escId(item.file));
      if (el && item.latency !== null) el.textContent = item.latency + ' ms';
    });
  },

  async suggestBest() {
    const btn = document.getElementById('suggest-best');
    const orig = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner mini-spinner"></span>';
    this.showToast('Testing best server...', 'info', 2500);
    const t = setTimeout(() => { btn.disabled = false; btn.innerHTML = orig; this.showToast('Timed out', 'error'); }, 60000);
    try {
      const protocol = this.state.protocolMode;
      if (this.state.latencyRequest && this.state.latencyProtocol !== protocol) {
        await this.state.latencyRequest;
      }
      const data = this.state.latencyRequest
        ? await this.state.latencyRequest
        : await this.api('latency', { params: { force: '1', proto: protocol } });
      clearTimeout(t);
      if (!Array.isArray(data) || !data.length) throw new Error('No results');
      const visibleFiles = new Set(this.configsForProtocol().map(cfg => cfg.file));
      const valid = data.filter(d => d.latency !== null && visibleFiles.has(d.file));
      if (!valid.length) throw new Error('All servers failed');
      const best = valid.reduce((a, b) => a.latency < b.latency ? a : b);
      this.showToast(`Succesfully Select Best Server: ${this.configDisplayName(best.file)} (${best.latency} ms)`, 'success', 7000);
      const vpnMode = document.querySelector('input[name="vpn-mode"]:checked')?.value || 'redirect';
      const dnsType = document.getElementById('dns-select')?.value || 'cloudflare';
      const ipVersion = ({ ipv4: 'prefer_ipv4', ipv6: 'prefer_ipv6', dual: 'prefer_ipv4' })[document.getElementById('ip-mode-select')?.value] || 'prefer_ipv4';
      const ipResolve = document.getElementById('ip-resolve-toggle')?.checked ? 'on' : 'off';
      await this.api('select', { method: 'POST', body: new URLSearchParams({ file: best.file, proto: protocol, vpn_mode: vpnMode, dns_type: dnsType, ip_version: ipVersion, ip_resolve: ipResolve }) });
      this.loadConfigs(data);
    } catch (e) { this.showToast('Error: ' + e.message, 'error'); }
    finally { clearTimeout(t); btn.disabled = false; btn.innerHTML = orig; }
  },

  async refreshStatus() {
    try {
      const data = await this.api('status');
      this.renderStatus(data);
    } catch (e) {}
  },

  renderStatus(data) {
    const wasConnected = this.state.lastStatus === 'Connected';
    const nextConnected = data.status === 'Connected';
    const nextGroup = data.fallback_group || this.state.activeConfigGroup || 'all';
    const groupChanged = nextConnected && this.state.activeConfigGroup !== nextGroup;
    this.state.fallbackGroup = nextGroup;
    this.state.fallbackMainConfig = data.fallback_main_config || '';
    this.state.fallbackCurrentConfig = data.fallback_current_config || data.config_file || '';
    this.state.fallbackUsingBackup = data.fallback_using_backup || 'false';
    this.state.autoFallback = data.autofallback || 'off';
    if (nextConnected) this.state.activeConfigGroup = nextGroup;

    document.getElementById('model-name').textContent = data.model || '-';
    document.getElementById('config-file').textContent = this.configDisplayName(data.config_file || '-');
    if (data.config_file && data.config_file !== '-') { document.getElementById('show-config-link').style.display = 'inline'; }
    else { document.getElementById('show-config-link').style.display = 'none'; }
    document.getElementById('isp-ip').textContent = data.isp_ip || '-';
    document.getElementById('vpn-ip').textContent = data.vpn_ip || '-';
    this.renderVpnCountry(data.vpn_ip || '', data.status);
    document.getElementById('uptime').textContent = data.uptime || '-';
    document.getElementById('memory').textContent = data.memory || '-';
    document.getElementById('usage').textContent = data.usage || '-';
    const sEl = document.getElementById('vpn-status');
    sEl.textContent = data.status;
    sEl.style.color = data.status === 'Connected' ? 'green' : 'red';
    document.getElementById('vpn-isp').textContent = data.status === 'Connected' ? (data.vpn_isp || '') : '';
    document.getElementById('vpn-duration').textContent = data.status === 'Connected' && data.vpn_duration ? data.vpn_duration : '';
    const latency = document.getElementById('vpn-latency');
    latency.textContent = data.status !== 'Connected' ? '' : data.vpn_latency_status === 'ok' ? `${data.vpn_latency} ms` : data.vpn_latency_status ? '' : 'Checking';
    latency.className = `status-pill vpn-latency ${data.vpn_latency_status === 'ok' && Number(data.vpn_latency) > 180 ? 'warning' : ''}`;
    this.updateButtons(data.status);
    this.toggleCards(data.status === 'Connected');
    document.body.classList.toggle('vpn-connected', nextConnected);
    if (!wasConnected && nextConnected && document.getElementById('auto-check-update').checked) this.checkForUpdates(true);
    const statusCard = document.querySelector('.status-card');
    if (statusCard) {
      if (!wasConnected && nextConnected) statusCard.classList.add('connected-summary');
      if (!nextConnected) statusCard.classList.remove('connected-summary');
    }
    document.getElementById('speedtest-link').style.display = 'inline-grid';

    const licEl = document.getElementById('license-status');
    if (data.license_status === 'ACTIVATED') { licEl.textContent = 'ACTIVATED'; licEl.style.color = 'green'; this.state.licenseActive = true; }
    else { licEl.textContent = 'NOT ACTIVE'; licEl.style.color = 'red'; this.state.licenseActive = false; }

    const at = document.getElementById('autorun-toggle');
    const al = at.closest('.toggle-wrap')?.querySelector('.toggle-label');
    const as = at.closest('.toggle-wrap')?.querySelector('.tile-labels span');
    if (!data.config_file || data.config_file === '-') { at.checked = false; at.disabled = true; if (al) { al.textContent = 'Autorun: OFF'; al.className = 'toggle-label disabled'; } if (as) as.textContent = 'OFF'; }
    else { at.disabled = false; at.checked = data.autorun === 'on'; if (al) { al.textContent = 'Autorun: ' + (data.autorun === 'on' ? 'ON' : 'OFF'); al.className = 'toggle-label ' + (data.autorun === 'on' ? 'on' : 'off'); } if (as) as.textContent = data.autorun === 'on' ? 'ON' : 'OFF'; }

    const af = document.getElementById('autofallback-toggle');
    const afl = af.closest('.toggle-wrap')?.querySelector('.toggle-label');
    const afs = af.closest('.toggle-wrap')?.querySelector('.tile-labels span');
    if (!data.config_file || data.config_file === '-') { af.checked = false; af.disabled = true; if (afl) { afl.textContent = 'Auto Fallback: OFF'; afl.className = 'toggle-label disabled'; } if (afs) afs.textContent = 'OFF'; }
    else { af.disabled = false; af.checked = data.autofallback === 'on'; if (afl) { afl.textContent = 'Auto Fallback: ' + (data.autofallback === 'on' ? 'ON' : 'OFF'); afl.className = 'toggle-label ' + (data.autofallback === 'on' ? 'on' : 'off'); } if (afs) afs.textContent = data.autofallback === 'on' ? 'ON' : 'OFF'; }

    this.updateToggleLabel('ip-resolve');

    const icons = document.getElementById('vpn-icons-container');
    if (data.status === 'Connected') {
      icons.style.display = 'flex';
      document.getElementById('vpn-core-name').textContent = data.vpn_mode === 'redirect' ? (data.vpn_type === 'singbox' ? 'SING-BOX' : 'XRAY CORE') : 'SING-BOX';
      document.getElementById('vpn-mode-text').textContent = (data.vpn_mode || 'redirect').toUpperCase();
      document.getElementById('core-protocol-alt').textContent = (data.protocol || '').toUpperCase();
    } else { icons.style.display = 'none'; }
    this.state.lastStatus = data.status;
    if (wasConnected !== nextConnected || groupChanged) {
      this.renderConfigGroupTabs();
      this.renderConfigCards();
    }
  },

  toggleCards(connected) {
    document.querySelectorAll('.card').forEach(card => {
      const t = card.querySelector('h2')?.textContent.trim();
      if (t === 'VPN Control') card.style.display = connected ? 'none' : 'block';
    });
  },

  renderVpnCountry(vpnIpText, status) {
    const elements = [document.getElementById('vpn-country'), document.getElementById('connected-status-country')].filter(Boolean);
    if (!elements.length) return;
    if (status !== 'Connected' || !vpnIpText || vpnIpText === '-') {
      elements.forEach(el => { el.style.display = 'none'; el.textContent = ''; });
      return;
    }
    const parts = vpnIpText.split('|').map(p => p.trim()).filter(Boolean);
    const country = parts[parts.length - 1] || '';
    const code = this.countryFlagCode(country);
    if (!country) {
      elements.forEach(el => { el.style.display = 'none'; el.textContent = ''; });
      return;
    }
    const flag = code
      ? `<span class="flag flag-img" title="${this.esc(country)}" style="background-image:url('img/${code}.png')"></span>`
      : `<span class="flag flag-code" title="${this.esc(country)}">${this.esc(country.slice(0, 2).toUpperCase() || '?')}</span>`;
    elements.forEach(el => { el.innerHTML = flag; el.style.display = 'flex'; });
  },

  countryFlagCode(country) {
    const map = {
      'Malaysia': 'my', 'Singapore': 'sg', 'Indonesia': 'id', 'Thailand': 'th', 'Vietnam': 'vn',
      'Philippines': 'ph', 'Cambodia': 'kh', 'Japan': 'jp', 'South Korea': 'kr', 'Korea': 'kr',
      'Hong Kong': 'hk', 'Taiwan': 'tw', 'China': 'cn', 'India': 'in', 'United States': 'us',
      'United Kingdom': 'gb', 'Germany': 'de', 'France': 'fr', 'Netherlands': 'nl', 'Canada': 'ca',
      'Australia': 'au', 'Russia': 'ru', 'Brazil': 'br', 'Turkey': 'tr', 'United Arab Emirates': 'ae'
    };
    return map[country] || '';
  },

  toggleLogs() {
    const log = document.getElementById('sing-box-log');
    const btn = document.getElementById('toggle-log');
    if (log.style.display === 'block') { log.style.display = 'none'; btn.textContent = 'Show Logs'; if (this.state.logInterval) clearInterval(this.state.logInterval); }
    else { log.style.display = 'block'; btn.textContent = 'Hide Logs'; this.fetchLog(); this.state.logInterval = setInterval(() => { if (document.getElementById('vpn-status').textContent === 'Connected') this.fetchLog(); }, 2000); }
  },

  toggleLogSize() { document.getElementById('sing-box-log').classList.toggle('expanded'); },

  async fetchLog() {
    try {
      const text = await this.api('logs');
      const lines = text.split('\n').slice(-20);
      document.getElementById('sing-box-log').textContent = lines.join('\n');
      document.getElementById('sing-box-log').scrollTop = document.getElementById('sing-box-log').scrollHeight;
    } catch (e) {}
  },

  async showConfig() {
    try {
      const text = await this.api('config');
      document.getElementById('config-json-text').textContent = text;
      document.getElementById('config-json-text').style.display = 'block';
      document.getElementById('speedtest-panel-row').style.display = 'none';
      document.getElementById('config-panel-row').style.display = 'block';
      document.getElementById('show-config-link').textContent = '[Hide]';
    } catch (e) {
      document.getElementById('config-json-text').textContent = 'Failed to load config';
      document.getElementById('speedtest-panel-row').style.display = 'none';
      document.getElementById('config-panel-row').style.display = 'block';
      document.getElementById('show-config-link').textContent = '[Hide]';
    }
  },

  renderSpeedtestPanel() {
    const resultEl = document.getElementById('speedtest-result');
    resultEl.innerHTML = `
      <div class="speedtest-panel">
        <div class="speedtest-heading"><h3>Speedtest</h3><span id="speedtest-time">Running</span></div>
        <div id="speedtest-status" class="speedtest-phase">Checking IP...</div>
        <div class="speedtest-metrics">
          <div class="speedtest-metric"><span>DOWNLOAD</span><div id="speedtest-download-dial" class="speedtest-dial"><div class="speedtest-dial-content"><strong id="speedtest-download">0.00</strong><small>Mbps</small></div></div><small id="speedtest-download-state" class="speedtest-meter-state">Waiting</small></div>
          <div class="speedtest-metric"><span>UPLOAD</span><div id="speedtest-upload-dial" class="speedtest-dial"><div class="speedtest-dial-content"><strong id="speedtest-upload">0.00</strong><small>Mbps</small></div></div><small id="speedtest-upload-state" class="speedtest-meter-state">Waiting</small></div>
          <div class="speedtest-metric"><span>PING</span><strong id="speedtest-ping">Testing...</strong></div>
        </div>
        <div id="speedtest-meta" class="speedtest-meta">VPN IP: Checking...<br>Server: Checking...</div>
        <div class="speedtest-actions">
          <button type="button" id="speedtest-rerun" class="btn btn-primary btn-sm" disabled>Run Again</button>
          <button type="button" id="speedtest-details-toggle" class="btn btn-outline btn-sm">Show Details</button>
        </div>
        <div id="speedtest-details" class="speedtest-details"><h4>Latest test</h4><pre id="speedtest-raw"></pre><h4>Recent history</h4><pre id="speedtest-history"></pre></div>
      </div>`;
    document.getElementById('speedtest-rerun').addEventListener('click', () => this.runSpeedTest());
    document.getElementById('speedtest-details-toggle').addEventListener('click', () => {
      const details = document.getElementById('speedtest-details');
      const visible = details.classList.toggle('show');
      document.getElementById('speedtest-details-toggle').textContent = visible ? 'Hide Details' : 'Show Details';
    });
  },

  updateSpeedtestProgress(stage) {
    const labels = ['Checking IP...', 'Finding server...', 'Testing download...', 'Testing upload...'];
    const status = document.getElementById('speedtest-status');
    if (status) status.textContent = stage < labels.length ? labels[stage] : 'Speedtest complete';
    const sweep = 22 + ((Date.now() / 45) % 66);
    if (stage < 2) {
      this.setSpeedtestDial('download', 0, 'Waiting', false);
      this.setSpeedtestDial('upload', 0, 'Waiting', false);
    } else if (stage === 2) {
      this.setSpeedtestDial('download', sweep, 'Testing...', true);
      this.setSpeedtestDial('upload', 0, 'Waiting', false);
    } else if (stage === 3) {
      this.setSpeedtestDial('download', 94, 'Finishing...', true);
      this.setSpeedtestDial('upload', sweep, 'Measuring', true);
    }
  },

  setSpeedtestDial(metric, value, state, measuring) {
    const dial = document.getElementById(`speedtest-${metric}-dial`);
    const stateEl = document.getElementById(`speedtest-${metric}-state`);
    if (!dial || !stateEl) return;
    dial.style.setProperty('--meter', Math.max(0, Math.min(100, value)));
    dial.classList.toggle('measuring', measuring);
    stateEl.textContent = state;
  },

  updateLiveSpeedtest(progress) {
    const speed = (value) => (Number(value) || 0).toFixed(2);
    if (progress.stage === 'preparing') {
      this.updateSpeedtestProgress(0);
    } else if (progress.stage === 'server') {
      this.updateSpeedtestProgress(1);
    } else if (progress.stage === 'download') {
      this.updateSpeedtestProgress(2);
      document.getElementById('speedtest-download').textContent = speed(progress.download);
      this.setSpeedtestDial('download', Number(progress.download) || 0, 'Testing...', true);
    } else if (progress.stage === 'upload') {
      this.updateSpeedtestProgress(3);
      document.getElementById('speedtest-download').textContent = speed(progress.download);
      document.getElementById('speedtest-upload').textContent = speed(progress.upload);
      this.setSpeedtestDial('download', Number(progress.download) || 0, '', false);
      this.setSpeedtestDial('upload', Number(progress.upload) || 0, 'Testing...', true);
    }
  },

  showSpeedtestResult(history) {
    const runs = history.split('=== Speedtest Started ===').filter(run => run.trim());
    const latest = runs[runs.length - 1] || history;
    const read = (label) => latest.match(new RegExp(`^${label}\\s*:\\s*(.+)$`, 'm'))?.[1]?.trim() || '-';
    const download = read('Download');
    const upload = read('Upload');
    const downloadValue = Number.parseFloat(download) || 0;
    const uploadValue = Number.parseFloat(upload) || 0;
    document.getElementById('speedtest-download').textContent = downloadValue.toFixed(2);
    document.getElementById('speedtest-upload').textContent = uploadValue.toFixed(2);
    document.getElementById('speedtest-ping').textContent = read('Latency');
    this.setSpeedtestDial('download', downloadValue, '', false);
    this.setSpeedtestDial('upload', uploadValue, '', false);
    document.getElementById('speedtest-meta').textContent = `Route: ${read('Route').toUpperCase()} | IP: ${read('IP')}\nISP: ${read('SERVER')}\nServer: ${read('Test Server')} | ${read('Location')}`;
    document.getElementById('speedtest-time').textContent = `Completed ${read('Test completed')}`;
    document.getElementById('speedtest-raw').textContent = `=== Speedtest Started ===${latest}`;
    document.getElementById('speedtest-history').textContent = history;
    document.getElementById('speedtest-rerun').disabled = false;
  },

  async runSpeedTest() {
    if (this.state.speedtestRunning) return;
    this.state.speedtestRunning = true;
    const statusCard = document.querySelector('.status-card');
    if (this.state.lastStatus === 'Connected') statusCard.classList.add('connected-summary');
    statusCard.querySelector('.card-body').style.display = 'block';
    const resultEl = document.getElementById('speedtest-result');
    resultEl.style.display = 'block';
    document.getElementById('config-json-text').style.display = 'none';
    document.getElementById('config-panel-row').style.display = 'none';
    document.getElementById('speedtest-panel-row').style.display = 'block';
    document.getElementById('speedtest-link').style.pointerEvents = 'none';
    document.getElementById('speedtest-link').style.opacity = '0.6';
    this.renderSpeedtestPanel();
    this.updateSpeedtestProgress(0);
    let liveUpdates = true;
    const progressTimer = setInterval(() => {
      this.api('speedtest_progress').then(progress => { if (liveUpdates) this.updateLiveSpeedtest(progress); }).catch(() => {});
    }, 1000);
    try {
      await this.api('speedtest');
      const history = await this.api('speedtest', { params: { log: '1' } });
      clearInterval(progressTimer);
      liveUpdates = false;
      this.updateSpeedtestProgress(4);
      this.showSpeedtestResult(history);
    } catch (e) {
      clearInterval(progressTimer);
      liveUpdates = false;
      document.getElementById('speedtest-status').textContent = 'Speed test failed';
      document.getElementById('speedtest-time').textContent = 'Failed';
      document.getElementById('speedtest-meta').textContent = e.message;
      document.getElementById('speedtest-rerun').disabled = false;
    } finally {
      this.state.speedtestRunning = false;
      document.getElementById('speedtest-link').style.pointerEvents = 'auto';
      document.getElementById('speedtest-link').style.opacity = '1';
    }
  },

  async checkLicense() {
    try {
      const data = await this.api('license_status');
      this.state.licenseActive = data.status === 'ACTIVATED';
      return this.state.licenseActive;
    } catch { return false; }
  },

  async showLicenseModal() {
    const active = await this.checkLicense();
    if (active) await this.showLicenseInfo();
    else await this.showActivationForm();
  },

  async showActivationForm() {
    try {
      const token = await this.api('gen_token');
      document.getElementById('device-token').value = (token || '').trim();
      document.getElementById('license-key').value = '';
      document.getElementById('license-message').style.display = 'none';
      document.getElementById('license-activation-form').style.display = 'block';
      document.getElementById('license-info').style.display = 'none';
      document.getElementById('license-modal-title').textContent = 'License Activation Required';
      document.getElementById('license-modal-overlay').classList.add('show');
    } catch (e) { this.showToast('Failed to get token', 'error'); }
  },

  async showLicenseInfo() {
    try {
      const data = await this.api('license_status');
      document.getElementById('activated-license-key').value = data.license_key || '';
      document.getElementById('license-issue-date').textContent = data.issue_date || '-';
      document.getElementById('license-activation-status').textContent = data.status || '';
      document.getElementById('license-info').style.display = 'block';
      document.getElementById('license-activation-form').style.display = 'none';
      document.getElementById('license-modal-title').textContent = 'License Info';
      document.getElementById('license-modal-overlay').classList.add('show');
    } catch { document.getElementById('license-modal-overlay').classList.add('show'); }
  },

  hideLicenseModal() { document.getElementById('license-modal-overlay').classList.remove('show'); },

  async validateLicenseForm() {
    const key = document.getElementById('license-key').value.trim();
    if (!key) { this.showLicenseMsg('Enter a license key', 'red'); return; }
    const btn = document.getElementById('validate-license');
    btn.disabled = true; btn.textContent = 'Validating...';
    try {
      const text = await this.api('validate_license', { params: { key } });
      if (text.includes('SUCCESS')) {
        this.showLicenseMsg('✓ Activated!', 'green');
        setTimeout(() => { this.hideLicenseModal(); this.refreshStatus(); this.showToast('License activated!', 'success'); }, 2000);
      } else { this.showLicenseMsg(text.replace('ERROR: ', ''), 'red'); }
    } catch (e) { this.showLicenseMsg('Network error: ' + e.message, 'red'); }
    finally { btn.disabled = false; btn.textContent = 'Activate License'; }
  },

  async deleteLicense() {
    if (!confirm('Are you sure to Delete this license key?.')) return;
    const btn = document.getElementById('delete-license');
    btn.disabled = true; btn.setAttribute('aria-label', 'Deleting license key');
    try {
      const data = await this.api('delete_license', { method: 'POST', body: new URLSearchParams({ confirm: 'DELETE' }) });
      if (data.status !== 'success') throw new Error(data.message || 'Unable to delete license key');
      this.hideLicenseModal();
      await this.refreshStatus();
      this.showToast('License key deleted. VPN disconnected.', 'success');
    } catch (e) { this.showToast(e.message || 'Unable to delete license key', 'error'); }
    finally { btn.disabled = false; btn.setAttribute('aria-label', 'Delete License Key'); }
  },

  showLicenseMsg(msg, color) {
    const el = document.getElementById('license-message');
    el.innerHTML = '<div style="color:' + color + '">' + msg + '</div>';
    el.style.display = 'block';
  },

  copyToken() { const el = document.getElementById('device-token'); el.select(); document.execCommand('copy'); this.showToast('Copied!', 'success'); },

  async fetchVersion() {
    try { const t = await this.api('version'); document.getElementById('version-text').textContent = (t || '').trim() || 'n/a'; }
    catch { document.getElementById('version-text').textContent = 'n/a'; }
  },

  updateVersions(data) {
    const items = [['ZBOX Panel', 'panel', data.panel], ['Xray Core', 'xray', data.xray], ['sing-box Core', 'singbox', data.singbox]];
    const container = document.getElementById('update-versions');
    container.replaceChildren();
    items.forEach(([name, component, value]) => {
      const available = value?.available || '';
      const installed = value?.installed || 'not installed';
      const installedLabel = installed === 'not installed' || installed.startsWith('unknown') ? installed : `v${installed}`;
      const canUpdate = available && this.isNewerVersion(available, installed);
      const row = document.createElement('div');
      row.className = 'update-version-row';
      const summary = document.createElement('div');
      const title = document.createElement('strong'); title.textContent = name;
      const versions = document.createElement('span'); versions.textContent = installedLabel;
      summary.append(title, versions);
      if (available) {
        const details = document.createElement('button');
        details.type = 'button'; details.className = 'link-button update-latest-link'; details.textContent = `Latest: v${available}`;
        details.addEventListener('click', () => this.openUpdateDetails(component, name, available, value?.notes_b64 || '', canUpdate));
        summary.append(details);
      }
      const action = document.createElement('button');
      action.type = 'button'; action.className = `btn ${canUpdate ? 'btn-primary' : 'btn-outline'} btn-sm update-component`;
      action.dataset.component = component;
      action.textContent = canUpdate || component === 'panel' ? 'Update' : 'Change';
      action.disabled = component === 'panel' && !canUpdate;
      action.addEventListener('click', () => canUpdate || component === 'panel' ? this.updateComponent(component) : this.changeCore(component));
      row.append(summary, action);
      container.appendChild(row);
    });
  },

  showUpdateVersionsLoading() {
    const container = document.getElementById('update-versions');
    container.replaceChildren();
    ['ZBOX Panel', 'Xray Core', 'sing-box Core'].forEach(name => {
      const row = document.createElement('div'); row.className = 'update-version-row';
      const summary = document.createElement('div');
      const title = document.createElement('strong'); title.textContent = name;
      const installed = document.createElement('span'); installed.className = 'update-version-placeholder'; installed.textContent = '\u00a0';
      const action = document.createElement('button'); action.type = 'button'; action.className = 'btn btn-primary btn-sm update-component'; action.textContent = 'Update'; action.tabIndex = -1; action.style.visibility = 'hidden';
      summary.append(title, installed); row.append(summary, action); container.append(row);
    });
  },

  setUpdateChecking(checking) { document.getElementById('update-message').classList.toggle('checking', checking); },

  decodeVerifiedNotes(notesB64) {
    if (!notesB64) return 'No release notes were provided.';
    try {
      const bytes = Uint8Array.from(atob(notesB64), c => c.charCodeAt(0));
      return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    } catch { return 'Release notes could not be decoded.'; }
  },

  isNewerVersion(available, installed) {
    const match = String(installed).match(/\d+(?:\.\d+)+/);
    if (!match) return true;
    const current = match[0].split('.').map(Number);
    const latest = String(available).split('.').map(Number);
    for (let i = 0; i < Math.max(current.length, latest.length); i++) {
      if ((latest[i] || 0) !== (current[i] || 0)) return (latest[i] || 0) > (current[i] || 0);
    }
    return false;
  },

  openUpdateDetails(component, name, version, notesB64, canUpdate = true) {
    this.state.updateDetails = { component };
    document.getElementById('update-details-title').textContent = `${name} Update`;
    document.getElementById('update-details-version').textContent = `Version ${version}. Update Changelog.`;
    const notes = document.getElementById('update-details-notes');
    notes.replaceChildren();
    this.decodeVerifiedNotes(notesB64).split(/\r?\n/).map(line => line.replace(/^\s*[-*]\s*/, '').trim()).filter(Boolean).forEach(line => {
      const item = document.createElement('li');
      const mark = document.createElement('span'); mark.className = 'whats-new-check'; mark.textContent = '✓';
      const text = document.createElement('span'); text.textContent = line;
      item.append(mark, text); notes.appendChild(item);
    });
    if (!notes.children.length) {
      const item = document.createElement('li'); item.textContent = 'No release notes were provided.'; notes.appendChild(item);
    }
    document.getElementById('install-update-details').style.display = canUpdate ? '' : 'none';
    document.getElementById('update-details-modal').classList.add('show');
  },

  closeUpdateDetails() { document.getElementById('update-details-modal').classList.remove('show'); },

  renderUpdateProgress(data) {
    const percent = Math.max(0, Math.min(100, Number(data?.percent) || 0));
    document.getElementById('update-progress-stage').textContent = data?.stage || 'Preparing';
    document.getElementById('update-progress-message').textContent = data?.message || 'Preparing update...';
    document.getElementById('update-progress-bar').style.width = `${percent}%`;
    document.getElementById('update-progress-percent').textContent = `${percent}%`;
  },

  startUpdateProgress(message) {
    this.renderUpdateProgress({ stage: 'Connecting', percent: 1, message });
    document.getElementById('update-progress-modal').classList.add('show');
    if (this.state.updateProgressTimer) clearInterval(this.state.updateProgressTimer);
    this.state.updateProgressTimer = setInterval(async () => {
      try { this.renderUpdateProgress(await this.api('update_progress')); } catch (e) {}
    }, 500);
  },

  stopUpdateProgress() {
    if (this.state.updateProgressTimer) clearInterval(this.state.updateProgressTimer);
    this.state.updateProgressTimer = null;
  },

  showUpdateProgressError(message) {
    this.stopUpdateProgress();
    this.renderUpdateProgress({ stage: 'Error', percent: 100, message });
    setTimeout(() => document.getElementById('update-progress-modal').classList.remove('show'), 3500);
  },

  setUpdateMessage(message, type = '') {
    const el = document.getElementById('update-message');
    const checking = el.classList.contains('checking');
    el.textContent = message;
    el.className = 'update-message ' + type + (checking ? ' checking' : '');
  },

  async openUpdateCenter() {
    document.getElementById('update-modal-overlay').classList.add('show');
    this.setUpdateMessage('');
    if (this.state.lastUpdateCheck) {
      this.updateVersions(this.state.lastUpdateCheck);
      this.setUpdateMessage(this.state.lastUpdateCheck.update_available ? 'Newers update available.' : 'this the newers version of ZBOX.', 'success');
      return;
    }
    this.showUpdateVersionsLoading();
    this.setUpdateChecking(true);
    this.setUpdateMessage('Checking versions...');
    let autoCheck = false;
    try {
      const data = await this.api('update_status');
      this.updateVersions(data);
      autoCheck = document.getElementById('auto-check-update').checked;
    } catch { this.setUpdateMessage('Unable to read installed versions.', 'error'); }
    finally { this.setUpdateChecking(false); if (!autoCheck) this.setUpdateMessage(''); }
    if (autoCheck) this.checkForUpdates();
  },

  closeUpdateCenter() { document.getElementById('update-modal-overlay').classList.remove('show'); },

  setUpdateAvailable(available) {
    this.state.updateAvailable = available;
    const version = document.getElementById('open-update-center');
    version.classList.toggle('update-available', available);
    version.title = available ? 'New update available' : 'Open Update Center';
  },

  async checkForUpdates(background = false) {
    const btn = document.getElementById('check-update');
    const loading = document.getElementById('check-update-loading');
    btn.disabled = true; loading.hidden = background; if (!background) this.setUpdateMessage('Checking for new update...');
    try {
      const data = await this.api('update_check');
      if (data.status !== 'success') throw new Error(data.message || 'Signature verification failed');
      this.state.lastUpdateCheck = data;
      this.updateVersions(data);
      this.setUpdateAvailable(Boolean(data.update_available));
      if (!background) this.setUpdateMessage(data.update_available ? 'Newers update available.' : 'this the newers version of ZBOX.', 'success');
    } catch (e) { if (!background) this.setUpdateMessage(e.message || 'Update check failed.', 'error'); }
    finally { btn.disabled = false; loading.hidden = true; }
  },

  async updateComponent(component) {
    const name = component === 'panel' ? 'ZBOX Panel' : component === 'xray' ? 'Xray Core' : 'sing-box Core';
    if (this.vpnLocked()) { this.showToast('ERROR : Please disconnect VPN before install update.', 'error'); return; }
    if (!confirm(`Install the verified ${name} update?`)) return;
    this.closeUpdateDetails();
    const btn = document.querySelector(`.update-component[data-component="${component}"]`);
    btn.disabled = true; this.setUpdateMessage('Downloading, verifying, and staging update...');
    this.startUpdateProgress('Connecting to update server...');
    try {
      const data = await this.api('update_install', { method: 'POST', body: new URLSearchParams({ source: 'ota', component }) });
      if (data.status !== 'success') throw new Error(data.message || 'Installation failed');
      this.setUpdateMessage('Verified update installed. Reloading panel...', 'success');
      setTimeout(() => location.reload(), 1500);
    } catch (e) { const message = e.message || 'Installation failed.'; this.showUpdateProgressError(message); this.setUpdateMessage(message, 'error'); btn.disabled = false; }
    finally { this.stopUpdateProgress(); }
  },

  changeCore(component) {
    const name = component === 'xray' ? 'Xray Core' : 'sing-box Core';
    if (!confirm(`Replace ${name} with a user-supplied raw executable? This is not a signed .zbox update. The current binary will be backed up and the VPN will not be restarted.`)) return;
    this.state.customCoreComponent = component;
    this.setUpdateMessage(`Choose a raw ${name} executable supplied by you.`);
    document.getElementById('custom-core-package').click();
  },

  async uploadOfflineUpdate(file) {
    if (!file) return;
    if (!file.name.endsWith('.zbox')) { this.setUpdateMessage('Choose a .zbox offline bundle.', 'error'); return; }
    const dropzone = document.getElementById('offline-dropzone');
    dropzone.style.pointerEvents = 'none'; this.setUpdateMessage('Uploading offline bundle...');
    this.startUpdateProgress('Uploading offline bundle...');
    try {
      const r = await fetch(`${API}?action=update_upload`, { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: file });
      const data = await r.json();
      if (data.status !== 'success') throw new Error(data.message || 'Upload failed');
      this.setUpdateMessage('Verifying and staging offline bundle...');
      const result = await this.api('update_install', { method: 'POST', body: new URLSearchParams({ source: 'upload', component: 'all' }) });
      if (result.status !== 'success') throw new Error(result.message || 'Installation failed');
      this.setUpdateMessage('Offline update installed. Reloading panel...', 'success');
      setTimeout(() => location.reload(), 1500);
    } catch (e) { const message = e.message || 'Offline update failed.'; this.showUpdateProgressError(message); this.setUpdateMessage(message, 'error'); }
    finally { this.stopUpdateProgress(); dropzone.style.pointerEvents = ''; document.getElementById('offline-package').value = ''; }
  },

  async uploadCustomCore(file, component) {
    const name = component === 'xray' ? 'Xray' : 'sing-box';
    if (!file || !['xray', 'singbox'].includes(component)) return;
    this.setUpdateMessage(`Uploading user-supplied ${name} executable...`);
    this.startUpdateProgress(`Uploading user-supplied ${name} executable...`);
    try {
      const r = await fetch(`${API}?action=core_upload&component=${encodeURIComponent(component)}`, { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: file });
      const data = await r.json();
      if (data.status !== 'success') throw new Error(data.message || 'Core upload failed');
      const result = await this.api('core_install', { method: 'POST', body: new URLSearchParams({ component }) });
      if (result.status !== 'success') throw new Error(result.message || 'Core installation failed');
      this.setUpdateMessage(`${name} custom core installed. VPN was not restarted.`, 'success');
      await this.openUpdateCenter();
    } catch (e) {
      const message = e.message || 'Custom core installation failed.';
      this.showUpdateProgressError(message);
      this.setUpdateMessage(message, 'error');
    } finally {
      this.stopUpdateProgress();
      document.getElementById('custom-core-package').value = '';
      this.state.customCoreComponent = '';
    }
  },

  detectProtocol(link) {
    let p = 'Unknown';
    if (link.startsWith('vless://')) p = 'VLESS';
    else if (link.startsWith('trojan://')) p = 'Trojan';
    else if (link.includes('[Interface]')) p = 'WG';
    else p = 'Unknown';
    document.getElementById('core-protocol-alt').textContent = p;
  },

  updateToggleLabel(type) {
    if (type === 'ip-resolve') {
      const t = document.getElementById('ip-resolve-toggle');
      const l = t.closest('.toggle-wrap')?.querySelector('.toggle-label');
      const sub = t.closest('.toggle-wrap')?.querySelector('.tile-labels span');
      if (l) { const o = t.checked; l.textContent = 'IP Resolve: ' + (o ? 'ON' : 'OFF'); l.className = 'toggle-label ' + (o ? 'on' : 'off'); }
      if (sub) sub.textContent = t.checked ? 'ON' : 'OFF';
    }
  },

  showToast(msg, type, dur) {
    document.querySelectorAll('.toast').forEach(t => t.remove());
    const toast = document.createElement('div');
    toast.className = 'toast ' + (type || 'info');
    toast.innerHTML = msg + '<span class="toast-close" onclick="this.parentElement.remove()">×</span>';
    document.body.appendChild(toast);
    const d = dur || 3000;
    setTimeout(() => { if (toast.parentNode) { toast.style.opacity = '0'; setTimeout(() => { if (toast.parentNode) toast.remove(); }, 300); } }, d);
  },

  esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; },

  displayFile(s) { return (s || '').replace(/\.txt\b/g, '').replace(/^WIREGUARD_/, 'WG_'); },

  configDisplayName(file) {
    if (!file || file === '-') return '-';
    const config = this.state.configs.find(cfg => cfg.file === file);
    if (!config) return this.displayFile(file);
    return `${config.proto === 'wg' ? 'WG' : config.proto.toUpperCase()}: ${config.alias}`;
  },

  stripTxt(s) { return (s || '').replace(/\.txt\b/g, ''); },

  escId(s) { return s.replace(/[.#\s()]/g, '_'); }
};

document.addEventListener('DOMContentLoaded', () => setTimeout(() => ZBOX.init(), 100));

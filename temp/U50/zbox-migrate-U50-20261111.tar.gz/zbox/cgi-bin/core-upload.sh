#!/bin/sh
# Receive a user-supplied core as raw bytes. Signed .zbox bundles use update-upload.sh.
CORE_DIR="/tmp/zbox-core-upload"

echo "Content-Type: application/json"
echo ""

[ "$REQUEST_METHOD" = "POST" ] || { echo '{"status":"error","message":"POST required"}'; exit 0; }
case "${HTTP_X_ZBOX_COMPONENT:-}" in xray|singbox) component="$HTTP_X_ZBOX_COMPONENT" ;; *) echo '{"status":"error","message":"Component must be xray or singbox"}'; exit 0 ;; esac
case "${CONTENT_LENGTH:-}" in ''|*[!0-9]*) echo '{"status":"error","message":"Invalid upload length"}'; exit 0 ;; esac
[ "$CONTENT_LENGTH" -gt 0 ] 2>/dev/null && [ "$CONTENT_LENGTH" -le 104857600 ] 2>/dev/null || { echo '{"status":"error","message":"Core must be 1 to 100 MB"}'; exit 0; }
mkdir -p "$CORE_DIR" || { echo '{"status":"error","message":"Cannot create upload area"}'; exit 0; }
umask 077
printf '%s\n' '{"stage":"Uploading","percent":15,"message":"Receiving user-supplied core"}' > /tmp/zbox-update-progress.json
upload="$CORE_DIR/$component.upload"
dd of="${upload}.tmp" bs=4096 iflag=fullblock count=$(( (CONTENT_LENGTH + 4095) / 4096 )) 2>/dev/null
if [ "$(wc -c < "${upload}.tmp" 2>/dev/null)" != "$CONTENT_LENGTH" ]; then
  dd of="${upload}.tmp" bs=1 count="$CONTENT_LENGTH" 2>/dev/null
fi
[ "$(wc -c < "${upload}.tmp" 2>/dev/null)" = "$CONTENT_LENGTH" ] || { rm -f "${upload}.tmp"; echo '{"status":"error","message":"Incomplete upload"}'; exit 0; }
mv "${upload}.tmp" "$upload"
printf '%s\n' '{"stage":"Staging","percent":30,"message":"Custom core uploaded"}' > /tmp/zbox-update-progress.json
echo '{"status":"success","message":"Core uploaded"}'
